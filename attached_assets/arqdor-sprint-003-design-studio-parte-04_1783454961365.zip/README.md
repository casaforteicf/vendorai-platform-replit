# Sprint 003 — Design Studio — Parte 04

## Objetivo
Adicionar Biblioteca Inteligente ao Design Studio.

## Arquivos novos
- SearchLibrary.tsx
- FavoritesPanel.tsx
- MaterialSidebar.tsx
- FurnitureSidebar.tsx
- ManufacturerLibrary.tsx
- LibraryPanel.tsx

## Integração
Em `DesignStudio.tsx`:

1. Importar:
```tsx
import { LibraryPanel } from "./LibraryPanel";
```

2. Quando o modo atual for `materials`, renderizar o `LibraryPanel` no painel direito.
Exemplo:
```tsx
{mode === "materials" ? (
  <LibraryPanel />
) : (
  <AIChatPanel ... />
)}
```

3. Se preferir menor risco, apenas importar e deixar disponível sem substituir o painel atual.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts

## Validar
- pnpm check
- pnpm build
