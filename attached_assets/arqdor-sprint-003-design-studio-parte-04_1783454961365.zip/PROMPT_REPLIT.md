Aplicar Sprint 003 — Design Studio — Parte 04.

1. Copiar arquivos para:
artifacts/frontend/src/modules/arqdor/workspace/design-studio

2. Em DesignStudio.tsx:
- importar LibraryPanel;
- conectar LibraryPanel ao modo materials no painel direito;
- preservar AIChatPanel nos demais modos.

3. Não alterar backend.
4. Não alterar banco.
5. Não alterar Core Vendor.ai.
6. Não alterar rotas.
7. Não alterar useArqProject.ts.

Rodar:
- pnpm check
- pnpm build

Corrigir somente imports/tipagens se necessário.
