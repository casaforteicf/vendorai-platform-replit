Aplicar Sprint 018.

1 Copiar arquivos.
2 Atualizar Sidebar/Menu.
3 Criar grupos:
Projeto
Operações
Construção
Integração

4 Substituir:
case 'integracao' => IntegrationHub

5 Renomear legado para:
'integracao-legado'

6 Atualizar MODULE_MAP sem duplicidades.

7 Não alterar backend.

8 Rodar:
pnpm typecheck

Entregar:
- prints
- typecheck
- menu final
- rotas finais.
