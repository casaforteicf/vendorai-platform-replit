# Sprint 018 — Menu Principal + Navegação

## Objetivo
Integrar todos os módulos criados entre as Sprints 015–017 ao menu principal do ARQDOR.

### Entregas
- Menu lateral reorganizado
- Grupo Integração
- Grupo Operações
- Grupo BIM/Construção
- Migração de `integracao` para `IntegrationHub`
- `integracao-legado` preservado
- MODULE_MAP atualizado
- Navegação consistente
- Nenhuma alteração de backend

## Módulos no menu

Projeto
- Project Studio
- Render
- Specification
- Budget
- Procurement
- Production

Operações
- Automation Audit
- AI Command Intelligence
- Executive Cockpit

Construção
- BIM Digital Twin
- Construction Hub
- Smart Building
- Facility Management

Integração
- Integration Hub
- Data Sync
- Unified Copilot
- Migration Audit
