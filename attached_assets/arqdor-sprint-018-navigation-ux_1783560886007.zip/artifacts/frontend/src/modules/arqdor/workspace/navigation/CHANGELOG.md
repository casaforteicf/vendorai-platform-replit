Sprint 018
- Reorganização do menu
- Integração dos módulos 015-017
- Migração do IntegrationHub
