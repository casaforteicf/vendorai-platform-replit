Aplicar Sprint 017A — Integration Hub + Workflow Engine.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-hub

2. Integrar em ArqWorkspace:
import IntegrationHub from "./integration-hub/IntegrationHub";

3. Usar em case seguro:
case "integration":
case "integration-hub":
case "integracao":
  return <IntegrationHub arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Integration Hub;
- resultado typecheck.
