Aplicar Sprint 016D — Facility Management.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/facility-management

2. Integrar em ArqWorkspace:
import FacilityManagementCenter from "./facility-management/FacilityManagementCenter";

3. Usar em case seguro:
case "facility":
case "facility-management":
case "manutencao":
  return <FacilityManagementCenter arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Facility Management Center;
- resultado typecheck.
