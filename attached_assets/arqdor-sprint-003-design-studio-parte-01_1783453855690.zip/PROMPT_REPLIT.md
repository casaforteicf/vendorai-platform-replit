Aplicar Sprint 003 — Design Studio — Parte 01.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/design-studio

2. Em ArqWorkspace.tsx:
- importar DesignStudio;
- plugar DesignStudio no case do módulo de render/studio/design mais adequado;
- se houver risco de quebrar o render atual, criar integração mínima em um case de teste existente.

3. Não alterar backend.
4. Não alterar banco.
5. Não alterar Core Vendor.ai.
6. Não alterar useArqProject.ts.
7. Não alterar rotas.

Rodar:
- pnpm check
- pnpm build

Corrigir apenas imports/tipagens se necessário.

Entregar arquivos alterados e resultado do build.
