# Sprint 003 — Design Studio — Parte 01

## Objetivo
Criar a estrutura base do Design Studio dentro do ARQDOR Workspace.

## Arquivos novos
- `artifacts/frontend/src/modules/arqdor/workspace/design-studio/DesignStudio.tsx`
- `artifacts/frontend/src/modules/arqdor/workspace/design-studio/DesignHeader.tsx`
- `artifacts/frontend/src/modules/arqdor/workspace/design-studio/WorkspaceLayout.tsx`
- `artifacts/frontend/src/modules/arqdor/workspace/design-studio/StudioContext.tsx`

## Integração
Em `ArqWorkspace.tsx`:

Adicionar:

```tsx
import DesignStudio from "./design-studio/DesignStudio";
```

No case do módulo de render/studio/design, usar:

```tsx
return <DesignStudio arqState={arqState} onNavigate={handleNavigate} />;
```

Se não quiser substituir o módulo de render ainda, adicionar apenas em um case disponível para teste.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts

## Validar
- `pnpm check`
- `pnpm build`
