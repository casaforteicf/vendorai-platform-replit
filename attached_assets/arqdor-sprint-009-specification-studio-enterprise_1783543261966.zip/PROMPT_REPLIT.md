Aplicar Sprint 009.

Substituir:
artifacts/frontend/src/modules/arqdor/workspace/specification-studio/SpecificationStudio.tsx

Não alterar backend, banco, hooks ou ArqWorkspace.
Executar:
pnpm typecheck
pnpm build
