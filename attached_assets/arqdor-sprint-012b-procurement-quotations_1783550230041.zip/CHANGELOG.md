# Changelog — Sprint 012B

## Adicionado
- Módulo completo de cotações.
- QuotationCard.
- QuotationInspector.
- SupplierComparison.
- QuoteRanking.
- PriceHistory.
- LeadTimeComparison.
- AIQuoteAnalyzer.
- NegotiationPanel.
- Critérios de ranking.
