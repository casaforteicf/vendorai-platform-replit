Aplicar Sprint 012B — Procurement Quotations.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/procurement-studio/quotations

2. Integrar em ProcurementStudio:
import Quotations from "./quotations/Quotations";

3. No view/case quotations, renderizar:
return <Quotations onNavigate={onNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print da tela de cotações;
- resultado typecheck.
