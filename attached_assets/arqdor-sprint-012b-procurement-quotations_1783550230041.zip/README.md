# Sprint 012B — Procurement Quotations

## Pacote 2 da Sprint 012

Arquivos incluídos:
- Quotations.tsx
- quotationTypes.ts
- quotationData.ts
- quotationUtils.ts
- QuotationCard.tsx
- QuotationInspector.tsx
- SupplierComparison.tsx
- QuoteRanking.tsx
- PriceHistory.tsx
- LeadTimeComparison.tsx
- AIQuoteAnalyzer.tsx
- NegotiationPanel.tsx

## Objetivo
Completar o módulo de cotações:
- Comparativo de fornecedores.
- Ranking por critério.
- Melhor preço/prazo/score/equilíbrio.
- Histórico de preços.
- Comparação de lead time.
- IA de análise de cotações.
- Simulação de negociação.

## Integração
Importar no ProcurementStudio ou ArqWorkspace:

```tsx
import Quotations from "./procurement-studio/quotations/Quotations";
```

Usar quando o usuário acessar cotações:
```tsx
return <Quotations onNavigate={handleNavigate} />;
```
