Fluxo:
Budget→Procurement→Production→Construction→Facility
Todos comunicam via EventBus.
Fallback sem websocket.
