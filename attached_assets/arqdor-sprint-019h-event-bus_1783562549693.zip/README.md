# Sprint 019H
Event Bus + sincronização.

Arquivos:
- EventBus
- EventRegistry
- RealtimeSyncService

Rodar pnpm typecheck.
