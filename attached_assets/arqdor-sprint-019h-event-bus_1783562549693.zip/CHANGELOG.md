Sprint 019H - Event Bus e sincronização.
