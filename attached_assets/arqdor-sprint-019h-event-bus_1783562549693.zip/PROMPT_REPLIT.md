Aplicar Sprint 019H

1 Copiar event-bus
2 Integrar EventBus sem quebrar fluxo atual
3 Não remover lógica existente
4 Publicar eventos apenas quando APIs responderem
5 Rodar pnpm typecheck

Entregar:
- typecheck
- eventos registrados
- módulos conectados
- pendências 019I
