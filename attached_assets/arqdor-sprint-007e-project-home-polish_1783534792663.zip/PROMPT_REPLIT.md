Aplicar Sprint 007E — Project Home Polish.

1. Substituir exatamente este arquivo:
artifacts/frontend/src/modules/arqdor/workspace/project-experience/ProjectHomeV2.tsx

2. Não criar componente paralelo.
3. Não criar case novo.
4. Não alterar ArqWorkspace.tsx.
5. Não alterar backend.
6. Não alterar banco.
7. Não alterar Core Vendor.ai.
8. Não alterar rotas.
9. Não alterar useArqProject.ts.

Rodar:
- pnpm typecheck
- pnpm build

Corrigir somente tipagens/imports se necessário.

Entregar:
- confirmação do arquivo substituído;
- resultado typecheck;
- resultado build;
- print da Home.
