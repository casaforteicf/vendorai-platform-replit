# Changelog — Sprint 007E

## Alterado
- ProjectHomeV2 refinado:
  - Hero mais rico.
  - Métricas executivas.
  - AI Architect contextual.
  - AI Score por etapa.
  - Workflow visual.
  - Cards de projeto mais completos.
  - Timeline de evolução.
