# Sprint 007E — Project Home Polish

## Objetivo
Substituir diretamente o `ProjectHomeV2.tsx` para deixar a Home do ARQDOR alinhada ao produto definido.

## Arquivo substituído
- `artifacts/frontend/src/modules/arqdor/workspace/project-experience/ProjectHomeV2.tsx`

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts
- ArqWorkspace.tsx

## Validação
- Abrir `/arch/render`.
- Confirmar nova Home com:
  - Hero rico.
  - AI Architect.
  - AI Score.
  - Fluxo Design → Documentação → Produção → Orçamento → Cliente.
  - Cards ricos.
- Rodar `pnpm typecheck`.
- Rodar `pnpm build`.
