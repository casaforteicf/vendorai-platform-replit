Aplicar Sprint 019E — Procurement API Integration.

Objetivo:
Conectar Procurement ao evento budget.approved com fallback seguro.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-hub/procurement-api

2. Integrar gradualmente:
- ProcurementRepository para /arch/procurement ou rota equivalente existente.
- SupplierRepository para /arch/marketplace/suppliers ou rota equivalente.
- BudgetApprovedHandler para converter budget.approved em purchase requests.

3. Não remover procurementData.ts ainda.
Usar fallback:
- tenta API real;
- se falhar, usa dados mockados atuais.

4. Validar contrato:
- projectId
- budgetId
- approvalId
- canonicalProductId
- quantity
- unit
- supplierId quando existir

5. Se /arch/procurement não existir:
- não criar backend;
- manter adapter documentado;
- registrar pendência para backend.

6. Rodar:
pnpm typecheck

Entregar:
- typecheck;
- arquivos alterados;
- fallback mantido;
- APIs encontradas;
- APIs ausentes;
- pendências para 019F Production.
