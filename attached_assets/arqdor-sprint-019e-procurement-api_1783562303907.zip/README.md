# Sprint 019E — Procurement API Integration

## Objetivo
Conectar o Procurement ao evento `budget.approved` e iniciar a criação de solicitações de compra reais.

## Entregas
- ProcurementRepository
- BudgetApprovedHandler
- SupplierRepository
- ProcurementValidation
- ProcurementContract
- Plano técnico
- Checklist de migração

## Integração sugerida
```ts
import { BudgetApprovedHandler } from "./integration-hub/procurement-api/BudgetApprovedHandler";
import { ProcurementRepository } from "./integration-hub/procurement-api/ProcurementRepository";
```

## Regras
- Não alterar backend.
- Não remover fallback mock ainda.
- Não criar pedido sem aprovação financeira.
- Rodar `pnpm typecheck`.
