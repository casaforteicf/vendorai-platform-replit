# Changelog — Sprint 019E

## Adicionado
- ProcurementRepository
- BudgetApprovedHandler
- SupplierRepository
- ProcurementValidation
- ProcurementContract
- Plano de migração Procurement API
- Checklist 019E
