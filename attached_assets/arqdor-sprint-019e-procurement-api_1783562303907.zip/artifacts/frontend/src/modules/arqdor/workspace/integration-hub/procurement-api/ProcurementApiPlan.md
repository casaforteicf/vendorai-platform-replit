# Plano técnico — Sprint 019E

## Objetivo
Conectar Procurement ao evento `budget.approved` e preparar a criação de solicitações de compra reais.

## Fluxo
Budget aprovado
→ budget.approved
→ BudgetApprovedHandler
→ Purchase Requests
→ Supplier/Marketplace
→ Cotação
→ Pedido de compra
→ Recebimento
→ Production

## Regras
- Não criar pedido de compra sem approvalId.
- Não criar solicitação sem canonicalProductId.
- supplierId pode ser opcional inicialmente, mas deve gerar pendência.
- Manter fallback mock até API real ser confirmada.
