# Checklist 019E

- [ ] Confirmar se /arch/procurement existe
- [ ] Confirmar endpoint de purchase requests
- [ ] Confirmar endpoint de suppliers/marketplace
- [ ] Integrar BudgetApprovedHandler
- [ ] Manter fallback para procurementData.ts
- [ ] Validar approvalId
- [ ] Validar canonicalProductId
- [ ] Rodar pnpm typecheck
- [ ] Listar pendências para 019F Production
