Aplicar Sprint 009 — Specification Studio Enterprise FULL.

1. Copiar:
artifacts/frontend/src/modules/arqdor/workspace/specification-studio/SpecificationStudio.tsx

2. Integrar em ArqWorkspace com um case seguro:
- specification
- especificacao-produto
ou rota/módulo equivalente disponível.

3. Não alterar backend.
4. Não alterar banco.
5. Não alterar hooks.
6. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build

Entregar:
- print do Specification Studio;
- resultado typecheck;
- resultado build.
