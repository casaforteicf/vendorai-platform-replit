# Changelog — Sprint 009 FULL

## Adicionado
- Specification Studio Enterprise completo.
- Objetos inteligentes.
- Inspector técnico do objeto.
- Biblioteca de materiais.
- Fornecedores.
- Timeline executiva.
- IA de especificação.
- Integração conceitual com render, orçamento e produção.
