Aplicar Sprint 007G — Smart Render Polish.

1. Substituir:
artifacts/frontend/src/modules/arqdor/workspace/smart-render-engine/SmartRenderEngine.tsx

2. Não criar componentes paralelos.
3. Não alterar ArqWorkspace.
4. Não alterar backend, banco, rotas ou hooks.

Rodar:
pnpm typecheck
pnpm build

Entregar print do Smart Render.
