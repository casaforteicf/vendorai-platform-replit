# Changelog — Sprint 007G

## Alterado
- SmartRenderEngine refinado:
  - render protagonista;
  - IA contextual;
  - painel de objeto inteligente;
  - custos conectados;
  - timeline visual de versões;
  - navegação para especificação, produção, orçamento e cliente.
