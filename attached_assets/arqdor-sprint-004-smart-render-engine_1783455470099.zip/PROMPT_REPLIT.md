Aplicar Sprint 004 — Smart Render Engine.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/smart-render-engine

2. Em ArqWorkspace.tsx:
- importar SmartRenderEngine;
- plugar em um case seguro do workspace, preferencialmente o módulo de render se isso não quebrar o fluxo atual;
- se houver risco, criar integração apenas para teste em case disponível.

3. Não alterar backend.
4. Não alterar banco.
5. Não alterar Core Vendor.ai.
6. Não alterar rotas.
7. Não alterar useArqProject.ts.

Rodar:
- pnpm check
- pnpm build

Corrigir somente imports/tipagens se necessário.

Entregar:
- arquivos copiados;
- arquivo alterado para integração;
- resultado typecheck;
- resultado build.
