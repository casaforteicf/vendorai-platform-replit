# Changelog — Sprint 004

## Adicionado
- Contexto do Render Engine.
- Canvas avançado com zoom e comparação.
- Prompt Builder.
- Timeline de versões.
- Painel de exportação.
- Hook para detectar versões existentes a partir do arqState.

## Observação
Esta Sprint não chama backend de render. Ela cria a estrutura visual e de estado para integração futura com os endpoints existentes.
