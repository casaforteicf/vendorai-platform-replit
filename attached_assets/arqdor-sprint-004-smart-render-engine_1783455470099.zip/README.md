# Sprint 004 — Smart Render Engine

## Objetivo
Criar o núcleo visual do Smart Render Engine do ARQDOR.ai.

## Arquivos incluídos
- SmartRenderEngine.tsx
- RenderEngineContext.tsx
- useRenderEngineData.ts
- SmartRenderCanvas.tsx
- RenderToolbar.tsx
- PromptBuilder.tsx
- RenderVersionTimeline.tsx
- RenderExportPanel.tsx

## Integração sugerida
Em `ArqWorkspace.tsx`, importar:

```tsx
import SmartRenderEngine from "./smart-render-engine/SmartRenderEngine";
```

Plugar em um case seguro de render ou teste:

```tsx
return <SmartRenderEngine arqState={arqState} />;
```

Se o render atual estiver em produção, não substituir diretamente. Adicionar primeiro em um case de teste ou módulo disponível.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts

## Validação
- pnpm check
- pnpm build
