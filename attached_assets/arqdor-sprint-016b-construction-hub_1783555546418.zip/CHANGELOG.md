# Changelog — Sprint 016B

## Adicionado
- Construction Hub.
- Construction Dashboard.
- Site Diary.
- Physical Schedule.
- Financial Schedule.
- Team Management.
- Measurement Panel.
- Checklist Panel.
- Non Conformity Panel.
- Photo Gallery.
- Site Approvals.
- AI Construction.
