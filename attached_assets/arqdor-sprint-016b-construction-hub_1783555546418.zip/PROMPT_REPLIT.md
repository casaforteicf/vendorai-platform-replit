Aplicar Sprint 016B — Construction Hub.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/construction-hub

2. Integrar em ArqWorkspace:
import ConstructionHub from "./construction-hub/ConstructionHub";

3. Usar em case seguro:
case "construction":
case "obra":
case "construction-hub":
  return <ConstructionHub arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Construction Hub;
- resultado typecheck.
