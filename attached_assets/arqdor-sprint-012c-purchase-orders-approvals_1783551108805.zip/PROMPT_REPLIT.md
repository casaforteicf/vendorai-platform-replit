Aplicar Sprint 012C — Purchase Orders & Approvals.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/procurement-studio/purchase-orders

2. Integrar em ProcurementStudio:
import PurchaseOrders from "./purchase-orders/PurchaseOrders";

3. No view/case orders, renderizar:
return <PurchaseOrders onNavigate={onNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print da tela de Pedidos de Compra;
- resultado typecheck.
