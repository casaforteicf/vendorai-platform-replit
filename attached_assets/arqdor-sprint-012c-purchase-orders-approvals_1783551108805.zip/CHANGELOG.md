# Changelog — Sprint 012C

## Adicionado
- Purchase Orders.
- PurchaseOrderCard.
- PurchaseOrderInspector.
- ApprovalFlow.
- ApprovalTimeline.
- DigitalApproval.
- OrderStatusBoard.
- PurchasePDFPanel.
- PurchaseAttachments.
- OrderHistory.
- Dados e tipos de pedidos de compra.
