# Sprint 012C — Purchase Orders & Approvals

## Pacote C da Sprint 012

Arquivos incluídos:
- PurchaseOrders.tsx
- purchaseOrderTypes.ts
- purchaseOrderData.ts
- purchaseOrderUtils.ts
- PurchaseOrderCard.tsx
- PurchaseOrderInspector.tsx
- ApprovalFlow.tsx
- ApprovalTimeline.tsx
- DigitalApproval.tsx
- OrderStatusBoard.tsx
- PurchasePDFPanel.tsx
- PurchaseAttachments.tsx
- OrderHistory.tsx

## Objetivo
Completar fluxo de pedidos de compra:
- Pedidos de Compra.
- Aprovação multinível.
- Aprovação digital.
- Status Board.
- PDF estrutural.
- Anexos.
- Histórico/rastreabilidade.
- Integração com Procurement Studio.

## Integração
Importar no ProcurementStudio ou ArqWorkspace:

```tsx
import PurchaseOrders from "./procurement-studio/purchase-orders/PurchaseOrders";
```

Renderizar no view/case orders:
```tsx
return <PurchaseOrders onNavigate={onNavigate} />;
```
