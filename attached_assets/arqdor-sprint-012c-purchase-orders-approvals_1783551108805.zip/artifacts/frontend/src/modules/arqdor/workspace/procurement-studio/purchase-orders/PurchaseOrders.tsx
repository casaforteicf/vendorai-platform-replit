import React, { useState } from "react";
import { ApprovalFlow } from "./ApprovalFlow";
import { ApprovalTimeline } from "./ApprovalTimeline";
import { DigitalApproval } from "./DigitalApproval";
import { OrderHistory } from "./OrderHistory";
import { OrderStatusBoard } from "./OrderStatusBoard";
import { PurchaseAttachments } from "./PurchaseAttachments";
import { PurchaseOrderCard } from "./PurchaseOrderCard";
import { PurchaseOrderInspector } from "./PurchaseOrderInspector";
import { PurchasePDFPanel } from "./PurchasePDFPanel";
import { purchaseOrders } from "./purchaseOrderData";
import type { PurchaseOrder, PurchaseOrderView } from "./purchaseOrderTypes";
import { currency } from "./purchaseOrderUtils";
import { MetricCard } from "../MetricCard";

type PurchaseOrdersProps = {
  onNavigate?: (module: string) => void;
};

export default function PurchaseOrders({ onNavigate }: PurchaseOrdersProps) {
  const [view, setView] = useState<PurchaseOrderView>("dashboard");
  const [selectedOrder, setSelectedOrder] = useState<PurchaseOrder>(purchaseOrders[0]);

  const total = purchaseOrders.reduce((sum, order) => sum + order.total, 0);
  const waiting = purchaseOrders.filter((order) => order.status === "waiting_approval").length;
  const approved = purchaseOrders.filter((order) => order.status === "approved").length;

  return (
    <div className="min-h-screen bg-[#f7f7f8] text-slate-950">
      <div className="mx-auto flex w-full max-w-[1760px] flex-col gap-5 px-6 py-6">
        <header className="rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">Purchase Orders</p>
              <h1 className="mt-1 text-3xl font-semibold tracking-tight text-slate-950">Pedidos de Compra</h1>
              <p className="mt-1 text-sm text-slate-500">Pedido, aprovação, assinatura, anexos e rastreabilidade.</p>
            </div>

            <div className="flex flex-wrap gap-2">
              {[
                ["dashboard", "Dashboard"],
                ["orders", "Pedidos"],
                ["status", "Status"],
                ["approval", "Aprovação"],
                ["digital", "Digital"],
                ["pdf", "PDF"],
                ["attachments", "Anexos"],
                ["history", "Histórico"],
              ].map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setView(id as PurchaseOrderView)}
                  className={[
                    "rounded-2xl px-4 py-2 text-sm font-semibold transition",
                    view === id ? "bg-slate-950 text-white" : "bg-slate-50 text-slate-600 hover:bg-violet-50 hover:text-violet-700",
                  ].join(" ")}
                >
                  {label}
                </button>
              ))}

              <button type="button" onClick={() => onNavigate?.("compras")} className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:border-violet-200 hover:text-violet-700">
                Voltar compras
              </button>
            </div>
          </div>
        </header>

        {view === "dashboard" || view === "orders" ? (
          <>
            <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              <MetricCard label="Pedidos" value={String(purchaseOrders.length)} description="Pedidos em andamento." />
              <MetricCard label="Volume" value={currency(total)} description="Total em pedidos de compra." />
              <MetricCard label="Aguardando" value={String(waiting)} description="Pedidos pendentes de aprovação." />
              <MetricCard label="Aprovados" value={String(approved)} description="Pedidos liberados." />
            </section>

            <main className="grid gap-5 xl:grid-cols-[1fr_390px]">
              <section className="rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm">
                <div className="mb-5">
                  <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">Pedidos</p>
                  <h2 className="mt-1 text-xl font-semibold text-slate-950">Pedidos gerados</h2>
                </div>

                <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                  {purchaseOrders.map((order) => (
                    <PurchaseOrderCard key={order.id} order={order} selected={selectedOrder.id === order.id} onSelect={setSelectedOrder} />
                  ))}
                </div>
              </section>

              <PurchaseOrderInspector order={selectedOrder} />
            </main>
          </>
        ) : null}

        {view === "status" ? <OrderStatusBoard /> : null}
        {view === "approval" ? (
          <div className="space-y-5">
            <ApprovalFlow />
            <ApprovalTimeline />
          </div>
        ) : null}
        {view === "digital" ? <DigitalApproval /> : null}
        {view === "pdf" ? <PurchasePDFPanel order={selectedOrder} /> : null}
        {view === "attachments" ? <PurchaseAttachments /> : null}
        {view === "history" ? <OrderHistory /> : null}
      </div>
    </div>
  );
}
