import React from "react";
import { approvalSteps } from "./purchaseOrderData";
import { approvalClass } from "./purchaseOrderUtils";

export function ApprovalTimeline() {
  return (
    <section className="rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm">
      <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">Timeline</p>
      <h2 className="mt-1 text-xl font-semibold text-slate-950">Histórico de aprovações</h2>

      <div className="mt-5 space-y-4">
        {approvalSteps.map((step, index) => (
          <div key={step.id} className="flex gap-4">
            <div className="flex flex-col items-center">
              <span className={["h-3 w-3 rounded-full", step.status === "approved" ? "bg-violet-600" : "bg-slate-200"].join(" ")} />
              {index < approvalSteps.length - 1 ? <span className="mt-2 h-full min-h-[42px] w-px bg-slate-200" /> : null}
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-950">{step.role} — {step.person}</p>
              <p className="mt-1 text-xs text-slate-500">{step.note}</p>
              <span className={`mt-2 inline-flex rounded-full px-3 py-1 text-xs font-semibold ${approvalClass(step.status)}`}>{step.status}</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
