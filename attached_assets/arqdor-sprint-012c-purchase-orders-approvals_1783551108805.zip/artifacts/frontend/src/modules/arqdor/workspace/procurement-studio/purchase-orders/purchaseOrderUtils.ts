import type { ApprovalStatus, PurchaseOrderStatus } from "./purchaseOrderTypes";

export function currency(value: number): string {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function formatDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", year: "numeric" }).format(date);
}

export function statusClass(status: PurchaseOrderStatus) {
  const classes: Record<PurchaseOrderStatus, string> = {
    draft: "bg-slate-100 text-slate-700",
    waiting_approval: "bg-amber-50 text-amber-700",
    approved: "bg-emerald-50 text-emerald-700",
    sent: "bg-blue-50 text-blue-700",
    confirmed: "bg-violet-50 text-violet-700",
    in_delivery: "bg-cyan-50 text-cyan-700",
    received: "bg-emerald-100 text-emerald-800",
    cancelled: "bg-rose-50 text-rose-700",
  };
  return classes[status];
}

export function approvalClass(status: ApprovalStatus) {
  const classes: Record<ApprovalStatus, string> = {
    pending: "bg-amber-50 text-amber-700",
    approved: "bg-emerald-50 text-emerald-700",
    rejected: "bg-rose-50 text-rose-700",
    skipped: "bg-slate-100 text-slate-700",
  };
  return classes[status];
}
