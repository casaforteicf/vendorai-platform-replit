import React from "react";
import { orderEvents } from "./purchaseOrderData";

export function OrderHistory() {
  return (
    <section className="rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm">
      <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">Histórico</p>
      <h2 className="mt-1 text-xl font-semibold text-slate-950">Rastreabilidade do pedido</h2>

      <div className="mt-5 space-y-4">
        {orderEvents.map((event, index) => (
          <div key={event.id} className="flex gap-4">
            <div className="flex flex-col items-center">
              <span className="h-3 w-3 rounded-full bg-violet-600" />
              {index < orderEvents.length - 1 ? <span className="mt-2 h-full min-h-[42px] w-px bg-slate-200" /> : null}
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-950">{event.title}</p>
              <p className="mt-1 text-xs leading-5 text-slate-500">{event.description}</p>
              <p className="mt-1 text-xs text-slate-400">{event.author} • {event.date}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
