import React from "react";
import { attachments } from "./purchaseOrderData";

export function PurchaseAttachments() {
  return (
    <section className="rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm">
      <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">Anexos</p>
      <h2 className="mt-1 text-xl font-semibold text-slate-950">Documentos do pedido</h2>

      <div className="mt-5 grid gap-5 md:grid-cols-3">
        {attachments.map((attachment) => (
          <article key={attachment.id} className="rounded-[28px] border border-slate-100 bg-white p-5 shadow-sm">
            <p className="text-base font-semibold text-slate-950">{attachment.name}</p>
            <p className="mt-1 text-sm text-slate-500">{attachment.type} • {attachment.size}</p>
            <p className="mt-4 text-xs text-slate-400">{attachment.uploadedBy} • {attachment.uploadedAt}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
