import React from "react";
import type { PurchaseOrder } from "./purchaseOrderTypes";
import { currency, formatDate } from "./purchaseOrderUtils";

export function PurchasePDFPanel({ order }: { order: PurchaseOrder }) {
  return (
    <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
      <section className="rounded-[34px] border border-slate-100 bg-white p-8 shadow-sm">
        <div className="mx-auto max-w-3xl rounded-3xl border border-slate-200 bg-white p-8">
          <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">Pedido de Compra</p>
          <h2 className="mt-2 text-3xl font-semibold text-slate-950">{order.code}</h2>
          <p className="mt-1 text-sm text-slate-500">{order.supplier}</p>

          <div className="mt-8 grid grid-cols-2 gap-4 text-sm">
            <Info label="Item" value={order.itemName} />
            <Info label="Entrega" value={formatDate(order.deliveryDate)} />
            <Info label="Quantidade" value={`${order.quantity} ${order.unit}`} />
            <Info label="Total" value={currency(order.total)} />
            <Info label="Pagamento" value={order.paymentTerms} />
            <Info label="Responsável" value={order.responsible} />
          </div>
        </div>
      </section>

      <aside className="rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm">
        <p className="text-sm font-semibold text-slate-950">Ações</p>
        <div className="mt-5 space-y-3">
          {["Gerar PDF", "Enviar fornecedor", "Anexar ao CRM", "Salvar no projeto"].map((action) => (
            <button key={action} type="button" className="w-full rounded-2xl bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 hover:bg-violet-50 hover:text-violet-700">
              {action}
            </button>
          ))}
        </div>
      </aside>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-3">
      <p className="text-xs text-slate-400">{label}</p>
      <p className="mt-1 font-semibold text-slate-800">{value}</p>
    </div>
  );
}
