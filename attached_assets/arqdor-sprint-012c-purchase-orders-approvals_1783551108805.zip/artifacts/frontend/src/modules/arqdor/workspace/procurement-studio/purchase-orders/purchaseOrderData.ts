import type { ApprovalStep, Attachment, OrderEvent, PurchaseOrder } from "./purchaseOrderTypes";

export const purchaseOrders: PurchaseOrder[] = [
  {
    id: "po-001",
    code: "PO-ARQ-001",
    requestCode: "REQ-ARQ-001",
    quoteCode: "QT-001",
    project: "Projeto ARQDOR",
    environment: "Sala de Estar",
    supplier: "Marceneiro Local",
    itemName: "Painel TV em MDF Carvalho Claro",
    category: "Marcenaria",
    quantity: 1,
    unit: "vb",
    unitPrice: 8260,
    total: 8260,
    paymentTerms: "40% entrada / 60% entrega",
    deliveryDate: "2026-08-04",
    status: "waiting_approval",
    responsible: "Compras",
    aiNote: "Validar rasgo de LED e passagem técnica antes do envio definitivo.",
  },
  {
    id: "po-002",
    code: "PO-ARQ-002",
    requestCode: "REQ-ARQ-002",
    quoteCode: "QT-004",
    project: "Projeto ARQDOR",
    environment: "Cozinha",
    supplier: "Marmoraria Local",
    itemName: "Bancada Gourmet em Quartzo Branco",
    category: "Marmoraria",
    quantity: 5.1,
    unit: "m²",
    unitPrice: 2056.47,
    total: 10488,
    paymentTerms: "50% entrada / 50% instalação",
    deliveryDate: "2026-08-01",
    status: "approved",
    responsible: "Compras",
    aiNote: "Pedido aprovado. Conferir cuba, cooktop e acabamento antes do recebimento.",
  },
  {
    id: "po-003",
    code: "PO-ARQ-003",
    requestCode: "REQ-ARQ-003",
    quoteCode: "QT-008",
    project: "Projeto ARQDOR",
    environment: "Sala de Estar",
    supplier: "Luminárias Pro",
    itemName: "Perfil LED Linear",
    category: "Iluminação",
    quantity: 3,
    unit: "un",
    unitPrice: 890,
    total: 2670,
    paymentTerms: "À vista",
    deliveryDate: "2026-07-20",
    status: "sent",
    responsible: "Compras",
    aiNote: "Compra alinhada ao cronograma. Agrupar entrega com itens elétricos.",
  },
];

export const approvalSteps: ApprovalStep[] = [
  { id: "ap-001", role: "Arquitetura", person: "Responsável técnico", status: "approved", date: "2026-07-10", note: "Especificação validada." },
  { id: "ap-002", role: "Financeiro", person: "Gestor financeiro", status: "pending", note: "Aguardando liberação." },
  { id: "ap-003", role: "Cliente", person: "Cliente final", status: "pending", note: "Aprovação comercial pendente." },
  { id: "ap-004", role: "Compras", person: "Comprador", status: "pending", note: "Pedido será enviado após aprovação." },
];

export const attachments: Attachment[] = [
  { id: "att-001", name: "Cotacao_Marceneiro_Local.pdf", type: "quote", size: "428 KB", uploadedBy: "Compras", uploadedAt: "2026-07-10" },
  { id: "att-002", name: "Detalhamento_Painel_TV.pdf", type: "pdf", size: "1.8 MB", uploadedBy: "Documentação", uploadedAt: "2026-07-09" },
  { id: "att-003", name: "Vista_Painel_TV.dwg", type: "dwg", size: "2.2 MB", uploadedBy: "Projeto", uploadedAt: "2026-07-09" },
];

export const orderEvents: OrderEvent[] = [
  { id: "ev-001", title: "Pedido criado", description: "Pedido gerado a partir da cotação aprovada.", author: "Sistema", date: "2026-07-10" },
  { id: "ev-002", title: "Aprovação técnica", description: "Especificação validada pela arquitetura.", author: "Responsável técnico", date: "2026-07-10" },
  { id: "ev-003", title: "Aguardando financeiro", description: "Pedido aguardando liberação financeira.", author: "Sistema", date: "2026-07-11" },
];

export const aiOrderInsights = [
  {
    title: "Aprovação financeira pendente",
    description: "Pedido principal da marcenaria ainda não foi liberado pelo financeiro.",
    impact: "Bloqueia envio",
    action: "Solicitar aprovação",
  },
  {
    title: "Anexos suficientes",
    description: "Cotação, PDF técnico e DWG já estão anexados ao pedido.",
    impact: "Pronto para fornecedor",
    action: "Enviar pedido",
  },
  {
    title: "Risco de divergência técnica",
    description: "Antes do envio, confirmar rasgos de LED no painel TV.",
    impact: "Evita retrabalho",
    action: "Gerar checklist",
  },
];
