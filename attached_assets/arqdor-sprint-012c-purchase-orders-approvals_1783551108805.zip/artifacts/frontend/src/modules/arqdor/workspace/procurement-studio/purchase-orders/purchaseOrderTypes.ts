export type PurchaseOrderView =
  | "dashboard"
  | "orders"
  | "status"
  | "approval"
  | "digital"
  | "pdf"
  | "attachments"
  | "history";

export type PurchaseOrderStatus =
  | "draft"
  | "waiting_approval"
  | "approved"
  | "sent"
  | "confirmed"
  | "in_delivery"
  | "received"
  | "cancelled";

export type ApprovalStatus = "pending" | "approved" | "rejected" | "skipped";

export type PurchaseOrder = {
  id: string;
  code: string;
  requestCode: string;
  quoteCode: string;
  project: string;
  environment: string;
  supplier: string;
  itemName: string;
  category: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  total: number;
  paymentTerms: string;
  deliveryDate: string;
  status: PurchaseOrderStatus;
  responsible: string;
  aiNote: string;
};

export type ApprovalStep = {
  id: string;
  role: string;
  person: string;
  status: ApprovalStatus;
  date?: string;
  note?: string;
};

export type Attachment = {
  id: string;
  name: string;
  type: "pdf" | "image" | "dwg" | "quote" | "contract";
  size: string;
  uploadedBy: string;
  uploadedAt: string;
};

export type OrderEvent = {
  id: string;
  title: string;
  description: string;
  author: string;
  date: string;
};
