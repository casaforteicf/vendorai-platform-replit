import React from "react";
import { purchaseOrders } from "./purchaseOrderData";
import type { PurchaseOrderStatus } from "./purchaseOrderTypes";

const statuses: Array<{ id: PurchaseOrderStatus; label: string }> = [
  { id: "draft", label: "Rascunho" },
  { id: "waiting_approval", label: "Aprovação" },
  { id: "approved", label: "Aprovado" },
  { id: "sent", label: "Enviado" },
  { id: "confirmed", label: "Confirmado" },
  { id: "in_delivery", label: "Entrega" },
  { id: "received", label: "Recebido" },
];

export function OrderStatusBoard() {
  return (
    <section className="rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm">
      <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">Status Board</p>
      <h2 className="mt-1 text-xl font-semibold text-slate-950">Fluxo dos pedidos</h2>

      <div className="mt-6 grid gap-4 xl:grid-cols-7">
        {statuses.map((status) => {
          const orders = purchaseOrders.filter((order) => order.status === status.id);

          return (
            <div key={status.id} className="rounded-[24px] border border-slate-100 bg-slate-50 p-4">
              <p className="text-sm font-semibold text-slate-900">{status.label}</p>
              <p className="mt-1 text-xs text-slate-500">{orders.length} pedido(s)</p>
              <div className="mt-4 space-y-2">
                {orders.map((order) => (
                  <div key={order.id} className="rounded-2xl bg-white p-3 text-xs font-semibold text-slate-700 shadow-sm">
                    {order.code}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
