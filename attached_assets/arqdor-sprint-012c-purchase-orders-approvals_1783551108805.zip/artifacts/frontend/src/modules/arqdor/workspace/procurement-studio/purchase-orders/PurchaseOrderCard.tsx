import React from "react";
import type { PurchaseOrder } from "./purchaseOrderTypes";
import { currency, formatDate, statusClass } from "./purchaseOrderUtils";

type Props = {
  order: PurchaseOrder;
  selected?: boolean;
  onSelect: (order: PurchaseOrder) => void;
};

export function PurchaseOrderCard({ order, selected, onSelect }: Props) {
  return (
    <button type="button" onClick={() => onSelect(order)} className="text-left">
      <article className={[
        "rounded-[30px] border bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md",
        selected ? "border-violet-300 ring-4 ring-violet-100" : "border-slate-100",
      ].join(" ")}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-base font-semibold text-slate-950">{order.code}</p>
            <p className="mt-1 text-sm text-slate-500">{order.itemName}</p>
          </div>
          <span className={`rounded-full px-3 py-1 text-xs font-semibold ${statusClass(order.status)}`}>
            {order.status}
          </span>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 text-sm">
          <Info label="Fornecedor" value={order.supplier} />
          <Info label="Entrega" value={formatDate(order.deliveryDate)} />
          <Info label="Total" value={currency(order.total)} />
          <Info label="Qtd." value={`${order.quantity} ${order.unit}`} />
        </div>

        <div className="mt-4 rounded-2xl bg-slate-50 p-3">
          <p className="text-xs text-slate-400">Condição</p>
          <p className="mt-1 text-sm font-semibold text-slate-800">{order.paymentTerms}</p>
        </div>
      </article>
    </button>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-3">
      <p className="text-xs text-slate-400">{label}</p>
      <p className="mt-1 font-semibold text-slate-800">{value}</p>
    </div>
  );
}
