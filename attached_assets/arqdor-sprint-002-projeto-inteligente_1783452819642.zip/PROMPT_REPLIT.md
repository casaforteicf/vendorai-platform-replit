Aplicar Sprint 002 — Projeto Inteligente.

1. Criar o arquivo:
artifacts/frontend/src/modules/arqdor/workspace/modules/SmartProjectModule.tsx

2. Colar o código enviado.

3. Em ArqWorkspace.tsx:
- importar SmartProjectModule;
- trocar somente o retorno do case do módulo Projeto para SmartProjectModule;
- manter todos os demais cases intactos.

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar Core Vendor.ai.
7. Não alterar useArqProject.ts.
8. Não alterar rotas.
9. Rodar pnpm check e pnpm build.
10. Corrigir somente erros de import/tipagem se aparecerem.

Entregar:
- arquivos criados;
- arquivos alterados;
- resultado do typecheck;
- resultado do build.
