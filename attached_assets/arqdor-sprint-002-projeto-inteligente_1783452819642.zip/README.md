# Sprint 002 — Projeto Inteligente

## Objetivo

Adicionar o módulo `Projeto Inteligente` no ARQDOR Workspace usando a estrutura existente.

## Arquivo novo

Criar:

`artifacts/frontend/src/modules/arqdor/workspace/modules/SmartProjectModule.tsx`

## Integração

Em:

`artifacts/frontend/src/modules/arqdor/workspace/ArqWorkspace.tsx`

Adicionar import:

```tsx
import SmartProjectModule from "./modules/SmartProjectModule";
```

No `switch/case` de módulos, localizar o case usado para projeto.

Pode estar como:

```tsx
case 'projeto':
```

ou:

```tsx
case 'project':
```

Trocar apenas o retorno desse case para:

```tsx
return <SmartProjectModule arqState={arqState} onNavigate={handleNavigate} />;
```

Se a função de navegação tiver outro nome, usar a mesma função que já era usada para navegar entre módulos.

## Regras

Não alterar backend.
Não alterar banco.
Não alterar Core Vendor.ai.
Não alterar useArqProject.ts.
Não alterar rotas.
Não alterar fluxo de render.
Não remover o ProjectModule antigo.

## Validação

Rodar:

```bash
pnpm check
pnpm build
```
