# Changelog — Sprint 016A

## Adicionado
- Digital Twin Center.
- BIM Hub.
- IFC Viewer placeholder.
- Model Explorer.
- Model Properties.
- Clash Detection.
- Version Manager.
- Model Comparison.
- Export Center.
- BIM Insights.
