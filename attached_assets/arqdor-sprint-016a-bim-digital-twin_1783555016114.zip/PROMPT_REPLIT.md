Aplicar Sprint 016A — BIM & Digital Twin.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/bim-digital-twin

2. Integrar em ArqWorkspace:
import DigitalTwinCenter from "./bim-digital-twin/DigitalTwinCenter";

3. Usar em case seguro:
case "bim":
case "digital-twin":
case "twin":
  return <DigitalTwinCenter arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.
8. O IFCViewer é placeholder seguro para integração futura com IFC.js/xeokit.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Digital Twin Center;
- resultado typecheck.
