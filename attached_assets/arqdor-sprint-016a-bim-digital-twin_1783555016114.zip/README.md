# Sprint 016A — BIM & Digital Twin

## Arquivos incluídos
- DigitalTwinCenter.tsx
- bimTypes.ts
- bimData.ts
- bimUtils.ts
- MetricCard.tsx
- IFCViewer.tsx
- BIMHub.tsx
- ModelExplorer.tsx
- ModelProperties.tsx
- ClashDetection.tsx
- VersionManager.tsx
- ModelComparison.tsx
- ExportCenter.tsx
- BIMInsights.tsx

## Objetivo
Criar o módulo BIM & Digital Twin:
- BIM Hub.
- IFC Viewer placeholder seguro.
- Model Explorer.
- Propriedades dos elementos.
- Clash Detection.
- Versionamento BIM.
- Comparação de versões.
- Export Center.
- AI BIM Insights.
- Integração conceitual com Specification, Budget, Procurement, Production e Client Portal.

## Integração
Importar no ArqWorkspace:

```tsx
import DigitalTwinCenter from "./bim-digital-twin/DigitalTwinCenter";
```

Adicionar/usar case:
```tsx
case "bim":
case "digital-twin":
case "twin":
  return <DigitalTwinCenter arqState={arqState} onNavigate={handleNavigate} />;
```
