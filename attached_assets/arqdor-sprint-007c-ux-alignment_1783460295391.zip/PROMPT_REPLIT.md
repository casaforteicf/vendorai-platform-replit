Aplicar Sprint 007C — UX Alignment.

Objetivo:
Corrigir a experiência visual do ARQDOR.ai sem alterar backend, banco ou Core.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/ux-alignment

2. Em ArqWorkspace.tsx:
- importar AlignedStudioShell;
- criar um case seguro de teste chamado "ux-alignment" OU envolver o SmartRenderEngine/DesignStudio com AlignedStudioShell se for seguro;
- não remover os módulos anteriores.

3. Não alterar backend.
4. Não alterar banco.
5. Não alterar Core Vendor.ai.
6. Não alterar useArqProject.ts.
7. Não alterar rotas públicas.

Rodar:
- pnpm check
- pnpm build

Corrigir somente imports/tipagem se necessário.

Entregar:
- arquivos copiados;
- arquivo alterado para integração;
- resultado typecheck;
- resultado build;
- print da tela alinhada.
