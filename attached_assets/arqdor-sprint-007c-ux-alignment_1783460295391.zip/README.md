# Sprint 007C — UX Alignment

## Objetivo
Corrigir o desalinhamento visual/experiencial dos módulos já implantados, aproximando o ARQDOR.ai da experiência definida:

- IA sempre visível e contextual.
- Render protagonista.
- Projeto com AI Score.
- Painel de objeto inteligente.
- Timeline contando a evolução real do projeto.
- Fluxo Design → Documentação → Produção → Orçamento → Cliente.
- Menos aparência de editor simples.
- Mais aparência de sistema operacional para arquitetos.

## Arquivos incluídos
- AlignedStudioShell.tsx
- UXAlignedHome.tsx
- UXAlignmentContext.tsx
- AIArchitectPanel.tsx
- ProjectScorePanel.tsx
- ObjectIntelligencePanel.tsx
- WorkflowNavigator.tsx
- ProjectStoryTimeline.tsx
- uxAlignmentData.ts

## Integração recomendada
Esta Sprint é corretiva e deve ser aplicada com cuidado.

### Opção segura
Adicionar os componentes e testar em um case separado:

```tsx
import AlignedStudioShell from "./ux-alignment/AlignedStudioShell";
```

```tsx
case "ux-alignment":
  return <AlignedStudioShell />;
```

### Opção de alinhamento real
Usar `AlignedStudioShell` como shell visual ao redor do SmartRenderEngine ou DesignStudio existente.

Exemplo:

```tsx
return (
  <AlignedStudioShell title="Sala de Estar" subtitle="Projeto atual">
    <SmartRenderEngine arqState={arqState} />
  </AlignedStudioShell>
);
```

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas públicas
- useArqProject.ts

## Validação
- pnpm check
- pnpm build
