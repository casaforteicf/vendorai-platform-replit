# Changelog — Sprint 007C

## Adicionado
- AI Architect Panel.
- AI Score / saúde do projeto.
- Objeto inteligente com custo, fornecedor e recomendação IA.
- Timeline de decisões do projeto.
- Workflow Navigator.
- Shell visual alinhado à visão original do ARQDOR.ai.
