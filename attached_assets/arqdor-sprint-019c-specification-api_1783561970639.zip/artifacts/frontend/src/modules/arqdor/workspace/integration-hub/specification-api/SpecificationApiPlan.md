# Plano técnico — Sprint 019C

## Objetivo
Conectar o Specification Studio ao catálogo real e preparar o contrato canônico de produtos.

## Prioridades
1. Manter fallback para `specificationData.ts`.
2. Criar camada `SpecificationRepository`.
3. Criar camada `CatalogRepository`.
4. Criar `SpecificationService`.
5. Validar obrigatoriedade de:
   - projectId
   - environmentId
   - canonicalProductId
   - materialId
   - supplierId
6. Não remover mocks até typecheck e navegação passarem.

## Fluxo
Render aprovado
→ objetos detectados
→ Specification Studio
→ Catálogo real
→ canonicalProductId
→ Budget
