# Checklist 019C

- [ ] Importar SpecificationRepository
- [ ] Importar CatalogRepository
- [ ] Criar fallback seguro para dados mockados
- [ ] Validar canonicalProductId
- [ ] Validar materialId
- [ ] Validar supplierId
- [ ] Rodar pnpm typecheck
- [ ] Testar Specification Studio
- [ ] Entregar pendências para Sprint 019D
