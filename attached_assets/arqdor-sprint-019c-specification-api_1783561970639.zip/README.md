# Sprint 019C — Specification Studio API Integration

## Objetivo
Conectar o Specification Studio ao catálogo real e preparar o contrato de dados para Budget, Procurement e Marketplace.

## Entregas
- SpecificationRepository
- CatalogRepository
- SpecificationService
- CanonicalProductContract
- Plano de migração
- Checklist de validação

## Integração sugerida
Importar service onde o Specification Studio carrega dados:

```ts
import { SpecificationService } from "./integration-hub/specification-api/SpecificationService";
```

## Regras
- Não alterar backend.
- Não remover fallback mock ainda.
- Não quebrar telas existentes.
- Rodar `pnpm typecheck`.
