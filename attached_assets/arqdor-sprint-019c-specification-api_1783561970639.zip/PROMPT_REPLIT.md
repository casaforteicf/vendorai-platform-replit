Aplicar Sprint 019C — Specification Studio API Integration.

Objetivo:
Conectar Specification Studio ao catálogo/API real com fallback seguro.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-hub/specification-api

2. Criar integração gradual:
- SpecificationRepository para /arch/specification ou rota equivalente existente.
- CatalogRepository para /arch/catalogo.
- SpecificationService como camada de orquestração.

3. Não remover specificationData.ts ainda.
Usar fallback:
- tenta API real;
- se falhar, usa dados mockados atuais.

4. Validar contrato:
- projectId
- environmentId
- canonicalProductId
- materialId
- supplierId
- quantity
- unit

5. Se /arch/specification não existir no backend:
- não criar backend;
- usar adapter documentado;
- manter fallback;
- registrar pendência para 019D/Backend.

6. Rodar:
pnpm typecheck

Entregar:
- typecheck;
- arquivos alterados;
- onde fallback foi mantido;
- APIs encontradas;
- APIs ausentes;
- pendências para 019D.
