# Changelog — Sprint 011

- Executive Budget Studio completo.
- Dashboard financeiro.
- Itens orçamentários.
- Planilha executiva.
- Disciplinas, fornecedores, curva ABC, versões, proposta e IA.
