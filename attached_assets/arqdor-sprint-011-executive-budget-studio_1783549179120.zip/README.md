# Sprint 011 — Executive Budget Studio

Módulo completo de orçamento executivo.

## Integração
Importar no ArqWorkspace:

```tsx
import ExecutiveBudgetStudio from './executive-budget-studio/ExecutiveBudgetStudio';
```

Usar case:
```tsx
case 'orcamento':
case 'budget':
case 'executive-budget':
  return <ExecutiveBudgetStudio arqState={arqState} onNavigate={handleNavigate} />;
```
