Aplicar Sprint 011 — Executive Budget Studio.

1. Copiar pasta:
artifacts/frontend/src/modules/arqdor/workspace/executive-budget-studio

2. Integrar no ArqWorkspace com case orcamento/budget.
3. Não alterar backend, banco, hooks ou rotas públicas.
4. Rodar pnpm typecheck.
