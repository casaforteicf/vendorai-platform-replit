Aplicar Sprint 010 — Production Studio Enterprise.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/production-studio

2. Integrar em ArqWorkspace:
import ProductionStudio from "./production-studio/ProductionStudio";

3. Usar em case seguro:
case "office":
case "production":
case "producao":
  return <ProductionStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Production Studio;
- resultado typecheck.
