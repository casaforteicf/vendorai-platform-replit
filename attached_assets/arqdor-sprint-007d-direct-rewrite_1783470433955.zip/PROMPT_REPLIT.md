Aplicar Sprint 007D — Direct Rewrite.

1. Substituir exatamente estes arquivos:
- artifacts/frontend/src/modules/arqdor/workspace/project-experience/ProjectHomeV2.tsx
- artifacts/frontend/src/modules/arqdor/workspace/smart-render-engine/SmartRenderEngine.tsx

2. Não criar novos componentes paralelos.
3. Não criar case novo.
4. Não alterar ArqWorkspace.tsx.
5. Não alterar backend.
6. Não alterar banco.
7. Não alterar Core Vendor.ai.
8. Não alterar rotas.
9. Não alterar useArqProject.ts.

Rodar:
- pnpm typecheck
- pnpm build

Corrigir somente tipagem/imports se necessário.

Entregar:
- confirmação dos dois arquivos substituídos;
- resultado typecheck;
- resultado build;
- print da Home;
- print do Smart Render Engine.
