# Changelog — Sprint 007D

## Alterado
- ProjectHomeV2 reescrito para mostrar ARQDOR como workspace operacional:
  - AI Architect visível.
  - AI Score.
  - fluxo Design → Documentação → Produção → Orçamento.
  - história do projeto.
  - projetos recentes com cards mais ricos.

- SmartRenderEngine reescrito para experiência de Studio:
  - render protagonista.
  - painel IA / Objeto / Custos.
  - timeline visual de versões.
  - ações de especificação, produção e orçamento.
