# Sprint 007D — Direct Rewrite

## Objetivo
Substituir diretamente os arquivos que já estão sendo renderizados, sem criar componentes paralelos.

## Arquivos substituídos
- `artifacts/frontend/src/modules/arqdor/workspace/project-experience/ProjectHomeV2.tsx`
- `artifacts/frontend/src/modules/arqdor/workspace/smart-render-engine/SmartRenderEngine.tsx`

## Por que este patch existe
As Sprints anteriores criaram componentes novos, mas a tela continuou antiga porque o Workspace ainda renderizava os arquivos originais.

Este patch substitui diretamente os arquivos reais em uso.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts
- ArqWorkspace.tsx

## Validação
- Abrir `/arch/render` e verificar a Home.
- Clicar em Renderização/renders e verificar o Smart Render Engine.
- Rodar `pnpm typecheck`.
- Rodar `pnpm build`.
