# Sprint 001 — ProjectHomeV2

## Arquivo novo

Criar:

`artifacts/frontend/src/modules/arqdor/workspace/project-experience/ProjectHomeV2.tsx`

## Alteração única

Em:

`artifacts/frontend/src/modules/arqdor/workspace/ArqWorkspace.tsx`

Adicionar import:

```tsx
import ProjectHomeV2 from "./project-experience/ProjectHomeV2";
```

Trocar apenas o `case 'home'`.

De:

```tsx
return <InstantRenderZone arqState={arqState} onNavigate={handleNavigate} />;
```

Para:

```tsx
return <ProjectHomeV2 arqState={arqState} onNavigate={handleNavigate} />;
```

Se a função de navegação tiver outro nome, usar a mesma que já era enviada para `InstantRenderZone`.

## Não alterar

- Backend
- Banco de dados
- Rotas
- Core Vendor.ai
- useArqProject.ts
- CRM
- Financeiro
- WhatsApp
- Instagram

## Validação

Rodar:

```bash
pnpm check
pnpm build
```
