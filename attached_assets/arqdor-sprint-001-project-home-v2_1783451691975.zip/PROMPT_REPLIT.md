Aplicar Sprint 001 — ProjectHomeV2.

Regras:
1. Criar o arquivo ProjectHomeV2.tsx no caminho informado.
2. Alterar somente ArqWorkspace.tsx para importar e usar ProjectHomeV2 no case home.
3. Não alterar backend.
4. Não alterar banco.
5. Não alterar Core Vendor.ai.
6. Não alterar rotas.
7. Não alterar useArqProject.ts.
8. Rodar pnpm check e pnpm build.
9. Corrigir apenas erros de import/tipagem se aparecerem.
10. Entregar lista de arquivos alterados e resultado do build.
