# Sprint 006 — Production Studio

## Objetivo
Criar o Production Studio do ARQDOR.ai, preparando o projeto para produção com fornecedores locais, fabricantes parceiros e modo híbrido.

## Arquivos incluídos
- ProductionStudio.tsx
- ProductionStudioContext.tsx
- ProductionHeader.tsx
- ProductionSidebar.tsx
- ProductionCanvas.tsx
- SupplierCard.tsx
- CompatibilityPanel.tsx
- QuoteRequestPanel.tsx
- productionData.ts

## Integração sugerida
Em `ArqWorkspace.tsx`, importar:

```tsx
import ProductionStudio from "./production-studio/ProductionStudio";
```

Plugar em um case seguro:

```tsx
return <ProductionStudio arqState={arqState} onNavigate={handleNavigate} />;
```

Pode ser no case `producao`, `production`, ou equivalente existente.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts

## Validação
- pnpm check
- pnpm build
