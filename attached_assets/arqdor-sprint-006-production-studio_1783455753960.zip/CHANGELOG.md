# Changelog — Sprint 006

## Adicionado
- Production Studio.
- Modo prestador local.
- Modo fabricante parceiro.
- Modo híbrido.
- Compatibilização inicial.
- Lista de fornecedores por disciplina.
- Preparação para solicitação de orçamento.
