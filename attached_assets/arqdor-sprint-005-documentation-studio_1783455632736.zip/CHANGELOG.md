# Changelog — Sprint 005

## Adicionado
- Documentation Studio.
- Cadernos técnicos por disciplina.
- Seleção de documentos para impressão.
- Memorial editor assistido.
- Tabela de quantitativos.
- Prévia técnica de planta/vistas.
