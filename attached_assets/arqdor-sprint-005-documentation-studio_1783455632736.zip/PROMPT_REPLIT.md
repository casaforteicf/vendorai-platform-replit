Aplicar Sprint 005 — Documentation Studio.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/documentation-studio

2. Em ArqWorkspace.tsx:
- importar DocumentationStudio;
- plugar em um case seguro de documentacao/especificacao;
- manter outros módulos intactos.

3. Não alterar backend.
4. Não alterar banco.
5. Não alterar Core Vendor.ai.
6. Não alterar rotas.
7. Não alterar useArqProject.ts.

Rodar:
- pnpm check
- pnpm build

Corrigir somente imports/tipagens se necessário.

Entregar:
- arquivos copiados;
- arquivo alterado para integração;
- resultado typecheck;
- resultado build.
