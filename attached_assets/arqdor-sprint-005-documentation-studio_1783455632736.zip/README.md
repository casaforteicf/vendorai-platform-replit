# Sprint 005 — Documentation Studio

## Objetivo
Criar o Documentation Studio do ARQDOR.ai, com cadernos técnicos por disciplina.

## Arquivos incluídos
- DocumentationStudio.tsx
- DocumentationStudioContext.tsx
- DocumentationHeader.tsx
- DisciplineSidebar.tsx
- DocumentationCanvas.tsx
- DocumentItemCard.tsx
- TechnicalPreview.tsx
- MemorialEditor.tsx
- QuantityTable.tsx
- PrintSelector.tsx
- documentationData.ts

## Integração sugerida
Em `ArqWorkspace.tsx`, importar:

```tsx
import DocumentationStudio from "./documentation-studio/DocumentationStudio";
```

Plugar em um case seguro:

```tsx
return <DocumentationStudio arqState={arqState} onNavigate={handleNavigate} />;
```

Pode ser no case `documentacao`, `especificacao`, ou equivalente existente.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts

## Validação
- pnpm check
- pnpm build
