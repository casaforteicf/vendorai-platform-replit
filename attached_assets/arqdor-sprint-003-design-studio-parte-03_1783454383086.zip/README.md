# Sprint 003 — Design Studio — Parte 03

## Objetivo
Adicionar o painel de IA contextual do Design Studio.

## Arquivos novos
- AIChatPanel.tsx
- PromptHistory.tsx
- QuickActions.tsx
- AISuggestions.tsx

## Integração
Em `DesignStudio.tsx`:

1. Importar:
```tsx
import { AIChatPanel } from "./AIChatPanel";
```

2. Substituir o painel direito atual pelo componente:
```tsx
<AIChatPanel
  projectTitle={getTitle(project)}
  environmentName={getEnvironment(project)}
  onClose={() => setRightPanelOpen(false)}
/>
```

Se `setRightPanelOpen` estiver disponível apenas dentro de `RightPanel`, manter o painel atual e apenas usar o `AIChatPanel` dentro dele.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts

## Validar
- pnpm check
- pnpm build
