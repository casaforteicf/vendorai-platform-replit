Aplicar Sprint 003 — Design Studio — Parte 03.

1. Copiar os arquivos para:
artifacts/frontend/src/modules/arqdor/workspace/design-studio

2. Em DesignStudio.tsx:
- importar AIChatPanel;
- substituir o conteúdo do painel direito atual pelo AIChatPanel;
- preservar a abertura/fechamento do painel direito.

3. Não alterar backend.
4. Não alterar banco.
5. Não alterar Core Vendor.ai.
6. Não alterar rotas.
7. Não alterar useArqProject.ts.

Rodar:
- pnpm check
- pnpm build

Corrigir somente imports/tipagem se necessário.
