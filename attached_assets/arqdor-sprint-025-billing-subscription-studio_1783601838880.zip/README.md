# Sprint 025 — Billing & Subscription Studio

## Objetivo
Criar o módulo de billing e assinaturas do ARQDOR.ai para sustentar o modelo SaaS.

Este módulo organiza:
- planos comerciais;
- contas assinantes;
- faturas;
- pagamentos;
- uso por tenant;
- comissões;
- contratos;
- régua de cobrança;
- reconhecimento de receita.

## Arquivos incluídos
- BillingSubscriptionStudio.tsx
- BillingOverview.tsx
- PlansPanel.tsx
- BillingAccountsPanel.tsx
- InvoicesPanel.tsx
- PaymentsPanel.tsx
- UsageMeteringPanel.tsx
- CommissionsPanel.tsx
- ContractsPanel.tsx
- DunningPanel.tsx
- RevenueRecognitionPanel.tsx
- BillingMetricCard.tsx
- billingTypes.ts
- billingData.ts
- billingUtils.ts

## Integração no ArqWorkspace

Importar:

```tsx
import BillingSubscriptionStudio from "./billing-subscription-studio/BillingSubscriptionStudio";
```

Adicionar case:

```tsx
case "billing":
case "subscriptions":
case "billing-subscription":
  return <BillingSubscriptionStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Observação
Este pacote não altera backend, banco ou autenticação.
Ele entrega a central SaaS financeira para cobrança, assinaturas e receita.
