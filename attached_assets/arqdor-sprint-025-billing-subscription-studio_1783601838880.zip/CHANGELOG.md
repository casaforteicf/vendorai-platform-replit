# Changelog — Sprint 025 Billing & Subscription Studio

## Adicionado
- Central de billing SaaS do ARQDOR.ai.
- Planos comerciais.
- Contas assinantes.
- Faturas.
- Pagamentos.
- Medição de uso.
- Comissões.
- Contratos.
- Régua de cobrança.
- Reconhecimento de receita.

## Fora do escopo
- Backend.
- Banco.
- Gateway de pagamento real.
- Emissão fiscal real.
- Integração contábil.
