Aplicar Sprint 025 — Billing & Subscription Studio.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/billing-subscription-studio

2. Integrar no ArqWorkspace:
import BillingSubscriptionStudio from "./billing-subscription-studio/BillingSubscriptionStudio";

3. Adicionar case:
case "billing":
case "subscriptions":
case "billing-subscription":
  return <BillingSubscriptionStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar autenticação.
7. Não alterar outros nichos da Vendor.ai.
8. Manter isolamento em /arch/*.

Rodar:
pnpm typecheck

Validar UI:
- Visão
- Planos
- Contas
- Faturas
- Pagamentos
- Uso
- Comissões
- Contratos
- Cobrança
- Receita

Entregar:
- resultado do typecheck;
- print da tela Billing Operations;
- logs do workflow se houver erro.
