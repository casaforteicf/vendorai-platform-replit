# Changelog — Sprint 024 Revenue Operations Studio

## Adicionado
- Central Revenue Operations do ARQDOR.ai.
- Pipeline comercial.
- Agenda de demos.
- Propostas.
- Métricas de MRR e setup.
- Parcerias.
- Customer Success.
- Forecast.
- Playbook de conversão.

## Fora do escopo
- Backend.
- Banco.
- Integração real com CRM.
- Automação real de cobrança/faturamento.
