Aplicar Sprint 024 — Revenue Operations Studio.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/revenue-operations-studio

2. Integrar no ArqWorkspace:
import RevenueOperationsStudio from "./revenue-operations-studio/RevenueOperationsStudio";

3. Adicionar case:
case "revenue":
case "revops":
case "revenue-operations":
  return <RevenueOperationsStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar autenticação.
7. Não alterar outros nichos da Vendor.ai.
8. Manter isolamento em /arch/*.

Rodar:
pnpm typecheck

Validar UI:
- Visão
- Pipeline
- Demos
- Propostas
- MRR
- Parcerias
- Success
- Forecast
- Playbook

Entregar:
- resultado do typecheck;
- print da tela Revenue Operations;
- logs do workflow se houver erro.
