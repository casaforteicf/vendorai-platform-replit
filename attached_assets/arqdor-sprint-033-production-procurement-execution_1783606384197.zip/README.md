# Sprint 033 — Production, Procurement & Execution Flow

## Objetivo
Transformar aprovação do cliente em execução operacional.

Fluxo:

```text
Cliente aprovou
↓
Itens aprovados
↓
Ordens de produção
↓
Pedidos de compra / fornecedores
↓
Agenda de entrega e instalação
↓
Checklist de qualidade
↓
Conclusão / pós-venda
```

## Frontend
Pasta:

```text
artifacts/frontend/src/modules/arqdor/workspace/production-procurement-execution
```

Arquivos principais:

- `ProductionProcurementExecutionStudio.tsx`
- `useProductionExecution.ts`
- `productionApi.ts`
- `productionTypes.ts`
- `productionUtils.ts`
- `WorkOrdersBoard.tsx`
- `WorkOrderEditorPanel.tsx`
- `SupplierOrdersPanel.tsx`
- `InstallationSchedulePanel.tsx`
- `QualityChecklistPanel.tsx`
- `ExecutionTimelinePanel.tsx`
- `ProductionSummaryCards.tsx`

## Backend
Pasta:

```text
artifacts/server/modules/arch/production-procurement
```

Arquivos:

- `productionProcurement.routes.ts`
- `productionProcurement.service.ts`
- `productionProcurement.types.ts`

Migração:

```text
artifacts/server/migrations/2026_07_09_arch_production_procurement.sql
```

## Endpoints previstos

- `GET /arch/producao?projectId=:projectId`
- `POST /arch/producao/from-approval`
- `POST /arch/producao/work-orders`
- `PATCH /arch/producao/work-orders/:id`
- `POST /arch/producao/supplier-orders`
- `PATCH /arch/producao/supplier-orders/:id`

## Integração no ArqWorkspace

```tsx
import ProductionProcurementExecutionStudio from "./production-procurement-execution/ProductionProcurementExecutionStudio";
```

Adicionar case:

```tsx
case "production":
case "producao":
case "procurement":
case "execution":
case "production-procurement":
  return <ProductionProcurementExecutionStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Próximo passo
Após aplicar, a Sprint 034 deve fechar Pós-venda, termo de entrega, satisfação e oportunidades futuras.
