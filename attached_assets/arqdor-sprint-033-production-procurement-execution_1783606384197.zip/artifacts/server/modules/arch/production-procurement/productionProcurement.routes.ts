import { Router } from "express";
import {
  createOrdersFromApproval,
  createSupplierOrder,
  createWorkOrder,
  getProductionBundle,
  updateSupplierOrder,
  updateWorkOrder,
} from "./productionProcurement.service";

export function createProductionProcurementRouter(deps: { db: any }) {
  const router = Router();

  function tenantId(req: any) {
    return req?.tenant?.id || req?.user?.tenantId || req?.tenantId || null;
  }

  router.get("/arch/producao", async (req, res, next) => {
    try {
      const projectId = String(req.query.projectId || "");

      if (!projectId) {
        res.status(400).json({ error: "projectId é obrigatório" });
        return;
      }

      const result = await getProductionBundle(deps.db, {
        tenantId: tenantId(req),
        projectId,
      });

      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/producao/from-approval", async (req, res, next) => {
    try {
      const result = await createOrdersFromApproval(deps.db, tenantId(req), req.body);
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/producao/work-orders", async (req, res, next) => {
    try {
      const workOrder = await createWorkOrder(deps.db, tenantId(req), req.body);
      res.status(201).json({ workOrder });
    } catch (error) {
      next(error);
    }
  });

  router.patch("/arch/producao/work-orders/:id", async (req, res, next) => {
    try {
      const workOrder = await updateWorkOrder(deps.db, req.params.id, tenantId(req), req.body);

      if (!workOrder) {
        res.status(404).json({ error: "Ordem não encontrada" });
        return;
      }

      res.json({ workOrder });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/producao/supplier-orders", async (req, res, next) => {
    try {
      const supplierOrder = await createSupplierOrder(deps.db, tenantId(req), req.body);
      res.status(201).json({ supplierOrder });
    } catch (error) {
      next(error);
    }
  });

  router.patch("/arch/producao/supplier-orders/:id", async (req, res, next) => {
    try {
      const supplierOrder = await updateSupplierOrder(deps.db, req.params.id, tenantId(req), req.body);

      if (!supplierOrder) {
        res.status(404).json({ error: "Pedido de fornecedor não encontrado" });
        return;
      }

      res.json({ supplierOrder });
    } catch (error) {
      next(error);
    }
  });

  return router;
}
