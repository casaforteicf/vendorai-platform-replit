export type ProductionStatus =
  | "draft"
  | "planned"
  | "waiting-supplier"
  | "ordered"
  | "in-production"
  | "ready"
  | "scheduled"
  | "installed"
  | "completed"
  | "blocked"
  | "cancelled";

export type WorkOrderPayload = {
  projectId: string;
  proposalId?: string | null;
  proposalItemId?: string | null;
  budgetItemId?: string | null;
  specObjectId?: string | null;
  title: string;
  description?: string | null;
  type?: string;
  priority?: string;
  status?: ProductionStatus;
  item?: string | null;
  quantity?: number;
  unit?: string;
  materialName?: string | null;
  productName?: string | null;
  supplierName?: string | null;
  manufacturerName?: string | null;
  plannedStart?: string | null;
  plannedEnd?: string | null;
  estimatedCost?: number;
  actualCost?: number;
  notes?: string | null;
};

export type SupplierOrderPayload = {
  projectId: string;
  workOrderId?: string | null;
  supplierName: string;
  contactName?: string | null;
  contactPhone?: string | null;
  contactEmail?: string | null;
  item: string;
  quantity?: number;
  unit?: string;
  estimatedValue?: number;
  confirmedValue?: number;
  status?: string;
  expectedDelivery?: string | null;
  notes?: string | null;
};
