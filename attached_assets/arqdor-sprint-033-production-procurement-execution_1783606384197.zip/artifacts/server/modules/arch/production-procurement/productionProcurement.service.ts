import type { SupplierOrderPayload, WorkOrderPayload } from "./productionProcurement.types";

async function addEvent(db: any, projectId: string, workOrderId: string | null, type: string, message: string, actorType = "system", metadata: any = {}) {
  await db.query(
    `
    insert into arch_execution_events (
      id, project_id, work_order_id, type, message, actor_type, metadata, created_at
    ) values ($1,$2,$3,$4,$5,$6,$7,now())
    `,
    [crypto.randomUUID(), projectId, workOrderId, type, message, actorType, JSON.stringify(metadata || {})],
  );
}

export async function getProductionBundle(db: any, params: { tenantId?: string | null; projectId: string }) {
  const values: any[] = [params.projectId];
  let tenantWhere = "";

  if (params.tenantId) {
    values.push(params.tenantId);
    tenantWhere = ` and tenant_id = $${values.length}`;
  }

  const workOrders = await db.query(
    `select * from arch_work_orders where project_id = $1 ${tenantWhere} and deleted_at is null order by created_at desc`,
    values,
  );

  const supplierOrders = await db.query(
    `select * from arch_supplier_orders where project_id = $1 ${tenantWhere} and deleted_at is null order by created_at desc`,
    values,
  );

  const installationTasks = await db.query(
    `select * from arch_installation_tasks where project_id = $1 ${tenantWhere} order by scheduled_date asc nulls last`,
    values,
  );

  const qualityChecks = await db.query(
    `select * from arch_quality_checks where project_id = $1 ${tenantWhere} order by created_at desc`,
    values,
  );

  const events = await db.query(
    `select * from arch_execution_events where project_id = $1 order by created_at desc limit 80`,
    [params.projectId],
  );

  return {
    workOrders: workOrders.rows,
    supplierOrders: supplierOrders.rows,
    installationTasks: installationTasks.rows,
    qualityChecks: qualityChecks.rows,
    events: events.rows,
  };
}

export async function createWorkOrder(db: any, tenantId: string | null, payload: WorkOrderPayload) {
  const id = crypto.randomUUID();

  const result = await db.query(
    `
    insert into arch_work_orders (
      id, tenant_id, project_id, proposal_id, proposal_item_id, budget_item_id, spec_object_id,
      title, description, type, priority, status,
      item, quantity, unit, material_name, product_name, supplier_name, manufacturer_name,
      planned_start, planned_end, estimated_cost, actual_cost, notes, created_at, updated_at
    ) values (
      $1,$2,$3,$4,$5,$6,$7,
      $8,$9,$10,$11,$12,
      $13,$14,$15,$16,$17,$18,$19,
      $20,$21,$22,$23,$24,now(),now()
    )
    returning *
    `,
    [
      id,
      tenantId,
      payload.projectId,
      payload.proposalId || null,
      payload.proposalItemId || null,
      payload.budgetItemId || null,
      payload.specObjectId || null,
      payload.title,
      payload.description || null,
      payload.type || "production",
      payload.priority || "medium",
      payload.status || "planned",
      payload.item || null,
      Number(payload.quantity || 1),
      payload.unit || "un",
      payload.materialName || null,
      payload.productName || null,
      payload.supplierName || null,
      payload.manufacturerName || null,
      payload.plannedStart || null,
      payload.plannedEnd || null,
      Number(payload.estimatedCost || 0),
      Number(payload.actualCost || 0),
      payload.notes || null,
    ],
  );

  await addEvent(db, payload.projectId, id, "created", "Ordem de execução criada.", "internal", { title: payload.title });
  return result.rows[0];
}

export async function updateWorkOrder(db: any, id: string, tenantId: string | null, payload: Partial<WorkOrderPayload>) {
  const currentResult = await db.query(`select * from arch_work_orders where id = $1`, [id]);
  const current = currentResult.rows[0];

  if (!current) return null;

  const allowed = {
    title: "title",
    description: "description",
    type: "type",
    priority: "priority",
    status: "status",
    item: "item",
    quantity: "quantity",
    unit: "unit",
    materialName: "material_name",
    productName: "product_name",
    supplierName: "supplier_name",
    manufacturerName: "manufacturer_name",
    plannedStart: "planned_start",
    plannedEnd: "planned_end",
    actualStart: "actual_start",
    actualEnd: "actual_end",
    estimatedCost: "estimated_cost",
    actualCost: "actual_cost",
    notes: "notes",
  } as const;

  const sets: string[] = [];
  const values: any[] = [];

  Object.entries(allowed).forEach(([key, column]) => {
    if ((payload as any)[key] === undefined) return;
    values.push((payload as any)[key]);
    sets.push(`${column} = $${values.length}`);
  });

  values.push(new Date());
  sets.push(`updated_at = $${values.length}`);

  values.push(id);
  let where = `id = $${values.length}`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  const result = await db.query(
    `update arch_work_orders set ${sets.join(", ")} where ${where} returning *`,
    values,
  );

  if (payload.status && payload.status !== current.status) {
    await addEvent(db, current.project_id, id, "status-change", `Status alterado para ${payload.status}.`, "internal", {
      from: current.status,
      to: payload.status,
    });
  }

  return result.rows[0];
}

export async function createSupplierOrder(db: any, tenantId: string | null, payload: SupplierOrderPayload) {
  const id = crypto.randomUUID();

  const result = await db.query(
    `
    insert into arch_supplier_orders (
      id, tenant_id, project_id, work_order_id,
      supplier_name, contact_name, contact_phone, contact_email,
      item, quantity, unit, estimated_value, confirmed_value,
      status, requested_at, expected_delivery, notes, created_at, updated_at
    ) values (
      $1,$2,$3,$4,
      $5,$6,$7,$8,
      $9,$10,$11,$12,$13,
      $14,now(),$15,$16,now(),now()
    )
    returning *
    `,
    [
      id,
      tenantId,
      payload.projectId,
      payload.workOrderId || null,
      payload.supplierName,
      payload.contactName || null,
      payload.contactPhone || null,
      payload.contactEmail || null,
      payload.item,
      Number(payload.quantity || 1),
      payload.unit || "un",
      Number(payload.estimatedValue || 0),
      Number(payload.confirmedValue || 0),
      payload.status || "quote-requested",
      payload.expectedDelivery || null,
      payload.notes || null,
    ],
  );

  await addEvent(db, payload.projectId, payload.workOrderId || null, "supplier-request", "Pedido/cotação enviado ao fornecedor.", "internal", {
    supplierName: payload.supplierName,
    item: payload.item,
  });

  return result.rows[0];
}

export async function updateSupplierOrder(db: any, id: string, tenantId: string | null, payload: Partial<SupplierOrderPayload>) {
  const currentResult = await db.query(`select * from arch_supplier_orders where id = $1`, [id]);
  const current = currentResult.rows[0];

  if (!current) return null;

  const allowed = {
    supplierName: "supplier_name",
    contactName: "contact_name",
    contactPhone: "contact_phone",
    contactEmail: "contact_email",
    item: "item",
    quantity: "quantity",
    unit: "unit",
    estimatedValue: "estimated_value",
    confirmedValue: "confirmed_value",
    status: "status",
    expectedDelivery: "expected_delivery",
    deliveredAt: "delivered_at",
    notes: "notes",
  } as const;

  const sets: string[] = [];
  const values: any[] = [];

  Object.entries(allowed).forEach(([key, column]) => {
    if ((payload as any)[key] === undefined) return;
    values.push((payload as any)[key]);
    sets.push(`${column} = $${values.length}`);
  });

  values.push(new Date());
  sets.push(`updated_at = $${values.length}`);

  values.push(id);
  let where = `id = $${values.length}`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  const result = await db.query(
    `update arch_supplier_orders set ${sets.join(", ")} where ${where} returning *`,
    values,
  );

  if (payload.status && payload.status !== current.status) {
    await addEvent(db, current.project_id, current.work_order_id || null, "supplier-delivery", `Fornecedor atualizado para ${payload.status}.`, "internal", {
      supplierOrderId: id,
      from: current.status,
      to: payload.status,
    });
  }

  return result.rows[0];
}

export async function createOrdersFromApproval(db: any, tenantId: string | null, payload: {
  projectId: string;
  proposalId: string;
  onlyApprovedItems?: boolean;
}) {
  const values: any[] = [payload.proposalId];

  let where = `proposal_id = $1`;
  if (payload.onlyApprovedItems) {
    where += ` and approval_status = 'approved'`;
  }

  const proposalItems = await db.query(
    `select * from arch_proposal_items where ${where} order by sort_order asc, created_at asc`,
    values,
  );

  for (const item of proposalItems.rows) {
    const exists = await db.query(
      `select id from arch_work_orders where proposal_item_id = $1 and deleted_at is null limit 1`,
      [item.id],
    );

    if (exists.rows[0]) continue;

    await createWorkOrder(db, tenantId, {
      projectId: payload.projectId,
      proposalId: payload.proposalId,
      proposalItemId: item.id,
      budgetItemId: item.budget_item_id || null,
      specObjectId: item.spec_object_id || null,
      title: `Executar: ${item.item}`,
      description: item.description || null,
      type: "production",
      priority: "medium",
      status: "planned",
      item: item.item,
      quantity: Number(item.quantity || 1),
      unit: item.unit || "un",
      estimatedCost: Number(item.total || 0),
      actualCost: 0,
      notes: "Criado automaticamente a partir da aprovação do cliente.",
    });
  }

  await addEvent(db, payload.projectId, null, "created", "Ordens geradas a partir da aprovação do cliente.", "system", {
    proposalId: payload.proposalId,
  });

  return getProductionBundle(db, { tenantId, projectId: payload.projectId });
}
