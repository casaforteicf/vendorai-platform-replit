-- Sprint 033 — Production, Procurement & Execution Flow
-- Ajustar schema e RLS conforme padrão real do projeto.

create table if not exists arch_work_orders (
  id uuid primary key,
  tenant_id uuid null,
  project_id uuid not null,
  proposal_id uuid null,
  proposal_item_id uuid null,
  budget_item_id uuid null,
  spec_object_id uuid null,

  title text not null,
  description text null,
  type text not null default 'production',
  priority text not null default 'medium',
  status text not null default 'planned',

  item text null,
  quantity numeric not null default 1,
  unit text not null default 'un',
  material_name text null,
  product_name text null,
  supplier_name text null,
  manufacturer_name text null,

  planned_start date null,
  planned_end date null,
  actual_start timestamptz null,
  actual_end timestamptz null,

  estimated_cost numeric not null default 0,
  actual_cost numeric not null default 0,
  notes text null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists arch_supplier_orders (
  id uuid primary key,
  tenant_id uuid null,
  project_id uuid not null,
  work_order_id uuid null,

  supplier_name text not null,
  contact_name text null,
  contact_phone text null,
  contact_email text null,

  item text not null,
  quantity numeric not null default 1,
  unit text not null default 'un',

  estimated_value numeric not null default 0,
  confirmed_value numeric not null default 0,

  status text not null default 'not-requested',
  requested_at timestamptz null,
  expected_delivery date null,
  delivered_at timestamptz null,

  notes text null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists arch_installation_tasks (
  id uuid primary key,
  tenant_id uuid null,
  project_id uuid not null,
  work_order_id uuid null,

  title text not null,
  team text null,
  location text null,
  scheduled_date date null,
  duration_hours numeric not null default 1,
  status text not null default 'planned',
  checklist jsonb not null default '[]'::jsonb,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists arch_quality_checks (
  id uuid primary key,
  tenant_id uuid null,
  project_id uuid not null,
  work_order_id uuid null,

  title text not null,
  status text not null default 'pending',
  responsible text null,
  notes text null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists arch_execution_events (
  id uuid primary key,
  project_id uuid not null,
  work_order_id uuid null,

  type text not null,
  message text not null,
  actor_type text not null default 'system',
  actor_name text null,
  metadata jsonb not null default '{}'::jsonb,

  created_at timestamptz not null default now()
);

create index if not exists idx_arch_work_orders_tenant on arch_work_orders (tenant_id);
create index if not exists idx_arch_work_orders_project on arch_work_orders (project_id);
create index if not exists idx_arch_work_orders_proposal on arch_work_orders (proposal_id);
create index if not exists idx_arch_work_orders_status on arch_work_orders (status);

create index if not exists idx_arch_supplier_orders_tenant on arch_supplier_orders (tenant_id);
create index if not exists idx_arch_supplier_orders_project on arch_supplier_orders (project_id);
create index if not exists idx_arch_supplier_orders_work_order on arch_supplier_orders (work_order_id);
create index if not exists idx_arch_supplier_orders_status on arch_supplier_orders (status);

create index if not exists idx_arch_installation_tasks_project on arch_installation_tasks (project_id);
create index if not exists idx_arch_quality_checks_project on arch_quality_checks (project_id);
create index if not exists idx_arch_execution_events_project on arch_execution_events (project_id);

-- Se o projeto usa Supabase RLS:
-- alter table arch_work_orders enable row level security;
-- alter table arch_supplier_orders enable row level security;
-- alter table arch_installation_tasks enable row level security;
-- alter table arch_quality_checks enable row level security;
