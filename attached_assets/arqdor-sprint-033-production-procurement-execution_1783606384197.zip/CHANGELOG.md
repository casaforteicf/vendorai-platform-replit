# Changelog — Sprint 033 Production, Procurement & Execution Flow

## Adicionado
- ProductionProcurementExecutionStudio.
- Hook `useProductionExecution`.
- API client de produção/compras.
- Kanban de ordens.
- Editor de ordem.
- Pedidos de fornecedor.
- Agenda de instalação.
- Checklist de qualidade.
- Timeline de execução.
- Backend adapter para produção/compras.
- Migração base para ordens, fornecedores, instalação, qualidade e eventos.

## Resolvido
- Aprovação do cliente pode virar ordem operacional.
- Itens aprovados entram em produção/compras.
- Fornecedores e prazos podem ser acompanhados.
- Execução fica registrada em timeline.

## Fora do escopo
- Pós-venda.
- Financeiro/faturamento real.
- Marketplace transacional.
- App de equipe de campo.
