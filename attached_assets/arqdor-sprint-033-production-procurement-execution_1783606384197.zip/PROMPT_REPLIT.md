Aplicar Sprint 033 — Production, Procurement & Execution Flow.

Contexto:
A Sprint 032 criou proposta pública com aprovação do cliente.
Agora precisamos transformar a aprovação em ordens reais de produção, compras, instalação e qualidade.

Objetivo:
1. Criar ordens de produção a partir dos itens aprovados da proposta.
2. Criar painel Kanban de execução.
3. Criar pedidos de fornecedores/compras.
4. Registrar prazos planejados e reais.
5. Criar agenda de instalação/entrega.
6. Criar checklist de qualidade.
7. Registrar timeline de eventos.
8. Preparar fluxo para pós-venda.

Frontend:
Copiar:
artifacts/frontend/src/modules/arqdor/workspace/production-procurement-execution

Integrar:
import ProductionProcurementExecutionStudio from "./production-procurement-execution/ProductionProcurementExecutionStudio";

Adicionar case:
case "production":
case "producao":
case "procurement":
case "execution":
case "production-procurement":
  return <ProductionProcurementExecutionStudio arqState={arqState} onNavigate={handleNavigate} />;

Backend:
Avaliar estrutura real do servidor.
Se compatível, copiar/adaptar:
artifacts/server/modules/arch/production-procurement

Registrar router:
createProductionProcurementRouter({ db })

Endpoints:
GET /arch/producao?projectId=:projectId
POST /arch/producao/from-approval
POST /arch/producao/work-orders
PATCH /arch/producao/work-orders/:id
POST /arch/producao/supplier-orders
PATCH /arch/producao/supplier-orders/:id

Banco:
Usar migração:
artifacts/server/migrations/2026_07_09_arch_production_procurement.sql

Se usa Drizzle/RLS/Supabase:
- adaptar ao padrão existente;
- manter tenant_id;
- garantir isolamento por tenant;
- não quebrar tabelas existentes.

Validações:
1. Gerar ordens da aprovação.
2. Somente itens aprovados viram ordem quando onlyApprovedItems=true.
3. Kanban mostra ordens por status.
4. Alterar status salva no backend.
5. Criar ordem manual salva.
6. Criar pedido de fornecedor salva.
7. Alterar status do fornecedor salva.
8. Timeline registra eventos.
9. Typecheck limpo.

Não alterar:
- outros nichos da Vendor.ai;
- autenticação global;
- rotas fora de /arch/*;
- billing;
- marketplace.

Se algum endpoint ou estrutura não existir:
- manter typecheck limpo;
- não inventar mock silencioso;
- retornar erro objetivo;
- informar arquivo/linha para registro de router ou migration.
