# Sprint 039 — Render Functional Hardening

## Corrigido
- `applyMelhoria()` agora envia `ajuste_prompt` para o backend.
- `applyMelhoria()` agora aguarda o job assíncrono concluir antes de criar nova versão.
- Histórico de versões só recebe imagem nova real.
- `startRender()` envia `project_id`.
- Envio para especificação usa endpoint existente `/api/arch/specification/analyze`.
- Backend ganhou `POST /api/arch/ai-render/:id/approve`.

## Mantido
- Fluxo linear original.
- Tela simples de render.
- Preservação do projeto.
- `createNewVersion`, `preserveGeometry` e `preserveCamera` no fluxo de ajuste.
- Tema e layout atual.

## Fora do escopo
- Redesign visual.
- CAD.
- Sidebar.
- Marketplace.
- Produção.
- Orçamento.
