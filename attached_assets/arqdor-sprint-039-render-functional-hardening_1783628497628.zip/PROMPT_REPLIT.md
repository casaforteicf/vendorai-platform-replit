Aplicar Sprint 039 — Render Functional Hardening sobre os arquivos atuais.

Contexto:
O ZIP atual mostrou que /arch/render já foi resetado parcialmente para fluxo linear, mas ainda havia 3 problemas técnicos:

1. A melhoria pós-render chamava /adjust mas não enviava `ajuste_prompt`, então o backend não recebia a instrução real.
2. A melhoria pós-render não fazia polling do job assíncrono; criava versão visual antes da imagem nova existir.
3. A etapa de especificação chamava endpoint inexistente `/api/arch/ai-render/:id/send-to-specification`.
4. O endpoint de aprovação `/api/arch/ai-render/:id/approve` não existia no backend.

Aplicar os dois arquivos deste pacote:

- artifacts/frontend/src/pages/arch/RenderStudioPage.tsx
- artifacts/api-server/src/routes/arch_ai_render.ts

O que muda:

Frontend:
- Gerar render agora envia `project_id`.
- Gerar render usa helper `waitForRenderCompletion`.
- Melhoria / material / iluminação envia `ajuste_prompt`.
- Melhoria / material / iluminação faz polling até status `concluido`.
- Nova versão só entra no histórico quando a imagem nova realmente existe.
- Enviar para especificação usa endpoint existente:
  `POST /api/arch/specification/analyze`
- Botão final volta para `/arch/projetos/:id`, rota existente.

Backend:
- Adiciona:
  `POST /api/arch/ai-render/:id/approve`
- Aprovação valida tenant e status concluído.
- Marca `versionTag` como `aprovado`.

Não alterar layout agora.
Não recriar CAD.
Não criar sidebar nova.
Não mexer em App.tsx.
Não mexer em ArqdorPage/ArqWorkspace.
Não mexer em tema.

Validar:
1. pnpm typecheck
2. /arch/render abre
3. selecionar projeto
4. ambiente
5. imagem
6. gerar render
7. aguardar concluir
8. aplicar melhoria
9. confirmar nova versão com imagem nova
10. alterar material
11. confirmar nova versão com imagem nova
12. aprovar render
13. gerar especificação
14. verificar console/backend logs
