# Sprint 039 — Render Functional Hardening

Este patch foi gerado em cima dos arquivos atuais enviados no ZIP `arqdor-current-render-files.zip`.

## Diagnóstico do ZIP

O `/arch/render` já está parcialmente resetado para o fluxo original, mas ainda havia falhas funcionais:

- Melhoria não enviava `ajuste_prompt`.
- Melhoria não aguardava render assíncrono concluir.
- Enviar para especificação chamava endpoint inexistente.
- Aprovar render chamava endpoint inexistente.
- Nova versão podia usar a imagem antiga por fallback.

## Arquivos incluídos

```text
artifacts/frontend/src/pages/arch/RenderStudioPage.tsx
artifacts/api-server/src/routes/arch_ai_render.ts
```

## Como aplicar

Substituir os arquivos atuais pelos arquivos deste pacote.

Depois rodar:

```bash
pnpm typecheck
```

## Critérios de aceite

- Gerar render chama `/api/arch/ai-render`.
- Melhoria chama `/api/arch/ai-render/:id/adjust`.
- Melhoria aguarda status `concluido`.
- Alteração de material gera imagem nova.
- Original permanece no histórico.
- Aprovar chama `/api/arch/ai-render/:id/approve`.
- Especificação chama `/api/arch/specification/analyze`.
