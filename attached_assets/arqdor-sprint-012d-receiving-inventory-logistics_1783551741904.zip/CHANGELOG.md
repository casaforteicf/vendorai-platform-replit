# Changelog — Sprint 012D

## Adicionado
- ReceivingInventoryStudio.
- Recebimento.
- Inspector de recebimento.
- Estoque.
- Warehouse.
- Logística.
- Tracking.
- AI Receiving.
