Aplicar Sprint 012D — Receiving, Inventory & Logistics.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/procurement-studio/receiving-inventory

2. Integrar em ProcurementStudio:
import ReceivingInventoryStudio from "./receiving-inventory/ReceivingInventoryStudio";

3. Nos views/cases receiving, inventory e logistics, renderizar:
return <ReceivingInventoryStudio onNavigate={onNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print da tela de Recebimento/Estoque/Logística;
- resultado typecheck.
