Aplicar Sprint 017B — Data Sync + API Connector + Event Bus.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-hub/data-sync

2. Integrar em ArqWorkspace ou IntegrationHub:
import DataSyncCenter from "./integration-hub/data-sync/DataSyncCenter";

3. Usar em case seguro:
case "data-sync":
case "api-connectors":
case "event-bus":
  return <DataSyncCenter onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Data Sync Center;
- resultado typecheck.
