Aplicar Sprint 021 — Release Candidate.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/release-candidate

2. Integrar no ArqWorkspace:
import ReleaseCandidateCenter from "./release-candidate/ReleaseCandidateCenter";

3. Adicionar case:
case "release":
case "release-candidate":
case "rc":
  return <ReleaseCandidateCenter arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar autenticação.
7. Não alterar outros nichos da Vendor.ai.
8. Manter isolamento em /arch/*.

Rodar:
pnpm typecheck

Validar UI:
- Visão
- Módulos
- QA
- Bugs
- Integrações
- Segurança
- Performance
- Lançamento
- Gates

Entregar:
- resultado do typecheck;
- print da tela Release Candidate;
- logs do workflow se houver erro.
