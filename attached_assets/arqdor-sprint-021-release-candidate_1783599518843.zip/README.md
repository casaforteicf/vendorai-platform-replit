# Sprint 021 — Release Candidate

## Objetivo
Criar o centro de controle do Release Candidate do ARQDOR.ai.

Este módulo organiza:
- readiness dos módulos;
- QA;
- bugs;
- integrações;
- segurança;
- performance;
- plano de lançamento;
- acceptance gates.

## Arquivos incluídos
- ReleaseCandidateCenter.tsx
- ReleaseOverview.tsx
- ModuleReadinessPanel.tsx
- QAChecklistPanel.tsx
- BugTriagePanel.tsx
- IntegrationAuditPanel.tsx
- SecurityReviewPanel.tsx
- PerformancePanel.tsx
- LaunchPlanPanel.tsx
- AcceptanceGatePanel.tsx
- ReleaseMetricCard.tsx
- ReadinessBar.tsx
- releaseTypes.ts
- releaseData.ts
- releaseUtils.ts

## Integração no ArqWorkspace

Importar:

```tsx
import ReleaseCandidateCenter from "./release-candidate/ReleaseCandidateCenter";
```

Adicionar case:

```tsx
case "release":
case "release-candidate":
case "rc":
  return <ReleaseCandidateCenter arqState={arqState} onNavigate={handleNavigate} />;
```

## Observação
Este pacote não altera backend, banco ou autenticação.
Ele entrega o painel executivo de validação final do ARQDOR.ai.
