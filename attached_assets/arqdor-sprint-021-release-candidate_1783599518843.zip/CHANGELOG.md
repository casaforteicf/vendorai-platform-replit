# Changelog — Sprint 021 Release Candidate

## Adicionado
- Launch Control do ARQDOR.ai.
- Readiness por módulo.
- Checklist de QA.
- Bug triage.
- Auditoria de integrações.
- Revisão de segurança.
- Painel de performance.
- Plano de lançamento.
- Acceptance gates.

## Fora do escopo
- Alterações backend.
- Banco.
- Autenticação.
- Deploy real.
