Aplicar Sprint 015C — AI Command Intelligence.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/operations-center/ai-command-intelligence

2. Integrar em OperationsCenter ou ArqWorkspace:
import AICommandIntelligence from "./operations-center/ai-command-intelligence/AICommandIntelligence";

3. Usar em case seguro:
case "ai-command":
case "ai-intelligence":
case "cerebro-ia":
  return <AICommandIntelligence onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do AI Command Intelligence;
- resultado typecheck.
