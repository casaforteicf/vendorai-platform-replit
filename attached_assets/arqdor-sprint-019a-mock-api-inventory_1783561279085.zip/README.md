# Sprint 019A — Mock/API Inventory

## Objetivo
Iniciar a fase de remoção de mocks e conexão com APIs reais.

## Arquivos incluídos
- MockApiInventoryCenter.tsx
- mockApiInventoryTypes.ts
- mockApiInventoryData.ts
- mockApiInventoryUtils.ts
- MetricCard.tsx
- InventoryDashboard.tsx
- MockInventoryPanel.tsx
- ApiInventoryPanel.tsx
- MigrationPriorityPanel.tsx
- DataContractsPanel.tsx
- InventoryRisksPanel.tsx
- InventoryChecklist.tsx
- InventoryReports.tsx
- AIInventoryPanel.tsx

## Integração
Importar no ArqWorkspace ou IntegrationHub:

```tsx
import MockApiInventoryCenter from "./integration-hub/mock-api-inventory/MockApiInventoryCenter";
```

Adicionar cases:

```tsx
case "mock-api-inventory":
case "mock-inventory":
case "api-inventory":
  return <MockApiInventoryCenter onNavigate={handleNavigate} />;
```

## Observação
Esta sprint não remove mocks ainda. Ela cria a tela e o inventário de governança para orientar as próximas sprints 019B–019J.
