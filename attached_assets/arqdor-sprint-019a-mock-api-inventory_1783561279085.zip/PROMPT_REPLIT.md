Aplicar Sprint 019A — Mock/API Inventory.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-hub/mock-api-inventory

2. Integrar em ArqWorkspace ou IntegrationHub:
import MockApiInventoryCenter from "./integration-hub/mock-api-inventory/MockApiInventoryCenter";

3. Adicionar cases seguros:
case "mock-api-inventory":
case "mock-inventory":
case "api-inventory":
  return <MockApiInventoryCenter onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não remover mocks ainda.
8. Rodar pnpm typecheck.

Entregar:
- resultado typecheck;
- prints;
- imports adicionados;
- cases adicionados;
- pendências para 019B.
