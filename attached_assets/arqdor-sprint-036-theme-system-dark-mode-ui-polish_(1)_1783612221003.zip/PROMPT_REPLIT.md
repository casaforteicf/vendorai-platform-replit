Aplicar Sprint 036 — Theme System, Dark Mode & UI Polish.

Contexto:
O ARQDOR.ai hoje está usando background claro fixo em várias telas:
bg-[#f7f7f8], bg-white, text-slate-950, border-slate-100.
O usuário quer poder escolher preto ou branco.

Objetivo:
1. Criar sistema de tema global.
2. Permitir tema claro, escuro e automático/sistema.
3. Salvar preferência do usuário.
4. Criar botão de alternância no menu/topbar.
5. Criar painel Configurações → Aparência.
6. Criar tokens globais para background, card, texto, borda e destaque.
7. Permitir que Render/Preview use workspace escuro mesmo no tema claro.
8. Evitar continuar usando cores fixas nas próximas telas.

Frontend:
Copiar:
artifacts/frontend/src/modules/arqdor/theme
artifacts/frontend/src/modules/arqdor/workspace/theme-system

Importar CSS:
import "./modules/arqdor/theme/arqdor-theme.css";

Envolver o módulo ARQDOR:
<ArqdorThemeProvider>
  <ArqdorPage />
</ArqdorThemeProvider>

Adicionar toggle:
<ArqdorThemeToggle />

Adicionar painel de configuração:
<ArqdorThemeSettingsPanel />

Adicionar case de navegação:
case "theme-system":
case "appearance":
case "aparencia":
case "dark-mode":
  return <ThemeSystemStudio arqState={arqState} onNavigate={handleNavigate} />;

Backend:
Avaliar estrutura real do servidor.
Se compatível, copiar/adaptar:
artifacts/server/modules/arch/theme-preferences

Registrar router:
createThemePreferencesRouter({ db })

Endpoints:
GET /arch/theme-preference
PATCH /arch/theme-preference

Banco:
Usar migração:
artifacts/server/migrations/2026_07_09_arch_theme_preferences.sql

Migração visual:
Substituir gradualmente:
- bg-[#f7f7f8] → arq-page
- bg-white + border + shadow → arq-card / arq-card-lg
- bg-slate-50 → arq-soft
- text-slate-950 → token ou arq-title/arq-hero-title
- text-slate-500 → arq-subtitle
- bg-violet-600 → arq-button arq-button-primary

Validações:
1. Tema claro funciona.
2. Tema escuro funciona.
3. Tema sistema acompanha preferência do dispositivo.
4. Preferência salva no localStorage mesmo se backend falhar.
5. Preferência salva no backend se endpoint existir.
6. Ao recarregar, tema escolhido permanece.
7. Render workspace pode continuar escuro.
8. Typecheck limpo.
9. Não quebrar telas antigas.
10. Não aplicar dark mode em landing/portal sem revisar contraste.

Não alterar:
- regras de negócio;
- endpoints de render, orçamento, proposta, produção ou pós-venda;
- billing;
- outros nichos da Vendor.ai.

Se houver conflito com Tailwind:
- manter CSS puro com classes arq-*;
- não exigir mexer no tailwind.config se não for necessário;
- priorizar estabilidade do build.
