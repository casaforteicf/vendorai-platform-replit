# Sprint 036 — Theme System, Dark Mode & UI Polish

## Objetivo
Permitir que o usuário escolha o visual do ARQDOR.ai:

```text
Claro
Escuro
Automático / Sistema
```

E criar a base visual para trocar classes fixas por tokens globais.

## Decisão de produto
- Sistema operacional: claro como padrão.
- Render/preview IA: pode ficar sempre escuro, mesmo no tema claro.
- Landing page/login: escuro premium.
- Portal cliente: claro por padrão.
- Usuário avançado: pode usar tema escuro completo.

## Frontend
Pastas:

```text
artifacts/frontend/src/modules/arqdor/theme
artifacts/frontend/src/modules/arqdor/workspace/theme-system
```

Arquivos principais:

- `arqdor-theme.css`
- `ArqdorThemeProvider.tsx`
- `ArqdorThemeToggle.tsx`
- `ArqdorThemeSettingsPanel.tsx`
- `ArqdorThemedShell.tsx`
- `ThemeSystemStudio.tsx`
- `themeMigrationGuide.ts`

## Backend
Pasta:

```text
artifacts/server/modules/arch/theme-preferences
```

Arquivos:

- `themePreferences.routes.ts`
- `themePreferences.service.ts`
- `themePreferences.types.ts`

Migração:

```text
artifacts/server/migrations/2026_07_09_arch_theme_preferences.sql
```

## Endpoints previstos

- `GET /arch/theme-preference`
- `PATCH /arch/theme-preference`

## Integração no app

### 1. Importar CSS global

No entrypoint do ARQDOR ou `main.tsx`:

```tsx
import "./modules/arqdor/theme/arqdor-theme.css";
```

### 2. Envolver o ARQDOR com provider

```tsx
import { ArqdorThemeProvider } from "./modules/arqdor/theme/ArqdorThemeProvider";

<ArqdorThemeProvider>
  <ArqdorPage />
</ArqdorThemeProvider>
```

### 3. Adicionar botão no menu/topbar

```tsx
import { ArqdorThemeToggle } from "./modules/arqdor/theme/ArqdorThemeToggle";

<ArqdorThemeToggle />
```

### 4. Adicionar painel em Configurações → Aparência

```tsx
import { ArqdorThemeSettingsPanel } from "./modules/arqdor/theme/ArqdorThemeSettingsPanel";

<ArqdorThemeSettingsPanel />
```

### 5. Adicionar tela de demonstração

```tsx
import ThemeSystemStudio from "./theme-system/ThemeSystemStudio";
```

Case:

```tsx
case "theme-system":
case "appearance":
case "aparencia":
case "dark-mode":
  return <ThemeSystemStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Substituição recomendada

Antes:

```tsx
<div className="min-h-screen bg-[#f7f7f8] text-slate-950">
```

Depois:

```tsx
<div className="arq-page">
```

Antes:

```tsx
<section className="rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm">
```

Depois:

```tsx
<section className="arq-card arq-card-lg">
```

## Próximo passo
Depois desta sprint, o Replit deve aplicar a migração visual gradualmente nas telas 029–035.
