# Changelog — Sprint 036 Theme System, Dark Mode & UI Polish

## Adicionado
- Tema claro, escuro e sistema.
- `ArqdorThemeProvider`.
- `ArqdorThemeToggle`.
- `ArqdorThemeSettingsPanel`.
- CSS global com tokens `--arq-*`.
- Workspace escuro para render.
- Tela `ThemeSystemStudio`.
- Backend de preferência de tema.
- Migração `arch_theme_preferences`.

## Resolvido
- Remove dependência futura de background fixo.
- Permite usuário escolher preto ou branco.
- Mantém tema salvo em localStorage e backend.
- Cria base visual para polimento final.

## Fora do escopo
- Redesenhar todas as telas manualmente nesta sprint.
- Criar white-label completo por tenant.
- Landing page premium.
- Portal cliente com tema customizado por cliente.
