import type { ThemePreferencePayload } from "./themePreferences.types";

const DEFAULT = {
  mode: "light",
  accent: "violet",
  useDarkRenderWorkspace: true,
};

export async function getThemePreference(db: any, params: { tenantId?: string | null; userId?: string | null }) {
  const values: any[] = [];
  let where = "1=1";

  if (params.tenantId) {
    values.push(params.tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  if (params.userId) {
    values.push(params.userId);
    where += ` and user_id = $${values.length}`;
  }

  const result = await db.query(
    `select * from arch_theme_preferences where ${where} order by updated_at desc limit 1`,
    values,
  );

  const row = result.rows[0];

  if (!row) {
    return DEFAULT;
  }

  return {
    mode: row.mode || DEFAULT.mode,
    accent: row.accent || DEFAULT.accent,
    useDarkRenderWorkspace: row.use_dark_render_workspace ?? DEFAULT.useDarkRenderWorkspace,
    updatedAt: row.updated_at || null,
  };
}

export async function upsertThemePreference(
  db: any,
  params: { tenantId?: string | null; userId?: string | null },
  payload: ThemePreferencePayload,
) {
  const current = await getThemePreference(db, params);

  const next = {
    mode: payload.mode || current.mode || DEFAULT.mode,
    accent: payload.accent || current.accent || DEFAULT.accent,
    useDarkRenderWorkspace:
      payload.useDarkRenderWorkspace !== undefined
        ? payload.useDarkRenderWorkspace
        : current.useDarkRenderWorkspace ?? DEFAULT.useDarkRenderWorkspace,
  };

  await db.query(
    `
    insert into arch_theme_preferences (
      id, tenant_id, user_id, mode, accent, use_dark_render_workspace, created_at, updated_at
    ) values ($1,$2,$3,$4,$5,$6,now(),now())
    on conflict (tenant_id, user_id)
    do update set mode = excluded.mode,
                  accent = excluded.accent,
                  use_dark_render_workspace = excluded.use_dark_render_workspace,
                  updated_at = now()
    `,
    [
      crypto.randomUUID(),
      params.tenantId || null,
      params.userId || null,
      next.mode,
      next.accent,
      next.useDarkRenderWorkspace,
    ],
  );

  return {
    ...next,
    updatedAt: new Date().toISOString(),
  };
}
