import { Router } from "express";
import {
  getThemePreference,
  upsertThemePreference,
} from "./themePreferences.service";

export function createThemePreferencesRouter(deps: { db: any }) {
  const router = Router();

  function tenantId(req: any) {
    return req?.tenant?.id || req?.user?.tenantId || req?.tenantId || null;
  }

  function userId(req: any) {
    return req?.user?.id || req?.userId || null;
  }

  router.get("/arch/theme-preference", async (req, res, next) => {
    try {
      const preference = await getThemePreference(deps.db, {
        tenantId: tenantId(req),
        userId: userId(req),
      });

      res.json({ preference });
    } catch (error) {
      next(error);
    }
  });

  router.patch("/arch/theme-preference", async (req, res, next) => {
    try {
      const preference = await upsertThemePreference(
        deps.db,
        {
          tenantId: tenantId(req),
          userId: userId(req),
        },
        req.body,
      );

      res.json({ preference });
    } catch (error) {
      next(error);
    }
  });

  return router;
}
