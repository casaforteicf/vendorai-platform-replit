export type ThemeMode = "light" | "dark" | "system";
export type Accent = "violet" | "blue" | "emerald" | "amber" | "rose" | "slate";

export type ThemePreferencePayload = {
  mode?: ThemeMode;
  accent?: Accent;
  useDarkRenderWorkspace?: boolean;
};
