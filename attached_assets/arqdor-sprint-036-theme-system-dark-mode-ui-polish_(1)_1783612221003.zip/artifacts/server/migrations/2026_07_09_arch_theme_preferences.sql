-- Sprint 036 — Theme System, Dark Mode & UI Polish
-- Preferência de tema por usuário/tenant.

create table if not exists arch_theme_preferences (
  id uuid primary key,
  tenant_id uuid null,
  user_id uuid null,

  mode text not null default 'light',
  accent text not null default 'violet',
  use_dark_render_workspace boolean not null default true,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique (tenant_id, user_id)
);

create index if not exists idx_arch_theme_preferences_tenant on arch_theme_preferences (tenant_id);
create index if not exists idx_arch_theme_preferences_user on arch_theme_preferences (user_id);

-- Se usa Supabase RLS:
-- alter table arch_theme_preferences enable row level security;
