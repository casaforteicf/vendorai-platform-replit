# Smoke Test

1 Criar projeto
2 Criar ambiente
3 Gerar render
4 Especificar produtos
5 Gerar orçamento
6 Aprovar orçamento
7 Criar procurement
8 Planejar produção
9 Executar construção
10 Criar ativo facility
11 Validar Copilot
12 Validar EventBus
