Release 0.19
Consolidação das Sprints 019A-019J.
Sistema preparado para homologação.
