Aplicar Sprint 019J

1 Copiar go-live
2 Integrar GoLiveValidator
3 Executar smoke test manual
4 Rodar pnpm typecheck
5 Gerar relatório final

Entregar:
- typecheck
- checklist
- pendências
- riscos
- status go-live
