Aplicar Sprint 015A — Operations Core.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/operations-center

2. Integrar em ArqWorkspace:
import OperationsCenter from "./operations-center/OperationsCenter";

3. Usar em case seguro:
case "operations":
case "command-center":
case "operacoes":
  return <OperationsCenter arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Operations Center;
- resultado typecheck.
