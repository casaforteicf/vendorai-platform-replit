Aplicar Sprint 029 — Real Render Gallery & Post-Render Integration.

Contexto:
O problema atual é que a melhoria do render não gera uma nova versão no histórico e não existe opção clara de alterar material no pós-render.

Objetivo:
1. Conectar a galeria real em GET /arch/renders/gallery?projectId=:projectId.
2. Garantir que pós-render chama POST /arch/ai-render/:id/adjust.
3. Toda melhoria deve enviar:
   - createNewVersion: true
   - preserveGeometry: true
   - preserveCamera: true
4. O render original deve permanecer no histórico.
5. O novo render deve aparecer como nova versão.
6. Adicionar fluxo de alteração de material por região/objeto.
7. Adicionar ação de aprovar render.
8. Adicionar ação de enviar render aprovado para Specification Studio.

Arquivos:
Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/real-render-gallery

Integração mínima no ArqWorkspace:
import RealRenderGalleryStudio from "./real-render-gallery/RealRenderGalleryStudio";

Adicionar case:
case "real-render-gallery":
case "render-gallery":
case "post-render":
  return <RealRenderGalleryStudio arqState={arqState} onNavigate={handleNavigate} />;

Integração ideal:
Se o workspace já renderiza SmartRenderEngine.tsx ou RenderHistoryModule.tsx para o fluxo de render, substituir a área de histórico/pós-render pela galeria real desta sprint. Não deixar componente órfão.

Endpoints consumidos:
- GET /arch/renders/gallery?projectId=:projectId
- POST /arch/ai-render/:id/adjust
- POST /arch/ai-render/:id/approve
- POST /arch/ai-render/:id/send-to-specification

Se /approve ou /send-to-specification não existirem:
- Não inventar mock silencioso.
- Retornar o erro.
- Informar exatamente qual rota está faltando.
- Manter o typecheck limpo.
- Depois geraremos Sprint 029B backend patch.

Não alterar:
- outros nichos da Vendor.ai;
- autenticação global;
- banco sem solicitação;
- rotas fora de /arch/*.

Rodar:
pnpm typecheck

Validar:
1. Galeria carrega renders reais.
2. Selecionar render mostra preview grande.
3. Alterar material gera payload correto.
4. Clicar Gerar novo render chama /adjust.
5. Novo render aparece na galeria após reload.
6. Original continua no histórico.
7. Aprovar render chama endpoint de aprovação.
8. Enviar para especificação navega para Specification Studio.

Entregar:
- resultado do typecheck;
- print da galeria real;
- logs de erro caso endpoint falte.
