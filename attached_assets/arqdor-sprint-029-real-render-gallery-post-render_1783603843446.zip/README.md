# Sprint 029 — Real Render Gallery & Post-Render Integration

## Objetivo
Resolver o problema crítico do fluxo de render:

- melhoria deve gerar um novo render;
- render original deve permanecer salvo;
- histórico deve vir de `/arch/renders/gallery`;
- alteração de material deve existir no pós-render;
- render aprovado deve poder ser enviado para Specification Studio.

## Arquivos incluídos
- RealRenderGalleryStudio.tsx
- useRealRenderGallery.ts
- renderGalleryApi.ts
- renderGalleryTypes.ts
- renderGalleryUtils.ts
- RealRenderGalleryPanel.tsx
- RenderPreviewCard.tsx
- RenderVersionTimeline.tsx
- SelectedRenderInspector.tsx
- PostRenderAdjustmentPanel.tsx
- MaterialChangePanel.tsx
- ApprovedRenderToSpecPanel.tsx

## Endpoints consumidos
- GET `/arch/renders/gallery?projectId=:projectId`
- POST `/arch/ai-render/:id/adjust`
- POST `/arch/ai-render/:id/approve`
- POST `/arch/ai-render/:id/send-to-specification`

## Importação sugerida

```tsx
import RealRenderGalleryStudio from "./real-render-gallery/RealRenderGalleryStudio";
```

## Case sugerido no ArqWorkspace

```tsx
case "real-render-gallery":
case "render-gallery":
case "post-render":
  return <RealRenderGalleryStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Integração ideal
Se o arquivo ativo for `SmartRenderEngine.tsx` ou `RenderHistoryModule.tsx`, o agente deve substituir a área de histórico/pós-render existente por este módulo, em vez de deixar como tela órfã.

## Regras de preservação
Toda melhoria deve enviar:

```ts
createNewVersion: true
preserveGeometry: true
preserveCamera: true
```

## Observação
Este pacote conecta frontend aos endpoints existentes. Caso `/approve` ou `/send-to-specification` ainda não existam, o Replit deve retornar erro objetivo para gerarmos o patch backend na Sprint 029B.
