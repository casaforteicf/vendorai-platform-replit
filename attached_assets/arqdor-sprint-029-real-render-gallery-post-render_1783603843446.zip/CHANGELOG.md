# Changelog — Sprint 029 Real Render Gallery & Post-Render Integration

## Adicionado
- Hook `useRealRenderGallery`.
- API client para `/arch/renders/gallery`.
- API client para `/arch/ai-render/:id/adjust`.
- Galeria real de renders.
- Preview do render selecionado.
- Timeline de versões.
- Painel de alteração de material.
- Painel de pós-render com `createNewVersion: true`.
- Aprovação de render.
- Envio para Specification Studio.

## Resolvido
- Melhoria deve gerar novo render.
- Render original deve permanecer no histórico.
- Material pode ser alterado por região/objeto.
- Fluxo de render aprovado fica preparado para especificação.

## Fora do escopo
- Criar endpoints backend faltantes.
- Alterar banco.
- OCR de planta.
- Marketplace.
