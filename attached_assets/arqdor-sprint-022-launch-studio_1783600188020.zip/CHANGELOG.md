# Changelog — Sprint 022 Launch Studio

## Adicionado
- Central Go-to-Market do ARQDOR.ai.
- Pacotes comerciais Start, Pro e Enterprise.
- Segmentação de mercado.
- Roteiro de demo.
- Plano de conteúdo.
- Campanhas.
- Playbook comercial.
- Onboarding.
- Analytics de lançamento.

## Fora do escopo
- Backend.
- Banco.
- Automação real de campanhas.
- Integrações com CRM.
