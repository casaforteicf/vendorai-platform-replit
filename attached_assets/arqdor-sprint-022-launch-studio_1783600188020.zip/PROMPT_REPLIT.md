Aplicar Sprint 022 — Launch Studio.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/launch-studio

2. Integrar no ArqWorkspace:
import LaunchStudio from "./launch-studio/LaunchStudio";

3. Adicionar case:
case "launch":
case "go-to-market":
case "gtm":
  return <LaunchStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar autenticação.
7. Não alterar outros nichos da Vendor.ai.
8. Manter isolamento em /arch/*.

Rodar:
pnpm typecheck

Validar UI:
- Visão
- Oferta
- Segmentos
- Demo
- Conteúdo
- Campanhas
- Vendas
- Onboarding
- Analytics

Entregar:
- resultado do typecheck;
- print da tela Launch Studio;
- logs do workflow se houver erro.
