# Sprint 022 — Launch Studio

## Objetivo
Criar o módulo de Go-to-Market do ARQDOR.ai pós Release Candidate.

Este módulo organiza:
- oferta comercial;
- segmentos;
- roteiro de demo;
- assets de conteúdo;
- campanhas;
- playbook de vendas;
- onboarding;
- analytics de lançamento.

## Arquivos incluídos
- LaunchStudio.tsx
- LaunchOverview.tsx
- OfferBuilderPanel.tsx
- SegmentStrategyPanel.tsx
- DemoScriptPanel.tsx
- ContentPlanPanel.tsx
- CampaignBoardPanel.tsx
- SalesPlaybookPanel.tsx
- OnboardingPlanPanel.tsx
- LaunchAnalyticsPanel.tsx
- LaunchMetricCard.tsx
- launchTypes.ts
- launchData.ts
- launchUtils.ts

## Integração no ArqWorkspace

Importar:

```tsx
import LaunchStudio from "./launch-studio/LaunchStudio";
```

Adicionar case:

```tsx
case "launch":
case "go-to-market":
case "gtm":
  return <LaunchStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Observação
Este pacote não altera backend, banco ou autenticação.
Ele entrega a central comercial de lançamento do ARQDOR.ai.
