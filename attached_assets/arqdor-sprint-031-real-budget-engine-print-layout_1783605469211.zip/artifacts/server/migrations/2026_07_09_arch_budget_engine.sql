-- Sprint 031 — Real Budget Engine
-- Ajustar schema e RLS conforme padrão do projeto.

create table if not exists arch_budgets (
  id uuid primary key,
  tenant_id uuid null,
  project_id uuid not null,
  ambiente_id uuid null,
  render_id uuid null,

  title text not null,
  client_name text null,
  status text not null default 'draft',
  version integer not null default 1,

  subtotal_material numeric not null default 0,
  subtotal_labor numeric not null default 0,
  subtotal numeric not null default 0,

  discount_type text not null default 'fixed',
  discount_value numeric not null default 0,
  discount_total numeric not null default 0,

  grand_total numeric not null default 0,

  notes text null,
  client_notes text null,
  internal_notes text null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists arch_budget_items (
  id uuid primary key,
  tenant_id uuid null,
  budget_id uuid not null references arch_budgets(id) on delete cascade,
  spec_object_id uuid null,
  project_id uuid not null,
  ambiente_id uuid null,
  render_id uuid null,

  item text not null,
  description text null,
  type text not null default 'product',

  quantity numeric not null default 1,
  unit text not null default 'un',

  material_value numeric not null default 0,
  labor_value numeric not null default 0,
  unit_total numeric not null default 0,

  total_material numeric not null default 0,
  total_labor numeric not null default 0,
  total numeric not null default 0,

  supplier_name text null,
  manufacturer_name text null,
  product_name text null,
  material_name text null,

  visible_to_client boolean not null default true,
  sort_order integer not null default 0,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create index if not exists idx_arch_budgets_tenant on arch_budgets (tenant_id);
create index if not exists idx_arch_budgets_project on arch_budgets (project_id);
create index if not exists idx_arch_budgets_status on arch_budgets (status);

create index if not exists idx_arch_budget_items_tenant on arch_budget_items (tenant_id);
create index if not exists idx_arch_budget_items_budget on arch_budget_items (budget_id);
create index if not exists idx_arch_budget_items_project on arch_budget_items (project_id);
create index if not exists idx_arch_budget_items_spec_object on arch_budget_items (spec_object_id);

-- Se o projeto usa RLS Supabase, ativar policies seguindo padrão existente:
-- alter table arch_budgets enable row level security;
-- alter table arch_budget_items enable row level security;
