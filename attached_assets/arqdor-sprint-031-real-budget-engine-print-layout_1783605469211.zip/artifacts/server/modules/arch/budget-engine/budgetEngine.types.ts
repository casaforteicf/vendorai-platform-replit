export type BudgetStatus = "draft" | "in-review" | "sent" | "approved" | "rejected" | "archived";

export type BudgetPayload = {
  projectId: string;
  ambienteId?: string | null;
  renderId?: string | null;
  title: string;
  clientName?: string | null;
  status?: BudgetStatus;
  discountType?: "percent" | "fixed";
  discountValue?: number;
  notes?: string | null;
  clientNotes?: string | null;
  internalNotes?: string | null;
};

export type BudgetItemPayload = {
  budgetId: string;
  specObjectId?: string | null;
  projectId: string;
  ambienteId?: string | null;
  renderId?: string | null;
  item: string;
  description?: string | null;
  type?: string;
  quantity: number;
  unit: string;
  materialValue: number;
  laborValue: number;
  supplierName?: string | null;
  manufacturerName?: string | null;
  productName?: string | null;
  materialName?: string | null;
  visibleToClient?: boolean;
  sortOrder?: number;
};
