import type { BudgetItemPayload, BudgetPayload } from "./budgetEngine.types";

function itemTotals(payload: Partial<BudgetItemPayload>) {
  const quantity = Number(payload.quantity || 1);
  const materialValue = Number(payload.materialValue || 0);
  const laborValue = Number(payload.laborValue || 0);

  return {
    unitTotal: materialValue + laborValue,
    totalMaterial: quantity * materialValue,
    totalLabor: quantity * laborValue,
    total: quantity * (materialValue + laborValue),
  };
}

async function recalculateBudget(db: any, budgetId: string) {
  const itemsResult = await db.query(
    `select * from arch_budget_items where budget_id = $1 and deleted_at is null`,
    [budgetId],
  );

  const subtotalMaterial = itemsResult.rows.reduce((sum: number, item: any) => sum + Number(item.total_material || 0), 0);
  const subtotalLabor = itemsResult.rows.reduce((sum: number, item: any) => sum + Number(item.total_labor || 0), 0);
  const subtotal = subtotalMaterial + subtotalLabor;

  const budgetResult = await db.query(`select * from arch_budgets where id = $1`, [budgetId]);
  const budget = budgetResult.rows[0];

  const discountValue = Number(budget?.discount_value || 0);
  const discountTotal = budget?.discount_type === "percent"
    ? subtotal * (discountValue / 100)
    : discountValue;

  const grandTotal = Math.max(0, subtotal - discountTotal);

  const updated = await db.query(
    `
    update arch_budgets
    set subtotal_material = $2,
        subtotal_labor = $3,
        subtotal = $4,
        discount_total = $5,
        grand_total = $6,
        updated_at = now()
    where id = $1
    returning *
    `,
    [budgetId, subtotalMaterial, subtotalLabor, subtotal, discountTotal, grandTotal],
  );

  return {
    budget: updated.rows[0],
    items: itemsResult.rows,
    totals: { subtotalMaterial, subtotalLabor, subtotal, discountTotal, grandTotal },
  };
}

export async function getBudgetByProject(db: any, params: { tenantId?: string | null; projectId: string }) {
  const values: any[] = [params.projectId];
  let where = `project_id = $1 and deleted_at is null`;

  if (params.tenantId) {
    values.push(params.tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  const budgetResult = await db.query(
    `select * from arch_budgets where ${where} order by created_at desc limit 1`,
    values,
  );

  const budget = budgetResult.rows[0] || null;

  if (!budget) {
    return {
      budget: null,
      items: [],
      totals: { subtotalMaterial: 0, subtotalLabor: 0, subtotal: 0, discountTotal: 0, grandTotal: 0 },
    };
  }

  return recalculateBudget(db, budget.id);
}

export async function createBudget(db: any, tenantId: string | null, payload: BudgetPayload) {
  const id = crypto.randomUUID();

  const result = await db.query(
    `
    insert into arch_budgets (
      id, tenant_id, project_id, ambiente_id, render_id,
      title, client_name, status, version,
      discount_type, discount_value, discount_total,
      subtotal_material, subtotal_labor, subtotal, grand_total,
      notes, client_notes, internal_notes, created_at, updated_at
    ) values (
      $1,$2,$3,$4,$5,
      $6,$7,$8,$9,
      $10,$11,0,
      0,0,0,0,
      $12,$13,$14,now(),now()
    )
    returning *
    `,
    [
      id,
      tenantId,
      payload.projectId,
      payload.ambienteId || null,
      payload.renderId || null,
      payload.title,
      payload.clientName || null,
      payload.status || "draft",
      1,
      payload.discountType || "fixed",
      Number(payload.discountValue || 0),
      payload.notes || null,
      payload.clientNotes || null,
      payload.internalNotes || null,
    ],
  );

  return {
    budget: result.rows[0],
    items: [],
    totals: { subtotalMaterial: 0, subtotalLabor: 0, subtotal: 0, discountTotal: 0, grandTotal: 0 },
  };
}

export async function updateBudget(db: any, id: string, tenantId: string | null, payload: Partial<BudgetPayload>) {
  const allowed = {
    title: "title",
    clientName: "client_name",
    status: "status",
    discountType: "discount_type",
    discountValue: "discount_value",
    notes: "notes",
    clientNotes: "client_notes",
    internalNotes: "internal_notes",
  } as const;

  const sets: string[] = [];
  const values: any[] = [];

  Object.entries(allowed).forEach(([key, column]) => {
    if ((payload as any)[key] === undefined) return;
    values.push((payload as any)[key]);
    sets.push(`${column} = $${values.length}`);
  });

  values.push(new Date());
  sets.push(`updated_at = $${values.length}`);

  values.push(id);
  let where = `id = $${values.length}`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  const result = await db.query(
    `update arch_budgets set ${sets.join(", ")} where ${where} returning *`,
    values,
  );

  if (result.rows[0]) {
    return recalculateBudget(db, result.rows[0].id);
  }

  return null;
}

export async function createBudgetItem(db: any, tenantId: string | null, payload: BudgetItemPayload) {
  const totals = itemTotals(payload);
  const id = crypto.randomUUID();

  const result = await db.query(
    `
    insert into arch_budget_items (
      id, tenant_id, budget_id, spec_object_id, project_id, ambiente_id, render_id,
      item, description, type, quantity, unit,
      material_value, labor_value, unit_total, total_material, total_labor, total,
      supplier_name, manufacturer_name, product_name, material_name,
      visible_to_client, sort_order, created_at, updated_at
    ) values (
      $1,$2,$3,$4,$5,$6,$7,
      $8,$9,$10,$11,$12,
      $13,$14,$15,$16,$17,$18,
      $19,$20,$21,$22,
      $23,$24,now(),now()
    )
    returning *
    `,
    [
      id,
      tenantId,
      payload.budgetId,
      payload.specObjectId || null,
      payload.projectId,
      payload.ambienteId || null,
      payload.renderId || null,
      payload.item,
      payload.description || null,
      payload.type || "product",
      Number(payload.quantity || 1),
      payload.unit || "un",
      Number(payload.materialValue || 0),
      Number(payload.laborValue || 0),
      totals.unitTotal,
      totals.totalMaterial,
      totals.totalLabor,
      totals.total,
      payload.supplierName || null,
      payload.manufacturerName || null,
      payload.productName || null,
      payload.materialName || null,
      payload.visibleToClient ?? true,
      Number(payload.sortOrder || 0),
    ],
  );

  await recalculateBudget(db, payload.budgetId);
  return result.rows[0];
}

export async function updateBudgetItem(db: any, id: string, tenantId: string | null, payload: Partial<BudgetItemPayload>) {
  const currentResult = await db.query(`select * from arch_budget_items where id = $1`, [id]);
  const current = currentResult.rows[0];

  if (!current) return null;

  const merged = {
    quantity: payload.quantity ?? current.quantity,
    materialValue: payload.materialValue ?? current.material_value,
    laborValue: payload.laborValue ?? current.labor_value,
  };
  const totals = itemTotals(merged);

  const allowed = {
    item: "item",
    description: "description",
    type: "type",
    quantity: "quantity",
    unit: "unit",
    materialValue: "material_value",
    laborValue: "labor_value",
    supplierName: "supplier_name",
    manufacturerName: "manufacturer_name",
    productName: "product_name",
    materialName: "material_name",
    visibleToClient: "visible_to_client",
    sortOrder: "sort_order",
  } as const;

  const sets: string[] = [];
  const values: any[] = [];

  Object.entries(allowed).forEach(([key, column]) => {
    if ((payload as any)[key] === undefined) return;
    values.push((payload as any)[key]);
    sets.push(`${column} = $${values.length}`);
  });

  values.push(totals.unitTotal);
  sets.push(`unit_total = $${values.length}`);
  values.push(totals.totalMaterial);
  sets.push(`total_material = $${values.length}`);
  values.push(totals.totalLabor);
  sets.push(`total_labor = $${values.length}`);
  values.push(totals.total);
  sets.push(`total = $${values.length}`);
  values.push(new Date());
  sets.push(`updated_at = $${values.length}`);

  values.push(id);
  let where = `id = $${values.length}`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  const result = await db.query(
    `update arch_budget_items set ${sets.join(", ")} where ${where} returning *`,
    values,
  );

  await recalculateBudget(db, current.budget_id);
  return result.rows[0];
}

export async function deleteBudgetItem(db: any, id: string, tenantId: string | null) {
  const currentResult = await db.query(`select * from arch_budget_items where id = $1`, [id]);
  const current = currentResult.rows[0];

  if (!current) return false;

  const values: any[] = [id];
  let where = `id = $1`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $2`;
  }

  await db.query(`update arch_budget_items set deleted_at = now() where ${where}`, values);
  await recalculateBudget(db, current.budget_id);
  return true;
}

export async function createBudgetFromSpecObjects(db: any, tenantId: string | null, payload: {
  projectId: string;
  ambienteId?: string | null;
  renderId?: string | null;
  title: string;
  clientName?: string | null;
  specObjectIds?: string[];
}) {
  const created = await createBudget(db, tenantId, {
    projectId: payload.projectId,
    ambienteId: payload.ambienteId || null,
    renderId: payload.renderId || null,
    title: payload.title,
    clientName: payload.clientName || null,
    status: "draft",
    discountType: "fixed",
    discountValue: 0,
  });

  const budget = created.budget;

  const values: any[] = [payload.projectId];
  let where = `project_id = $1 and status != 'archived'`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  if (payload.specObjectIds?.length) {
    values.push(payload.specObjectIds);
    where += ` and id = any($${values.length})`;
  }

  const specResult = await db.query(
    `select * from arch_spec_objects where ${where} order by created_at asc`,
    values,
  );

  for (const spec of specResult.rows) {
    await createBudgetItem(db, tenantId, {
      budgetId: budget.id,
      specObjectId: spec.id,
      projectId: spec.project_id,
      ambienteId: spec.ambiente_id,
      renderId: spec.render_id,
      item: spec.name,
      description: spec.description,
      type: "product",
      quantity: Number(spec.quantity || 1),
      unit: spec.unit || "un",
      materialValue: Number(spec.material_value || 0),
      laborValue: Number(spec.labor_value || 0),
      supplierName: spec.supplier_name,
      manufacturerName: spec.manufacturer_name,
      productName: spec.product_name,
      materialName: spec.material_name,
      visibleToClient: true,
      sortOrder: 0,
    });
  }

  return recalculateBudget(db, budget.id);
}
