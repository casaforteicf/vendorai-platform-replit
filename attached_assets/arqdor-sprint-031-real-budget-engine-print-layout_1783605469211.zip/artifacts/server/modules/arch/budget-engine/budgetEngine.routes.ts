import { Router } from "express";
import {
  createBudget,
  createBudgetFromSpecObjects,
  createBudgetItem,
  deleteBudgetItem,
  getBudgetByProject,
  updateBudget,
  updateBudgetItem,
} from "./budgetEngine.service";

export function createBudgetEngineRouter(deps: { db: any }) {
  const router = Router();

  function tenantId(req: any) {
    return req?.tenant?.id || req?.user?.tenantId || req?.tenantId || null;
  }

  router.get("/arch/orcamento", async (req, res, next) => {
    try {
      const projectId = String(req.query.projectId || "");

      if (!projectId) {
        res.status(400).json({ error: "projectId é obrigatório" });
        return;
      }

      const result = await getBudgetByProject(deps.db, {
        tenantId: tenantId(req),
        projectId,
      });

      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/orcamento", async (req, res, next) => {
    try {
      const result = await createBudget(deps.db, tenantId(req), req.body);
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/orcamento/from-spec-objects", async (req, res, next) => {
    try {
      const result = await createBudgetFromSpecObjects(deps.db, tenantId(req), req.body);
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  });

  router.patch("/arch/orcamento/:id", async (req, res, next) => {
    try {
      const result = await updateBudget(deps.db, req.params.id, tenantId(req), req.body);

      if (!result) {
        res.status(404).json({ error: "Orçamento não encontrado" });
        return;
      }

      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/orcamento/:id/items", async (req, res, next) => {
    try {
      const item = await createBudgetItem(deps.db, tenantId(req), {
        ...req.body,
        budgetId: req.params.id,
      });

      res.status(201).json({ item });
    } catch (error) {
      next(error);
    }
  });

  router.patch("/arch/orcamento/items/:id", async (req, res, next) => {
    try {
      const item = await updateBudgetItem(deps.db, req.params.id, tenantId(req), req.body);

      if (!item) {
        res.status(404).json({ error: "Item não encontrado" });
        return;
      }

      res.json({ item });
    } catch (error) {
      next(error);
    }
  });

  router.delete("/arch/orcamento/items/:id", async (req, res, next) => {
    try {
      const ok = await deleteBudgetItem(deps.db, req.params.id, tenantId(req));
      res.json({ ok });
    } catch (error) {
      next(error);
    }
  });

  return router;
}
