Aplicar Sprint 031 — Real Budget Engine & Print Layout.

Contexto:
A Sprint 030 criou SpecObject persistente com produto, material, fornecedor, quantidade, valor material e valor mão de obra.
Agora precisamos gerar orçamento real e corrigir impressão.

Objetivo:
1. Conectar SpecObjects ao orçamento real.
2. Criar orçamento por projeto.
3. Gerar itens com colunas:
   - Item
   - Quantidade
   - Unidade
   - Valor Material
   - Valor Mão de Obra
   - Total Material
   - Total Mão de Obra
   - Total
4. Corrigir impressão para não sumir atividades/itens.
5. Criar versão interna e versão cliente.
6. Permitir adicionar, editar e excluir itens.
7. Gerar orçamento a partir de SpecObjects.
8. Marcar orçamento como enviado/aprovado.

Frontend:
Copiar:
artifacts/frontend/src/modules/arqdor/workspace/real-budget-engine

Integrar:
import RealBudgetEngineStudio from "./real-budget-engine/RealBudgetEngineStudio";

Adicionar case:
case "real-budget":
case "orcamento-real":
case "budget-engine":
case "orcamento":
  return <RealBudgetEngineStudio arqState={arqState} onNavigate={handleNavigate} />;

Integração ideal:
Se já existe BudgetStudio, Orçamento ou Documentation/Production usando orçamento mockado, substituir a área mockada por este módulo.
Não deixar componente órfão.

Backend:
Avaliar estrutura real do servidor.
Se compatível, copiar/adaptar:
artifacts/server/modules/arch/budget-engine

Registrar router:
createBudgetEngineRouter({ db })

Endpoints:
GET /arch/orcamento?projectId=:projectId
POST /arch/orcamento
PATCH /arch/orcamento/:id
POST /arch/orcamento/from-spec-objects
POST /arch/orcamento/:id/items
PATCH /arch/orcamento/items/:id
DELETE /arch/orcamento/items/:id

Banco:
Usar migração:
artifacts/server/migrations/2026_07_09_arch_budget_engine.sql

Se o projeto usa Drizzle/RLS/Supabase:
- adaptar ao padrão existente;
- manter tenant_id;
- garantir isolamento por tenant;
- não quebrar tabelas existentes.

Validações:
1. Criar orçamento.
2. Gerar orçamento a partir de SpecObjects.
3. Itens aparecem na tabela.
4. Colunas Valor Material e Valor Mão de Obra aparecem separadas.
5. Totais calculam corretamente.
6. Item manual salva.
7. Editar item recalcula totais.
8. Excluir item recalcula totais.
9. Impressão mostra todos os itens.
10. Versão cliente oculta itens com visibleToClient=false.
11. Typecheck limpo.

Não alterar:
- outros nichos da Vendor.ai;
- autenticação global;
- rotas fora de /arch/*;
- marketplace;
- billing.

Se algum endpoint ou estrutura não existir:
- manter typecheck limpo;
- não inventar mock silencioso;
- retornar erro objetivo;
- informar arquivo/linha para registro de router ou migration.
