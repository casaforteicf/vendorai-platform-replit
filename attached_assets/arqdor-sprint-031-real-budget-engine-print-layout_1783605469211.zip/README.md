# Sprint 031 — Real Budget Engine & Print Layout

## Objetivo
Transformar os SpecObjects da Sprint 030 em orçamento real com:

- item;
- quantidade;
- unidade;
- valor material;
- valor mão de obra;
- total material;
- total mão de obra;
- total por item;
- total geral;
- versão interna;
- versão cliente;
- impressão corrigida.

## Frontend
Pasta:

```text
artifacts/frontend/src/modules/arqdor/workspace/real-budget-engine
```

Arquivos principais:

- `RealBudgetEngineStudio.tsx`
- `useRealBudgetEngine.ts`
- `budgetApi.ts`
- `budgetTypes.ts`
- `budgetUtils.ts`
- `BudgetItemsTable.tsx`
- `BudgetItemEditorPanel.tsx`
- `BudgetSettingsPanel.tsx`
- `BudgetPrintPreview.tsx`
- `BudgetSummaryCards.tsx`

## Backend
Pasta:

```text
artifacts/server/modules/arch/budget-engine
```

Arquivos:

- `budgetEngine.routes.ts`
- `budgetEngine.service.ts`
- `budgetEngine.types.ts`

Migração:

```text
artifacts/server/migrations/2026_07_09_arch_budget_engine.sql
```

## Endpoints previstos

- `GET /arch/orcamento?projectId=:projectId`
- `POST /arch/orcamento`
- `PATCH /arch/orcamento/:id`
- `POST /arch/orcamento/from-spec-objects`
- `POST /arch/orcamento/:id/items`
- `PATCH /arch/orcamento/items/:id`
- `DELETE /arch/orcamento/items/:id`

## Integração no ArqWorkspace

```tsx
import RealBudgetEngineStudio from "./real-budget-engine/RealBudgetEngineStudio";
```

Adicionar case:

```tsx
case "real-budget":
case "orcamento-real":
case "budget-engine":
case "orcamento":
  return <RealBudgetEngineStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Impressão corrigida
A impressão usa `.budget-print` para garantir que a tabela apareça com os itens/atividades e as colunas:

- Item
- Qtd.
- Un.
- Valor Material
- Valor Mão de Obra
- Total

## Próximo passo
Depois de aplicar, validar se `/arch/orcamento/from-spec-objects` cria itens a partir de `arch_spec_objects`.
