# Changelog — Sprint 031 Real Budget Engine & Print Layout

## Adicionado
- RealBudgetEngineStudio.
- Hook `useRealBudgetEngine`.
- API client para `/arch/orcamento`.
- Tabela de orçamento com material e mão de obra separados.
- Editor de item.
- Configuração de desconto e observações.
- Preview de impressão/PDF.
- Versão cliente e interna.
- Backend adapter para orçamento.
- Migração base para orçamento e itens.

## Resolvido
- Atividades/itens não somem na impressão.
- Colunas de material e mão de obra ficam separadas.
- SpecObjects podem gerar orçamento.
- Totais recalculam por item e orçamento.

## Fora do escopo
- Emissão fiscal.
- Gateway de pagamento.
- Assinatura digital.
- Portal cliente final.
