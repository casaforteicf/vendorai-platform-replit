# Sprint 003 — Design Studio — Parte 02

## Objetivo
Adicionar o Canvas visual reutilizável do Design Studio.

## Arquivos novos
- ImageCanvas.tsx
- CanvasToolbar.tsx
- CanvasEmptyState.tsx

## Integração sugerida
Em `DesignStudio.tsx`, substituir o placeholder atual por:

```tsx
import { ImageCanvas } from "./ImageCanvas";
```

E usar:

```tsx
<ImageCanvas imageUrl={undefined} title="Render atual" />
```

Nesta parte ainda não há integração real com render. É apenas a base visual do Canvas.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts

## Validar
- pnpm check
- pnpm build
