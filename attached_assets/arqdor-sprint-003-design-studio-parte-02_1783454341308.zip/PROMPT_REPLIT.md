Aplicar Sprint 003 — Design Studio — Parte 02.

1. Copiar os arquivos para:
artifacts/frontend/src/modules/arqdor/workspace/design-studio

2. Em DesignStudio.tsx:
- importar ImageCanvas;
- substituir o CanvasPlaceholder pelo ImageCanvas;
- manter o restante intacto.

3. Não alterar backend.
4. Não alterar banco.
5. Não alterar Core Vendor.ai.
6. Não alterar rotas.

Rodar:
- pnpm check
- pnpm build

Corrigir somente imports/tipagem se necessário.
