import React, { useMemo, useState } from "react";

type ImageCanvasProps = {
  imageUrl?: string | null;
  title?: string;
};

export function ImageCanvas({ imageUrl, title = "Render atual" }: ImageCanvasProps) {
  const [zoom, setZoom] = useState(100);
  const [showGrid, setShowGrid] = useState(false);
  const [fitMode, setFitMode] = useState<"contain" | "cover">("contain");

  const transformStyle = useMemo(() => ({ transform: `scale(${zoom / 100})` }), [zoom]);

  return (
    <div className="flex h-full min-h-[460px] flex-col rounded-[28px] border border-slate-100 bg-slate-950 shadow-sm">
      <div className="flex h-14 items-center justify-between border-b border-white/10 px-4">
        <div>
          <p className="text-sm font-semibold text-white">{title}</p>
          <p className="text-xs text-slate-400">Canvas visual do ambiente</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowGrid((v) => !v)}
            className={[
              "rounded-xl px-3 py-2 text-xs font-semibold transition",
              showGrid ? "bg-violet-600 text-white" : "bg-white/10 text-slate-300 hover:bg-white/15",
            ].join(" ")}
          >
            Grade
          </button>

          <button
            type="button"
            onClick={() => setFitMode((v) => (v === "contain" ? "cover" : "contain"))}
            className="rounded-xl bg-white/10 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-white/15"
          >
            {fitMode === "contain" ? "Ajustar" : "Preencher"}
          </button>

          <button
            type="button"
            onClick={() => setZoom((v) => Math.max(50, v - 10))}
            className="rounded-xl bg-white/10 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-white/15"
          >
            -
          </button>

          <span className="w-12 text-center text-xs font-medium text-slate-300">{zoom}%</span>

          <button
            type="button"
            onClick={() => setZoom((v) => Math.min(180, v + 10))}
            className="rounded-xl bg-white/10 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-white/15"
          >
            +
          </button>
        </div>
      </div>

      <div className="relative min-h-0 flex-1 overflow-hidden">
        {showGrid ? (
          <div
            className="pointer-events-none absolute inset-0 opacity-[0.08]"
            style={{
              backgroundImage:
                "linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)",
              backgroundSize: "40px 40px",
            }}
          />
        ) : null}

        <div className="flex h-full items-center justify-center p-6">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={title}
              className={[
                "max-h-full max-w-full rounded-2xl object-contain shadow-2xl transition-transform duration-200",
                fitMode === "cover" ? "h-full w-full object-cover" : "",
              ].join(" ")}
              style={transformStyle}
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center rounded-3xl border border-dashed border-white/15 bg-white/[0.03]">
              <div className="max-w-md text-center">
                <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-[28px] bg-white/10 text-2xl text-white/60">
                  ARQ
                </div>
                <h2 className="mt-5 text-2xl font-semibold text-white">Nenhum render selecionado</h2>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  Quando houver um render ou imagem do ambiente, ele aparecerá aqui com zoom, grade, modo foco e seleção visual.
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="absolute bottom-4 left-4 rounded-2xl bg-black/45 px-4 py-2 text-xs font-medium text-white backdrop-blur">
          Clique no render para selecionar objetos
        </div>
      </div>
    </div>
  );
}
