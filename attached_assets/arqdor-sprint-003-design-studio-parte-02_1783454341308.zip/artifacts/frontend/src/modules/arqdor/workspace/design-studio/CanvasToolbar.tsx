import React from "react";

type CanvasToolbarProps = {
  onAction?: (action: string) => void;
};

export function CanvasToolbar({ onAction }: CanvasToolbarProps) {
  const actions = [
    ["select", "Selecionar"],
    ["before-after", "Antes/depois"],
    ["mask", "Selecionar área"],
    ["fullscreen", "Modo foco"],
  ];

  return (
    <div className="absolute right-4 top-4 z-10 flex gap-2 rounded-2xl bg-white/95 p-2 shadow-sm backdrop-blur">
      {actions.map(([key, label]) => (
        <button
          key={key}
          type="button"
          onClick={() => onAction?.(key)}
          className="rounded-xl px-3 py-2 text-xs font-semibold text-slate-600 transition hover:bg-violet-50 hover:text-violet-700"
        >
          {label}
        </button>
      ))}
    </div>
  );
}
