import React from "react";

export function CanvasEmptyState({ onGenerate }: { onGenerate?: () => void }) {
  return (
    <div className="flex h-full min-h-[460px] items-center justify-center rounded-[28px] border border-dashed border-slate-200 bg-white">
      <div className="max-w-md text-center">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-[28px] bg-violet-50 text-2xl text-violet-600">
          ✨
        </div>
        <h2 className="mt-5 text-2xl font-semibold text-slate-950">Gerar primeiro render</h2>
        <p className="mt-2 text-sm leading-6 text-slate-500">
          Envie uma imagem, planta ou referência do ambiente para iniciar o Design Studio.
        </p>
        <button
          type="button"
          onClick={onGenerate}
          className="mt-6 rounded-2xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-violet-700"
        >
          Gerar render
        </button>
      </div>
    </div>
  );
}
