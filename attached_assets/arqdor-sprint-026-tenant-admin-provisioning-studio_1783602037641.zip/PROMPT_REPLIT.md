Aplicar Sprint 026 — Tenant Admin & Provisioning Studio.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/tenant-admin-provisioning-studio

2. Integrar no ArqWorkspace:
import TenantAdminProvisioningStudio from "./tenant-admin-provisioning-studio/TenantAdminProvisioningStudio";

3. Adicionar case:
case "tenant-admin":
case "provisioning":
case "saas-admin":
  return <TenantAdminProvisioningStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar autenticação.
7. Não alterar outros nichos da Vendor.ai.
8. Manter isolamento em /arch/*.

Rodar:
pnpm typecheck

Validar UI:
- Visão
- Tenants
- Provisioning
- Usuários
- Permissões
- Features
- Limites
- Integrações
- Auditoria
- Health

Entregar:
- resultado do typecheck;
- print da tela SaaS Admin;
- logs do workflow se houver erro.
