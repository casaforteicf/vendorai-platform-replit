# Sprint 026 — Tenant Admin & Provisioning Studio

## Objetivo
Criar o módulo SaaS Admin do ARQDOR.ai para controlar tenants, usuários, permissões, provisionamento, feature flags, limites, integrações, auditoria e saúde do sistema.

Este módulo organiza:
- tenants;
- provisioning;
- usuários;
- papéis e permissões;
- feature flags;
- limites de uso;
- integrações;
- auditoria;
- health operacional.

## Arquivos incluídos
- TenantAdminProvisioningStudio.tsx
- TenantAdminOverview.tsx
- TenantAccountsPanel.tsx
- ProvisioningPanel.tsx
- UsersPanel.tsx
- RolesPanel.tsx
- FeatureFlagsPanel.tsx
- UsageLimitsPanel.tsx
- IntegrationStatusPanel.tsx
- AuditLogPanel.tsx
- SystemHealthPanel.tsx
- AdminMetricCard.tsx
- RolloutBar.tsx
- tenantAdminTypes.ts
- tenantAdminData.ts
- tenantAdminUtils.ts

## Integração no ArqWorkspace

Importar:

```tsx
import TenantAdminProvisioningStudio from "./tenant-admin-provisioning-studio/TenantAdminProvisioningStudio";
```

Adicionar case:

```tsx
case "tenant-admin":
case "provisioning":
case "saas-admin":
  return <TenantAdminProvisioningStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Observação
Este pacote não altera backend, banco ou autenticação.
Ele entrega a central administrativa SaaS para operação multi-tenant.
