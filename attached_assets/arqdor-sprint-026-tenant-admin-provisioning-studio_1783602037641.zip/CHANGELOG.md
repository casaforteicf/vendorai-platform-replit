# Changelog — Sprint 026 Tenant Admin & Provisioning Studio

## Adicionado
- Central SaaS Admin do ARQDOR.ai.
- Tenants.
- Provisioning.
- Usuários.
- Papéis e permissões.
- Feature flags.
- Limites de uso.
- Integrações.
- Auditoria.
- Health operacional.

## Fora do escopo
- Backend.
- Banco.
- RLS real.
- Provisionamento automático real.
- Integração real com billing/auth.
