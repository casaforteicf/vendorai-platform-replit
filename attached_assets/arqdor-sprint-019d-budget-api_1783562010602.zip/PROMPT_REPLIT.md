Aplicar Sprint 019D

1 Copiar budget-api
2 Integrar Executive Budget
3 Manter fallback para budgetData.ts
4 Não alterar backend
5 Emitir budget.approved apenas se API responder
6 Rodar pnpm typecheck

Entregar:
- typecheck
- imports
- APIs encontradas
- pendências 019E
