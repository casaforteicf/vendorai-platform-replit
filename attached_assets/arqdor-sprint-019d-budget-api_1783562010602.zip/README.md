# Sprint 019D

Conecta Executive Budget às APIs reais.

Entregas:
- BudgetRepository
- BudgetApprovalService
- BudgetContract

Integração:
import BudgetApprovalService ...

Cases:
budget-api
budget-service

Rodar:
pnpm typecheck
