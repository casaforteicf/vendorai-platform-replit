# ARQDOR Sprint 001A — Foundation

Pacote base para criar componentes reutilizáveis do ARQDOR.ai.

## Objetivo

Adicionar uma camada de componentes, tipos e utilitários reutilizáveis para as próximas telas do ARQDOR, sem alterar o Core da Vendor.ai.

## Como integrar no Replit

Copiar a pasta `src/modules/arqdor/foundation` para:

`artifacts/frontend/src/modules/arqdor/foundation`

Depois rodar:

```bash
pnpm check
pnpm build
```

## Escopo

Inclui:
- Tipos base de projetos ARQDOR
- Componentes visuais reutilizáveis
- Utilitários de status/progresso
- Hook local para busca em projetos
- Serviço frontend opcional para endpoints `/api/arch/projetos`

Não inclui:
- Rotas novas
- Banco de dados
- Backend
- Alteração no Core Vendor.ai
