# Prompt para o Replit

Vou enviar um ZIP com a Sprint 001A — Foundation do ARQDOR.ai.

Faça apenas a integração.

1. Descompacte o ZIP.
2. Copie `src/modules/arqdor/foundation` para:
   `artifacts/frontend/src/modules/arqdor/foundation`
3. Não altere Core Vendor.ai.
4. Não altere backend.
5. Não altere banco de dados.
6. Não altere rotas.
7. Rode typecheck/build.
8. Corrija somente imports/tipagens se necessário.
9. Entregue:
   - arquivos copiados/alterados;
   - resultado do typecheck;
   - resultado do build;
   - qualquer pendência encontrada.

Não reescreva os componentes.
Não criar funcionalidades novas.
