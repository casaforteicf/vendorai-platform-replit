# Changelog — Sprint 023 Pilot Operations Studio

## Adicionado
- Central de pilotos do ARQDOR.ai.
- Contas piloto.
- Projetos piloto.
- Health score.
- Tarefas.
- Feedbacks.
- Métricas de sucesso.
- Riscos e mitigação.
- Handoff para operação comercial.

## Fora do escopo
- Backend.
- Banco.
- Automações reais.
- Integração com CRM.
