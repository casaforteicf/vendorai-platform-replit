Aplicar Sprint 023 — Pilot Operations Studio.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/pilot-operations-studio

2. Integrar no ArqWorkspace:
import PilotOperationsStudio from "./pilot-operations-studio/PilotOperationsStudio";

3. Adicionar case:
case "pilot":
case "pilots":
case "pilot-operations":
  return <PilotOperationsStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar autenticação.
7. Não alterar outros nichos da Vendor.ai.
8. Manter isolamento em /arch/*.

Rodar:
pnpm typecheck

Validar UI:
- Visão
- Contas
- Projetos
- Health
- Tarefas
- Feedback
- Success
- Riscos
- Handoff

Entregar:
- resultado do typecheck;
- print da tela Pilot Operations;
- logs do workflow se houver erro.
