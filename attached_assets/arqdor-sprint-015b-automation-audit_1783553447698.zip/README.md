# Sprint 015B — Automation & Audit

## Pacote B da Sprint 015

Arquivos incluídos:
- AutomationAuditCenter.tsx
- automationAuditTypes.ts
- automationAuditData.ts
- automationAuditUtils.ts
- MetricCard.tsx
- AutomationCenter.tsx
- ExecutionLogs.tsx
- AuditCenter.tsx
- PermissionsCenter.tsx
- IncidentCenter.tsx
- AutomationReports.tsx
- AIAuditPanel.tsx

## Objetivo
Expandir o Operations Center com:
- Automações.
- Regras operacionais.
- Logs de execução.
- Auditoria.
- Permissões.
- Incidentes.
- Relatórios.
- IA de auditoria.

## Integração
Importar no OperationsCenter ou ArqWorkspace:

```tsx
import AutomationAuditCenter from "./operations-center/automation-audit/AutomationAuditCenter";
```

Adicionar/usar case:
```tsx
case "automation-audit":
case "audit":
case "automacoes":
  return <AutomationAuditCenter onNavigate={handleNavigate} />;
```
