Aplicar Sprint 015B — Automation & Audit.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/operations-center/automation-audit

2. Integrar em OperationsCenter ou ArqWorkspace:
import AutomationAuditCenter from "./operations-center/automation-audit/AutomationAuditCenter";

3. Usar em case seguro:
case "automation-audit":
case "audit":
case "automacoes":
  return <AutomationAuditCenter onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Automation & Audit Center;
- resultado typecheck.
