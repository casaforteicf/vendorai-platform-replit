# Changelog — Sprint 015B

## Adicionado
- Automation & Audit Center.
- Automation Center.
- Execution Logs.
- Audit Center.
- Permissions Center.
- Incident Center.
- Automation Reports.
- AI Audit.
