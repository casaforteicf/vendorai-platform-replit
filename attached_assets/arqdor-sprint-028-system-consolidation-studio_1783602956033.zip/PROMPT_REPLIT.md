Aplicar Sprint 028 — System Consolidation Studio.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/system-consolidation-studio

2. Integrar no ArqWorkspace:
import SystemConsolidationStudio from "./system-consolidation-studio/SystemConsolidationStudio";

3. Adicionar case:
case "consolidation":
case "system-consolidation":
case "real-integration":
  return <SystemConsolidationStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar autenticação.
7. Não alterar outros nichos da Vendor.ai.
8. Manter isolamento em /arch/*.

Rodar:
pnpm typecheck

Validar UI:
- Visão
- Inventário
- Mock → Real
- API
- Dados
- Integração
- QA
- Prioridades
- Release
- Handoff

Após validar, usar este módulo para orientar a próxima fase:
1. conectar Render Gallery real;
2. trocar mocks do Specification por /arch/catalogo;
3. criar/persistir SpecObject;
4. ligar Specification → Budget;
5. validar Portal Cliente com aprovação real;
6. validar tenant/RLS.

Entregar:
- resultado do typecheck;
- print da tela System Consolidation;
- lista de erros por sprint, se houver.
