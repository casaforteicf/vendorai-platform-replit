Aplicar Sprint 007F — UX Polish Enterprise.

1. Substituir:
artifacts/frontend/src/modules/arqdor/workspace/project-experience/ProjectHomeV2.tsx

2. Não criar componentes paralelos.
3. Não alterar ArqWorkspace.
4. Não alterar backend, banco, rotas ou hooks.

Rodar:
pnpm typecheck
pnpm build

Entregar print da Home.
