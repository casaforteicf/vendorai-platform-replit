# Changelog — Sprint 007F

## Alterado
- Home refinada com layout Enterprise.
- Hero maior e mais informativo.
- Pipeline visual do projeto.
- AI Architect com leitura executiva.
- Cards de projetos mais ricos.
- Melhor uso de espaço e hierarquia visual.
