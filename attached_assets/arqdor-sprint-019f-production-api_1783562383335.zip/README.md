# Sprint 019F

Production API Integration

Entregas:
- ProductionRepository
- ProductionPlanningService
- ProductionContract
- Workflow
- Checklist

Não remover mocks.
