Budget Approved
↓
Procurement
↓
Purchase Order
↓
Production Planning
↓
Manufacturing
↓
Construction
