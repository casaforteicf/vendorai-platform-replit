Aplicar Sprint 019F

1. Copiar production-api
2. Integrar Production Hub
3. Tentar API /arch/production
4. Se falhar manter productionData.ts
5. Não alterar backend
6. Rodar pnpm typecheck

Entregar:
- typecheck
- imports
- APIs encontradas
- fallback mantido
- pendências 019G
