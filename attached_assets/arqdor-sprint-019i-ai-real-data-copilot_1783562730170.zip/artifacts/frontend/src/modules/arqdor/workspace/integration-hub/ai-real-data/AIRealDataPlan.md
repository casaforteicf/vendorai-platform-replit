# Plano técnico — Sprint 019I

## Objetivo
Conectar o Unified Copilot aos dados reais do projeto.

## Fontes
- Project API
- Environments API
- Render Gallery
- Specification API
- Budget API
- Procurement API
- Production API
- Construction API
- Facility API

## Regras
- IA não deve executar ação se contexto real estiver ausente.
- Procurement depende de budget.approved.
- Compra depende de canonicalProductId.
- Copilot deve usar Event Bus para reanalisar contexto após eventos.
- Manter fallback visual, mas recomendações devem priorizar dados reais.
