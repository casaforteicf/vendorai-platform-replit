# Checklist 019I

- [ ] Integrar AIContextRepository
- [ ] Integrar CopilotRealDataService
- [ ] Adicionar AIActionGuard antes de ações automáticas
- [ ] Registrar AIEventSubscriber no bootstrap do módulo
- [ ] Manter fallback do UnifiedCopilot mockado quando API falhar
- [ ] Rodar pnpm typecheck
- [ ] Listar pendências para 019J
