# Sprint 019I — AI Real Data Copilot

## Objetivo
Conectar o Unified Copilot aos dados reais da plataforma e aos eventos do Event Bus.

## Entregas
- AIContextRepository
- CopilotRealDataService
- AIActionGuard
- AIEventSubscriber
- AIRealDataContract
- Plano técnico
- Checklist

## Integração sugerida
```ts
import { CopilotRealDataService } from "./integration-hub/ai-real-data/CopilotRealDataService";
import { AIEventSubscriber } from "./integration-hub/ai-real-data/AIEventSubscriber";
```

## Regras
- Não alterar backend.
- Não remover fallback atual.
- IA deve bloquear ações inseguras.
- Rodar `pnpm typecheck`.
