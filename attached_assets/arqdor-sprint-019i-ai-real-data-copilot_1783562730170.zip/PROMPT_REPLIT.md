Aplicar Sprint 019I — AI Real Data Copilot.

Objetivo:
Conectar Unified Copilot aos dados reais e ao Event Bus.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-hub/ai-real-data

2. Integrar gradualmente:
- AIContextRepository para carregar contexto real do projeto.
- CopilotRealDataService para gerar insights reais.
- AIActionGuard antes de qualquer ação automática.
- AIEventSubscriber para reanalisar após eventos do Event Bus.

3. Não remover:
- dados mockados do Unified Copilot;
- recomendações atuais;
- fallback visual.

4. Regra:
- se API falhar, manter fallback;
- se faltar projectId, bloquear ação;
- se faltar budget.approved, bloquear procurement;
- se faltar canonicalProductId, bloquear compras.

5. Rodar:
pnpm typecheck

Entregar:
- typecheck;
- arquivos alterados;
- onde AIActionGuard foi usado;
- eventos assinados;
- APIs com erro;
- pendências para 019J.
