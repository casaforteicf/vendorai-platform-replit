# Sprint 032 — Client Portal Approval & Proposal Delivery

## Objetivo
Transformar orçamento aprovado internamente em proposta pública com aprovação do cliente.

Fluxo:

```text
Orçamento real
↓
Proposta cliente
↓
Portal público com token
↓
Cliente aprova / reprova / comenta
↓
Status volta para projeto
↓
Produção / compras / execução
```

## Frontend
Pasta:

```text
artifacts/frontend/src/modules/arqdor/workspace/client-portal-approval
```

Arquivos principais:

- `ClientPortalApprovalStudio.tsx`
- `PublicProposalPortal.tsx`
- `useClientPortalApproval.ts`
- `usePublicProposalPortal.ts`
- `portalApi.ts`
- `portalTypes.ts`
- `portalUtils.ts`
- `PortalDeliveryPanel.tsx`
- `ProposalItemsApprovalTable.tsx`
- `ClientPortalPreview.tsx`
- `ApprovalTimelinePanel.tsx`
- `ProposalSummaryCards.tsx`

## Backend
Pasta:

```text
artifacts/server/modules/arch/client-portal-approval
```

Arquivos:

- `clientPortalApproval.routes.ts`
- `clientPortalApproval.service.ts`
- `clientPortalApproval.types.ts`

Migração:

```text
artifacts/server/migrations/2026_07_09_arch_client_portal_approval.sql
```

## Endpoints previstos

Internos:

- `GET /arch/propostas?projectId=:projectId`
- `POST /arch/propostas/from-budget`
- `POST /arch/propostas/:id/portal/ativar`
- `POST /arch/propostas/:id/send`

Públicos por token:

- `GET /arch/portal/proposta/:token`
- `POST /arch/portal/proposta/:token/items/:itemId/decision`
- `POST /arch/portal/proposta/:token/decision`

## Integração no ArqWorkspace

```tsx
import ClientPortalApprovalStudio from "./client-portal-approval/ClientPortalApprovalStudio";
```

Adicionar case:

```tsx
case "client-portal-approval":
case "proposal-delivery":
case "portal-aprovacao":
case "portal-cliente":
  return <ClientPortalApprovalStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Rota pública sugerida

Criar rota pública:

```tsx
/arch/proposta/:token
```

Renderizando:

```tsx
<PublicProposalPortal token={token} />
```

Se já existir `PortalCliente.tsx`, integrar o `PublicProposalPortal` nele.

## Próximo passo
Após aplicar, a Sprint 033 deve ligar aprovação final à produção/compras.
