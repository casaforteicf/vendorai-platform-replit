Aplicar Sprint 032 — Client Portal Approval & Proposal Delivery.

Contexto:
A Sprint 031 criou orçamento real com material/mão de obra separados e impressão corrigida.
Agora precisamos transformar o orçamento em proposta pública para aprovação do cliente.

Objetivo:
1. Criar proposta a partir do orçamento.
2. Gerar portal público com token.
3. Enviar proposta por portal/e-mail/WhatsApp.
4. Cliente visualiza versão cliente.
5. Cliente aprova/reprova/comenta por item.
6. Cliente aprova/reprova/solicita revisão da proposta inteira.
7. Registrar histórico/timeline.
8. Atualizar status da proposta e preparar fluxo para produção/compras.

Frontend:
Copiar:
artifacts/frontend/src/modules/arqdor/workspace/client-portal-approval

Integrar:
import ClientPortalApprovalStudio from "./client-portal-approval/ClientPortalApprovalStudio";

Adicionar case:
case "client-portal-approval":
case "proposal-delivery":
case "portal-aprovacao":
case "portal-cliente":
  return <ClientPortalApprovalStudio arqState={arqState} onNavigate={handleNavigate} />;

Rota pública:
Se existir PortalCliente.tsx, integrar PublicProposalPortal nele.
Caso contrário, criar rota pública:
- /arch/proposta/:token
Render:
- <PublicProposalPortal token={token} />

Backend:
Avaliar estrutura real do servidor.
Se compatível, copiar/adaptar:
artifacts/server/modules/arch/client-portal-approval

Registrar router:
createClientPortalApprovalRouter({ db })

Endpoints internos:
GET /arch/propostas?projectId=:projectId
POST /arch/propostas/from-budget
POST /arch/propostas/:id/portal/ativar
POST /arch/propostas/:id/send

Endpoints públicos:
GET /arch/portal/proposta/:token
POST /arch/portal/proposta/:token/items/:itemId/decision
POST /arch/portal/proposta/:token/decision

Banco:
Usar migração:
artifacts/server/migrations/2026_07_09_arch_client_portal_approval.sql

Se o projeto usa Drizzle/RLS/Supabase:
- adaptar ao padrão existente;
- manter tenant_id em arch_proposals;
- rotas públicas devem validar portal_token;
- não expor dados de outro tenant;
- não quebrar portal existente.

Validações:
1. Criar proposta a partir de budgetId.
2. Proposta cria itens a partir dos itens do orçamento.
3. Ativar portal gera token.
4. Link público abre proposta.
5. Visualização pública marca viewed.
6. Cliente aprova item.
7. Cliente reprova item.
8. Cliente comenta item.
9. Cliente aprova proposta inteira.
10. Timeline registra eventos.
11. Status interno atualiza.
12. Typecheck limpo.

Não alterar:
- outros nichos da Vendor.ai;
- autenticação global;
- rotas fora de /arch/*;
- billing;
- marketplace.

Se algum endpoint ou estrutura não existir:
- manter typecheck limpo;
- não inventar mock silencioso;
- retornar erro objetivo;
- informar arquivo/linha para registro de router, rota pública ou migration.
