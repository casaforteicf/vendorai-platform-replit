# Changelog — Sprint 032 Client Portal Approval & Proposal Delivery

## Adicionado
- ClientPortalApprovalStudio.
- PublicProposalPortal.
- Hook interno `useClientPortalApproval`.
- Hook público `usePublicProposalPortal`.
- API client para propostas e portal público.
- Painel de envio de proposta.
- Link público com token.
- Preview cliente.
- Aprovação/reprovação/comentário por item.
- Aprovação/reprovação/revisão final da proposta.
- Timeline de eventos.
- Backend adapter para propostas e aprovações.
- Migração base para propostas, itens, eventos e entregas.

## Resolvido
- Orçamento pode virar proposta de cliente.
- Cliente pode tomar decisão dentro de portal público.
- Status volta para a área interna.
- Histórico de aprovação fica registrado.

## Fora do escopo
- Produção/compras final.
- Assinatura digital.
- Pagamento online.
- Notificações reais via provedor externo.
