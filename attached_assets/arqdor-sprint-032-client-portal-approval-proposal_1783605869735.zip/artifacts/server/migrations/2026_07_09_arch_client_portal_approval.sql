-- Sprint 032 — Client Portal Approval & Proposal Delivery
-- Ajustar schema e RLS conforme padrão real do projeto.

create table if not exists arch_proposals (
  id uuid primary key,
  tenant_id uuid null,
  project_id uuid not null,
  budget_id uuid not null,
  portal_token text null unique,

  title text not null,
  client_name text null,
  client_email text null,
  client_phone text null,

  status text not null default 'draft',
  version integer not null default 1,

  subtotal_material numeric not null default 0,
  subtotal_labor numeric not null default 0,
  subtotal numeric not null default 0,
  discount_total numeric not null default 0,
  grand_total numeric not null default 0,

  expires_at timestamptz null,
  sent_at timestamptz null,
  viewed_at timestamptz null,
  approved_at timestamptz null,
  rejected_at timestamptz null,

  client_notes text null,
  internal_notes text null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists arch_proposal_items (
  id uuid primary key,
  proposal_id uuid not null references arch_proposals(id) on delete cascade,
  budget_item_id uuid null,
  spec_object_id uuid null,

  item text not null,
  description text null,
  quantity numeric not null default 1,
  unit text not null default 'un',

  material_value numeric not null default 0,
  labor_value numeric not null default 0,
  total numeric not null default 0,

  visible_to_client boolean not null default true,
  approval_status text not null default 'pending',
  client_comment text null,
  approved_at timestamptz null,
  rejected_at timestamptz null,

  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists arch_proposal_events (
  id uuid primary key,
  proposal_id uuid not null references arch_proposals(id) on delete cascade,
  type text not null,
  actor_type text not null,
  actor_name text null,
  message text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists arch_proposal_deliveries (
  id uuid primary key,
  proposal_id uuid not null references arch_proposals(id) on delete cascade,
  channel text not null,
  destination text null,
  status text not null default 'pending',
  message text null,
  sent_at timestamptz null,
  error text null,
  created_at timestamptz not null default now()
);

create index if not exists idx_arch_proposals_tenant on arch_proposals (tenant_id);
create index if not exists idx_arch_proposals_project on arch_proposals (project_id);
create index if not exists idx_arch_proposals_budget on arch_proposals (budget_id);
create index if not exists idx_arch_proposals_token on arch_proposals (portal_token);
create index if not exists idx_arch_proposal_items_proposal on arch_proposal_items (proposal_id);
create index if not exists idx_arch_proposal_events_proposal on arch_proposal_events (proposal_id);
create index if not exists idx_arch_proposal_deliveries_proposal on arch_proposal_deliveries (proposal_id);

-- Se o projeto usa Supabase RLS:
-- alter table arch_proposals enable row level security;
-- alter table arch_proposal_items enable row level security;
-- alter table arch_proposal_events enable row level security;
-- alter table arch_proposal_deliveries enable row level security;
--
-- Atenção:
-- Rotas públicas por portal_token devem validar token sem expor outros dados do tenant.
