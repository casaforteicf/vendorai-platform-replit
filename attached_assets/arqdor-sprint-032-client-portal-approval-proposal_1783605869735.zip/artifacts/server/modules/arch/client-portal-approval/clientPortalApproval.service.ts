import type {
  ClientDecisionPayload,
  ClientItemDecisionPayload,
  CreateProposalFromBudgetPayload,
  SendProposalPayload,
} from "./clientPortalApproval.types";

function token() {
  return crypto.randomUUID().replace(/-/g, "");
}

async function addEvent(db: any, proposalId: string, type: string, actorType: string, message: string, metadata: any = {}, actorName: string | null = null) {
  await db.query(
    `
    insert into arch_proposal_events (
      id, proposal_id, type, actor_type, actor_name, message, metadata, created_at
    ) values ($1,$2,$3,$4,$5,$6,$7,now())
    `,
    [crypto.randomUUID(), proposalId, type, actorType, actorName, message, JSON.stringify(metadata || {})],
  );
}

async function getProposalBundleById(db: any, proposalId: string) {
  const proposalResult = await db.query(`select * from arch_proposals where id = $1`, [proposalId]);
  const proposal = proposalResult.rows[0] || null;

  if (!proposal) {
    return { proposal: null, items: [], events: [] };
  }

  const itemsResult = await db.query(
    `select * from arch_proposal_items where proposal_id = $1 order by sort_order asc, created_at asc`,
    [proposal.id],
  );

  const eventsResult = await db.query(
    `select * from arch_proposal_events where proposal_id = $1 order by created_at desc`,
    [proposal.id],
  );

  return {
    proposal,
    items: itemsResult.rows,
    events: eventsResult.rows,
  };
}

export async function getProposalByProject(db: any, params: { tenantId?: string | null; projectId: string }) {
  const values: any[] = [params.projectId];
  let where = `project_id = $1 and deleted_at is null`;

  if (params.tenantId) {
    values.push(params.tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  const proposalResult = await db.query(
    `select * from arch_proposals where ${where} order by created_at desc limit 1`,
    values,
  );

  const proposal = proposalResult.rows[0] || null;

  if (!proposal) {
    return { proposal: null, items: [], events: [] };
  }

  return getProposalBundleById(db, proposal.id);
}

export async function createProposalFromBudget(db: any, tenantId: string | null, payload: CreateProposalFromBudgetPayload) {
  const budgetResult = await db.query(`select * from arch_budgets where id = $1`, [payload.budgetId]);
  const budget = budgetResult.rows[0];

  if (!budget) {
    throw new Error("Orçamento não encontrado");
  }

  const proposalId = crypto.randomUUID();

  const proposalResult = await db.query(
    `
    insert into arch_proposals (
      id, tenant_id, project_id, budget_id, portal_token,
      title, client_name, client_email, client_phone,
      status, version,
      subtotal_material, subtotal_labor, subtotal, discount_total, grand_total,
      expires_at, client_notes, internal_notes, created_at, updated_at
    ) values (
      $1,$2,$3,$4,null,
      $5,$6,$7,$8,
      'ready',1,
      $9,$10,$11,$12,$13,
      $14,$15,$16,now(),now()
    )
    returning *
    `,
    [
      proposalId,
      tenantId,
      payload.projectId,
      payload.budgetId,
      payload.title,
      payload.clientName || budget.client_name || null,
      payload.clientEmail || null,
      payload.clientPhone || null,
      Number(budget.subtotal_material || 0),
      Number(budget.subtotal_labor || 0),
      Number(budget.subtotal || 0),
      Number(budget.discount_total || 0),
      Number(budget.grand_total || 0),
      payload.expiresAt || null,
      budget.client_notes || null,
      budget.internal_notes || null,
    ],
  );

  const budgetItemsResult = await db.query(
    `select * from arch_budget_items where budget_id = $1 and deleted_at is null order by sort_order asc, created_at asc`,
    [payload.budgetId],
  );

  for (const item of budgetItemsResult.rows) {
    if (item.visible_to_client === false) continue;

    await db.query(
      `
      insert into arch_proposal_items (
        id, proposal_id, budget_item_id, spec_object_id,
        item, description, quantity, unit,
        material_value, labor_value, total,
        visible_to_client, approval_status, sort_order, created_at, updated_at
      ) values (
        $1,$2,$3,$4,
        $5,$6,$7,$8,
        $9,$10,$11,
        true,'pending',$12,now(),now()
      )
      `,
      [
        crypto.randomUUID(),
        proposalId,
        item.id,
        item.spec_object_id || null,
        item.item,
        item.description || null,
        Number(item.quantity || 1),
        item.unit || "un",
        Number(item.material_value || 0),
        Number(item.labor_value || 0),
        Number(item.total || 0),
        Number(item.sort_order || 0),
      ],
    );
  }

  await addEvent(db, proposalId, "created", "internal", "Proposta criada a partir do orçamento.", { budgetId: payload.budgetId });

  return getProposalBundleById(db, proposalResult.rows[0].id);
}

export async function activateProposalPortal(db: any, tenantId: string | null, proposalId: string, payload: { regenerateToken?: boolean; expiresAt?: string | null }) {
  const current = await db.query(`select * from arch_proposals where id = $1`, [proposalId]);
  const proposal = current.rows[0];

  if (!proposal) {
    throw new Error("Proposta não encontrada");
  }

  const nextToken = payload.regenerateToken || !proposal.portal_token ? token() : proposal.portal_token;

  const values: any[] = [nextToken, payload.expiresAt || proposal.expires_at || null, proposalId];
  let where = `id = $3`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $4`;
  }

  const result = await db.query(
    `
    update arch_proposals
    set portal_token = $1,
        expires_at = $2,
        updated_at = now()
    where ${where}
    returning *
    `,
    values,
  );

  await addEvent(db, proposalId, "portal-activated", "internal", "Portal público ativado.", { token: nextToken });

  return result.rows[0];
}

export async function sendProposal(db: any, tenantId: string | null, proposalId: string, payload: SendProposalPayload) {
  const values: any[] = [proposalId];
  let where = `id = $1`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  await db.query(
    `
    update arch_proposals
    set status = 'sent',
        sent_at = now(),
        updated_at = now()
    where ${where}
    `,
    values,
  );

  for (const channel of payload.channels || ["portal"]) {
    await db.query(
      `
      insert into arch_proposal_deliveries (
        id, proposal_id, channel, destination, status, message, sent_at, created_at
      ) values ($1,$2,$3,$4,'sent',$5,now(),now())
      `,
      [
        crypto.randomUUID(),
        proposalId,
        channel,
        channel === "email" ? payload.email : channel === "whatsapp" ? payload.phone : null,
        payload.message || null,
      ],
    );
  }

  await addEvent(db, proposalId, "sent", "internal", "Proposta enviada ao cliente.", payload);

  return getProposalBundleById(db, proposalId);
}

export async function getPublicProposal(db: any, portalToken: string) {
  const proposalResult = await db.query(
    `select * from arch_proposals where portal_token = $1 and deleted_at is null`,
    [portalToken],
  );

  const proposal = proposalResult.rows[0];

  if (!proposal) {
    throw new Error("Proposta não encontrada");
  }

  if (!proposal.viewed_at) {
    await db.query(
      `update arch_proposals set status = case when status = 'sent' then 'viewed' else status end, viewed_at = now(), updated_at = now() where id = $1`,
      [proposal.id],
    );
    await addEvent(db, proposal.id, "viewed", "client", "Cliente visualizou a proposta.");
  }

  return getProposalBundleById(db, proposal.id);
}

export async function clientItemDecision(db: any, portalToken: string, itemId: string, payload: ClientItemDecisionPayload) {
  const proposalBundle = await getPublicProposal(db, portalToken);
  const proposal = proposalBundle.proposal;

  if (!proposal) throw new Error("Proposta não encontrada");

  const approvalStatus =
    payload.decision === "approve" ? "approved" :
    payload.decision === "reject" ? "rejected" :
    "commented";

  await db.query(
    `
    update arch_proposal_items
    set approval_status = $1,
        client_comment = $2,
        approved_at = case when $1 = 'approved' then now() else approved_at end,
        rejected_at = case when $1 = 'rejected' then now() else rejected_at end,
        updated_at = now()
    where id = $3 and proposal_id = $4
    `,
    [approvalStatus, payload.comment || null, itemId, proposal.id],
  );

  await addEvent(
    db,
    proposal.id,
    payload.decision === "approve" ? "item-approved" : payload.decision === "reject" ? "item-rejected" : "comment",
    "client",
    payload.decision === "approve" ? "Cliente aprovou um item." : payload.decision === "reject" ? "Cliente reprovou um item." : "Cliente comentou um item.",
    { itemId, comment: payload.comment || null },
  );

  await refreshProposalStatus(db, proposal.id);
  return getProposalBundleById(db, proposal.id);
}

export async function clientFinalDecision(db: any, portalToken: string, payload: ClientDecisionPayload) {
  const proposalBundle = await getPublicProposal(db, portalToken);
  const proposal = proposalBundle.proposal;

  if (!proposal) throw new Error("Proposta não encontrada");

  const status =
    payload.decision === "approve" ? "approved" :
    payload.decision === "reject" ? "rejected" :
    "partially-approved";

  await db.query(
    `
    update arch_proposals
    set status = $1,
        approved_at = case when $1 = 'approved' then now() else approved_at end,
        rejected_at = case when $1 = 'rejected' then now() else rejected_at end,
        updated_at = now()
    where id = $2
    `,
    [status, proposal.id],
  );

  await addEvent(
    db,
    proposal.id,
    payload.decision === "approve" ? "approved" : payload.decision === "reject" ? "rejected" : "revision-requested",
    "client",
    payload.decision === "approve" ? "Cliente aprovou a proposta." : payload.decision === "reject" ? "Cliente reprovou a proposta." : "Cliente solicitou revisão da proposta.",
    { comment: payload.comment || null },
    payload.clientName || null,
  );

  return getProposalBundleById(db, proposal.id);
}

async function refreshProposalStatus(db: any, proposalId: string) {
  const items = await db.query(`select approval_status from arch_proposal_items where proposal_id = $1`, [proposalId]);
  const statuses = items.rows.map((row: any) => row.approval_status);

  if (!statuses.length) return;

  const allApproved = statuses.every((status: string) => status === "approved");
  const anyApproved = statuses.some((status: string) => status === "approved");
  const anyRejected = statuses.some((status: string) => status === "rejected");

  const next =
    allApproved ? "approved" :
    anyApproved || anyRejected ? "partially-approved" :
    null;

  if (!next) return;

  await db.query(
    `update arch_proposals set status = $1, updated_at = now() where id = $2`,
    [next, proposalId],
  );
}
