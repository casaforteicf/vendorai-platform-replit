export type ProposalStatus =
  | "draft"
  | "ready"
  | "sent"
  | "viewed"
  | "partially-approved"
  | "approved"
  | "rejected"
  | "expired"
  | "archived";

export type CreateProposalFromBudgetPayload = {
  projectId: string;
  budgetId: string;
  title: string;
  clientName?: string | null;
  clientEmail?: string | null;
  clientPhone?: string | null;
  expiresAt?: string | null;
};

export type SendProposalPayload = {
  channels: Array<"portal" | "email" | "whatsapp" | "manual">;
  email?: string | null;
  phone?: string | null;
  message?: string | null;
};

export type ClientDecisionPayload = {
  clientName?: string | null;
  comment?: string | null;
  decision: "approve" | "reject" | "revision";
};

export type ClientItemDecisionPayload = {
  decision: "approve" | "reject" | "comment";
  comment?: string | null;
};
