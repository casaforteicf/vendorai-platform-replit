import { Router } from "express";
import {
  activateProposalPortal,
  clientFinalDecision,
  clientItemDecision,
  createProposalFromBudget,
  getProposalByProject,
  getPublicProposal,
  sendProposal,
} from "./clientPortalApproval.service";

export function createClientPortalApprovalRouter(deps: { db: any }) {
  const router = Router();

  function tenantId(req: any) {
    return req?.tenant?.id || req?.user?.tenantId || req?.tenantId || null;
  }

  router.get("/arch/propostas", async (req, res, next) => {
    try {
      const projectId = String(req.query.projectId || "");

      if (!projectId) {
        res.status(400).json({ error: "projectId é obrigatório" });
        return;
      }

      const result = await getProposalByProject(deps.db, {
        tenantId: tenantId(req),
        projectId,
      });

      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/propostas/from-budget", async (req, res, next) => {
    try {
      const result = await createProposalFromBudget(deps.db, tenantId(req), req.body);
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/propostas/:id/portal/ativar", async (req, res, next) => {
    try {
      const proposal = await activateProposalPortal(deps.db, tenantId(req), req.params.id, req.body);
      res.json({ proposal });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/propostas/:id/send", async (req, res, next) => {
    try {
      const result = await sendProposal(deps.db, tenantId(req), req.params.id, req.body);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.get("/arch/portal/proposta/:token", async (req, res, next) => {
    try {
      const result = await getPublicProposal(deps.db, req.params.token);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/portal/proposta/:token/items/:itemId/decision", async (req, res, next) => {
    try {
      const result = await clientItemDecision(deps.db, req.params.token, req.params.itemId, req.body);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/portal/proposta/:token/decision", async (req, res, next) => {
    try {
      const result = await clientFinalDecision(deps.db, req.params.token, req.body);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  return router;
}
