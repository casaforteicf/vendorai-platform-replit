import React, { useMemo } from "react";
import { ApprovalTimelinePanel } from "./ApprovalTimelinePanel";
import { ClientPortalPreview } from "./ClientPortalPreview";
import { PortalDeliveryPanel } from "./PortalDeliveryPanel";
import { ProposalItemsApprovalTable } from "./ProposalItemsApprovalTable";
import { ProposalSummaryCards } from "./ProposalSummaryCards";
import { useClientPortalApproval } from "./useClientPortalApproval";
import { getBudgetId, getClientName, getProjectId, getProjectTitle, proposalStatusClass, proposalStatusLabel } from "./portalUtils";

type ClientPortalApprovalStudioProps = {
  arqState: any;
  onNavigate?: (module: string) => void;
};

export default function ClientPortalApprovalStudio({ arqState, onNavigate }: ClientPortalApprovalStudioProps) {
  const projectId = useMemo(() => getProjectId(arqState), [arqState]);
  const projectTitle = useMemo(() => getProjectTitle(arqState), [arqState]);
  const clientName = useMemo(() => getClientName(arqState), [arqState]);
  const budgetId = useMemo(() => getBudgetId(arqState), [arqState]);

  const {
    proposal,
    items,
    events,
    stats,
    loading,
    creating,
    activating,
    sending,
    error,
    reload,
    createFromBudget,
    activate,
    send,
  } = useClientPortalApproval(projectId, projectTitle, clientName, budgetId);

  return (
    <div className="min-h-screen bg-[#f7f7f8] text-slate-950">
      <div className="mx-auto flex w-full max-w-[1760px] flex-col gap-5 px-6 py-6">
        <header className="rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">Sprint 032 • Client Portal Approval</p>
              <h1 className="mt-1 text-3xl font-semibold tracking-tight text-slate-950">Proposta, portal público e aprovação do cliente</h1>
              <p className="mt-1 text-sm text-slate-500">
                {projectTitle} • orçamento vira proposta, link público com token, aprovação por item e decisão final.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              {proposal ? (
                <span className={`rounded-2xl px-4 py-2 text-sm font-semibold ${proposalStatusClass(proposal.status)}`}>
                  {proposalStatusLabel(proposal.status)}
                </span>
              ) : null}

              <button
                type="button"
                onClick={() => void reload()}
                className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:border-violet-200 hover:text-violet-700"
              >
                {loading ? "Carregando..." : "Atualizar"}
              </button>

              <button
                type="button"
                onClick={() => void createFromBudget()}
                disabled={creating}
                className="rounded-2xl bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
              >
                {creating ? "Criando..." : "Criar proposta do orçamento"}
              </button>

              <button
                type="button"
                onClick={() => onNavigate?.("production")}
                className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:border-violet-200 hover:text-violet-700"
              >
                Produção
              </button>
            </div>
          </div>

          <div className="mt-5 grid gap-3 md:grid-cols-3">
            <Info label="Projeto" value={projectId || "não identificado"} />
            <Info label="Budget ID" value={budgetId || "não identificado pelo estado"} />
            <Info label="Proposta" value={proposal?.id || "ainda não criada"} />
          </div>
        </header>

        {error ? (
          <div className="rounded-[28px] border border-rose-100 bg-rose-50 p-4 text-sm font-medium text-rose-700">
            {error}
          </div>
        ) : null}

        <ProposalSummaryCards proposal={proposal} stats={stats} />

        <div className="grid gap-5 xl:grid-cols-[1.1fr_0.9fr]">
          <div className="space-y-5">
            <ProposalItemsApprovalTable items={items} />
            <ClientPortalPreview proposal={proposal} items={items} />
          </div>

          <div className="space-y-5">
            <PortalDeliveryPanel
              proposal={proposal}
              activating={activating}
              sending={sending}
              onActivate={activate}
              onSend={send}
            />

            <ApprovalTimelinePanel events={events} />
          </div>
        </div>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl bg-slate-50 p-4">
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</p>
      <p className="mt-1 truncate text-sm font-semibold text-slate-800">{value}</p>
    </div>
  );
}
