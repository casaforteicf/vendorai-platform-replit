Aplicar Sprint 013 — Marketplace Enterprise.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/marketplace-enterprise

2. Integrar em ArqWorkspace:
import MarketplaceEnterprise from "./marketplace-enterprise/MarketplaceEnterprise";

3. Usar em case seguro:
case "marketplace":
case "arq-marketplace":
  return <MarketplaceEnterprise arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Marketplace Enterprise;
- resultado typecheck.
