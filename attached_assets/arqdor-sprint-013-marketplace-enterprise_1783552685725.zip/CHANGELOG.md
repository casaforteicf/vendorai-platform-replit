# Changelog — Sprint 013

## Adicionado
- Marketplace Enterprise.
- Catálogo de produtos.
- Diretório de fabricantes.
- Biblioteca de assets.
- Portal fornecedor.
- Pedidos marketplace.
- Analytics.
- AI Marketplace.
