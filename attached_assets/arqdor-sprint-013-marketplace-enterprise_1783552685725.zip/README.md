# Sprint 013 — Marketplace Enterprise

## Arquivos incluídos
- MarketplaceEnterprise.tsx
- marketplaceTypes.ts
- marketplaceData.ts
- marketplaceUtils.ts
- MetricCard.tsx
- MarketplaceHome.tsx
- MarketplaceFilters.tsx
- MarketplaceSearch.tsx
- ProductCard.tsx
- ProductInspector.tsx
- ProductCatalog.tsx
- ManufacturerDirectory.tsx
- AssetLibrary.tsx
- SupplierPortal.tsx
- MarketplaceOrders.tsx
- MarketplaceAnalytics.tsx
- AIMarketplacePanel.tsx

## Objetivo
Criar o Marketplace Enterprise do ARQDOR:
- Catálogo de fabricantes.
- Produtos reais.
- BIM / DWG / SketchUp / PDF / Texturas.
- Publicação de fornecedores.
- Pedidos marketplace.
- Analytics.
- IA de recomendação.
- Integração conceitual com Specification, Budget, Procurement e Production.

## Integração
Importar no ArqWorkspace:

```tsx
import MarketplaceEnterprise from "./marketplace-enterprise/MarketplaceEnterprise";
```

Adicionar/usar case:
```tsx
case "marketplace":
case "arq-marketplace":
  return <MarketplaceEnterprise arqState={arqState} onNavigate={handleNavigate} />;
```
