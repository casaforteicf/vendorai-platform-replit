# Sprint 014 — Client Experience Enterprise

## Arquivos incluídos
- ClientExperience.tsx
- clientExperienceTypes.ts
- clientExperienceData.ts
- clientExperienceUtils.ts
- MetricCard.tsx
- ClientDashboard.tsx
- ClientTimeline.tsx
- ApprovalCenter.tsx
- CommentThread.tsx
- FileLibrary.tsx
- FinancialPanel.tsx
- SchedulePanel.tsx
- SignaturePanel.tsx
- AIClientPanel.tsx

## Objetivo
Criar o Portal Cliente Enterprise:
- Dashboard do cliente.
- Timeline do projeto.
- Aprovações.
- Comentários.
- Arquivos/downloads.
- Financeiro.
- Agenda.
- Assinatura digital.
- AI Client.

## Integração
Importar no ArqWorkspace:

```tsx
import ClientExperience from "./client-experience/ClientExperience";
```

Adicionar/usar case:
```tsx
case "cliente":
case "client":
case "portal-cliente":
  return <ClientExperience arqState={arqState} onNavigate={handleNavigate} />;
```
