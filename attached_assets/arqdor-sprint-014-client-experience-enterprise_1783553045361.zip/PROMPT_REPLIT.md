Aplicar Sprint 014 — Client Experience Enterprise.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/client-experience

2. Integrar em ArqWorkspace:
import ClientExperience from "./client-experience/ClientExperience";

3. Usar em case seguro:
case "cliente":
case "client":
case "portal-cliente":
  return <ClientExperience arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Client Experience;
- resultado typecheck.
