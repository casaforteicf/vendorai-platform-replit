# Changelog — Sprint 014

## Adicionado
- Client Experience Enterprise.
- Dashboard cliente.
- Timeline.
- Approval Center.
- Comment Thread.
- File Library.
- Financial Panel.
- Schedule Panel.
- Signature Panel.
- AI Client.
