Aplicar Sprint 012E — Procurement AI & Analytics.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/procurement-studio/ai-analytics

2. Integrar em ProcurementStudio:
import ProcurementAnalytics from "./ai-analytics/ProcurementAnalytics";

3. Nos views/cases ai, analytics ou reports, renderizar:
return <ProcurementAnalytics onNavigate={onNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print da tela de Procurement AI & Analytics;
- resultado typecheck.
