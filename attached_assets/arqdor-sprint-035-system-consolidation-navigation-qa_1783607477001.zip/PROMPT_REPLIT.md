Aplicar Sprint 035 — ARQDOR System Consolidation, Navigation & QA.

Contexto:
As Sprints 029–034 criaram o fluxo principal:
Render → Especificação → Orçamento → Portal Cliente → Produção → Pós-venda.
Agora não queremos criar novos módulos soltos. Precisamos consolidar navegação, endpoints, permissões, QA e Release Candidate.

Objetivo:
1. Criar tela de consolidação geral.
2. Registrar todos os módulos das Sprints 029–034.
3. Organizar fluxo único de navegação.
4. Mapear endpoints reais.
5. Mapear mocks restantes.
6. Criar release gates.
7. Criar checklist de segurança tenant/RLS.
8. Criar painel de Release Candidate.
9. Validar typecheck.
10. Evitar telas órfãs.

Frontend:
Copiar:
artifacts/frontend/src/modules/arqdor/workspace/system-consolidation-qa

Integrar:
import SystemConsolidationQAStudio from "./system-consolidation-qa/SystemConsolidationQAStudio";

Adicionar case:
case "system-consolidation-qa":
case "qa":
case "release-candidate":
case "system-qa":
case "consolidation-qa":
  return <SystemConsolidationQAStudio arqState={arqState} onNavigate={handleNavigate} />;

Também ajustar o menu lateral do ARQDOR para refletir o fluxo:
1. Projeto
2. Render
3. Especificação
4. Orçamento
5. Portal Cliente
6. Produção
7. Pós-venda
8. QA / Release

Backend:
Avaliar estrutura real do servidor.
Se compatível, copiar/adaptar:
artifacts/server/modules/arch/system-consolidation

Registrar router:
createSystemConsolidationRouter({ db })

Endpoints:
GET /arch/system/consolidation
POST /arch/system/release-gates
POST /arch/system/health-check

Banco:
Usar migração:
artifacts/server/migrations/2026_07_09_arch_system_consolidation_qa.sql

Validações obrigatórias:
1. pnpm typecheck limpo.
2. Tela QA abre pelo menu.
3. Todos os módulos 029–034 aparecem no registro.
4. Fluxo principal navega para cada módulo.
5. Release gates podem ser marcados como passed/failed.
6. Endpoints principais aparecem na matriz.
7. Mocks críticos aparecem listados.
8. Segurança tenant/RLS aparece como checklist.
9. Nenhuma tela nova fica órfã.
10. Build não quebra outros nichos da Vendor.ai.

Não alterar:
- outros nichos da Vendor.ai;
- autenticação global;
- billing;
- marketplace;
- integrações existentes.

Se algum endpoint, router ou tabela não encaixar:
- manter typecheck limpo;
- não inventar mock silencioso;
- retornar erro objetivo;
- informar arquivo/linha para integração.
