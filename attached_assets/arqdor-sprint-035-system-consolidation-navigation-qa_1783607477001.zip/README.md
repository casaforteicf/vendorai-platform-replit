# Sprint 035 — ARQDOR System Consolidation, Navigation & QA

## Objetivo
Consolidar as Sprints 029–034 antes de continuar criando novas funcionalidades.

Fluxo consolidado:

```text
Projeto
↓
Render
↓
Especificação
↓
Orçamento
↓
Portal Cliente
↓
Produção
↓
Pós-venda
↓
CRM / Nova oportunidade
```

## Frontend
Pasta:

```text
artifacts/frontend/src/modules/arqdor/workspace/system-consolidation-qa
```

Arquivos principais:

- `SystemConsolidationQAStudio.tsx`
- `useSystemConsolidationQA.ts`
- `moduleRegistry.ts`
- `consolidationApi.ts`
- `consolidationTypes.ts`
- `consolidationUtils.ts`
- `NavigationFlowPanel.tsx`
- `ModuleRegistryPanel.tsx`
- `EndpointHealthPanel.tsx`
- `ReleaseGatePanel.tsx`
- `MockDebtPanel.tsx`
- `TenantSecurityPanel.tsx`
- `SystemSummaryCards.tsx`

## Backend
Pasta:

```text
artifacts/server/modules/arch/system-consolidation
```

Arquivos:

- `systemConsolidation.routes.ts`
- `systemConsolidation.service.ts`
- `systemConsolidation.types.ts`

Migração:

```text
artifacts/server/migrations/2026_07_09_arch_system_consolidation_qa.sql
```

## Endpoints previstos

- `GET /arch/system/consolidation`
- `POST /arch/system/release-gates`
- `POST /arch/system/health-check`

## Integração no ArqWorkspace

```tsx
import SystemConsolidationQAStudio from "./system-consolidation-qa/SystemConsolidationQAStudio";
```

Adicionar case:

```tsx
case "system-consolidation-qa":
case "qa":
case "release-candidate":
case "system-qa":
case "consolidation-qa":
  return <SystemConsolidationQAStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## O que validar
- Menu lateral com todos os módulos.
- Nenhuma tela nova órfã.
- Endpoints 029–034 registrados.
- Typecheck limpo.
- Portal público seguro.
- Tenant/RLS validado.
- Impressão de orçamento validada.
- Mocks críticos mapeados/removidos.

## Próximo passo
Depois da Sprint 035, o sistema entra em etapa de Release Candidate. A próxima sprint deve ser correções finais/bugfixes, não novo produto.
