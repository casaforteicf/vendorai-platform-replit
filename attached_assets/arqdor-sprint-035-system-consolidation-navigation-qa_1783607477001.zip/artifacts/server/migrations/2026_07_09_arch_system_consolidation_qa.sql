-- Sprint 035 — System Consolidation, Navigation & QA
-- Armazena evidências dos release gates.

create table if not exists arch_release_gates (
  id uuid primary key,
  tenant_id uuid null,
  gate_id text not null unique,
  status text not null default 'pending',
  evidence text null,
  owner text null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_arch_release_gates_tenant on arch_release_gates (tenant_id);
create index if not exists idx_arch_release_gates_status on arch_release_gates (status);

-- Se usa Supabase RLS:
-- alter table arch_release_gates enable row level security;
