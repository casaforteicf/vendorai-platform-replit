import type { ReleaseGatePayload } from "./systemConsolidation.types";

const modules = [
  { id: "render-gallery", sprint: "029", label: "Render real", health: "unknown" },
  { id: "specification-catalog", sprint: "030", label: "Especificação", health: "unknown" },
  { id: "budget-engine", sprint: "031", label: "Orçamento", health: "unknown" },
  { id: "client-portal-approval", sprint: "032", label: "Portal cliente", health: "unknown" },
  { id: "production-procurement", sprint: "033", label: "Produção", health: "unknown" },
  { id: "post-sale", sprint: "034", label: "Pós-venda", health: "unknown" },
];

const endpoints = [
  ["GET", "/arch/renders/gallery", "render-gallery"],
  ["POST", "/arch/ai-render/:id/adjust", "render-gallery"],
  ["GET", "/arch/spec-objects", "specification-catalog"],
  ["POST", "/arch/spec-objects", "specification-catalog"],
  ["GET", "/arch/orcamento", "budget-engine"],
  ["POST", "/arch/orcamento/from-spec-objects", "budget-engine"],
  ["GET", "/arch/propostas", "client-portal-approval"],
  ["GET", "/arch/portal/proposta/:token", "client-portal-approval"],
  ["GET", "/arch/producao", "production-procurement"],
  ["POST", "/arch/producao/from-approval", "production-procurement"],
  ["GET", "/arch/pos-venda", "post-sale"],
  ["POST", "/arch/pos-venda/from-production", "post-sale"],
];

const releaseGates = [
  { id: "gate-typecheck", label: "Typecheck global", description: "pnpm typecheck executado.", status: "pending" },
  { id: "gate-navigation", label: "Navegação unificada", description: "Menu lateral validado.", status: "pending" },
  { id: "gate-real-api", label: "APIs reais", description: "Endpoints críticos validados.", status: "pending" },
  { id: "gate-tenant", label: "Tenant/RLS", description: "Isolamento por tenant validado.", status: "pending" },
  { id: "gate-public-token", label: "Tokens públicos seguros", description: "Tokens públicos não vazam dados.", status: "pending" },
  { id: "gate-print", label: "Impressão orçamento", description: "Impressão validada.", status: "pending" },
  { id: "gate-release-candidate", label: "Release Candidate", description: "Fluxo E2E validado.", status: "pending" },
];

export async function getSystemConsolidation(db: any) {
  let savedGates: any[] = [];

  try {
    const result = await db.query(`select * from arch_release_gates order by created_at desc`);
    savedGates = result.rows || [];
  } catch {
    savedGates = [];
  }

  const mergedGates = releaseGates.map((gate) => {
    const saved = savedGates.find((row: any) => row.gate_id === gate.id);
    return {
      ...gate,
      status: saved?.status || gate.status,
      evidence: saved?.evidence || null,
      owner: saved?.owner || null,
    };
  });

  return {
    modules: modules.map((module) => ({
      ...module,
      kind: module.id,
      routeKeys: [],
      importPath: "",
      componentName: "",
      required: true,
      description: module.label,
      expectedEndpoints: [],
      status: "applied",
    })),
    endpoints: endpoints.map(([method, path, moduleId]) => ({
      method,
      path,
      moduleId,
      required: true,
      description: path,
      health: "unknown",
      lastStatus: null,
      lastCheckedAt: null,
      error: null,
    })),
    mockDebts: [],
    releaseGates: mergedGates,
    flow: [],
    securityChecks: [],
  };
}

export async function saveReleaseGate(db: any, tenantId: string | null, payload: ReleaseGatePayload) {
  await db.query(
    `
    insert into arch_release_gates (
      id, tenant_id, gate_id, status, evidence, created_at, updated_at
    ) values ($1,$2,$3,$4,$5,now(),now())
    on conflict (gate_id)
    do update set status = excluded.status,
                  evidence = excluded.evidence,
                  updated_at = now()
    `,
    [crypto.randomUUID(), tenantId, payload.gateId, payload.status, payload.evidence || null],
  );

  return { ok: true };
}

export async function runSystemHealthCheck(db: any) {
  const bundle = await getSystemConsolidation(db);

  return {
    ...bundle,
    endpoints: bundle.endpoints.map((endpoint: any) => ({
      ...endpoint,
      health: "unknown",
      lastCheckedAt: new Date().toISOString(),
      error: "Health check real deve ser adaptado ao roteador/ambiente do projeto.",
    })),
  };
}
