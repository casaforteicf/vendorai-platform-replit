export type ReleaseGateStatus = "pending" | "passed" | "failed" | "waived";

export type ReleaseGatePayload = {
  gateId: string;
  status: ReleaseGateStatus;
  evidence?: string | null;
};
