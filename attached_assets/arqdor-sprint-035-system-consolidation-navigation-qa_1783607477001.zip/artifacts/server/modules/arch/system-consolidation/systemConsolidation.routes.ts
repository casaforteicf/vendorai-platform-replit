import { Router } from "express";
import {
  getSystemConsolidation,
  runSystemHealthCheck,
  saveReleaseGate,
} from "./systemConsolidation.service";

export function createSystemConsolidationRouter(deps: { db: any }) {
  const router = Router();

  function tenantId(req: any) {
    return req?.tenant?.id || req?.user?.tenantId || req?.tenantId || null;
  }

  router.get("/arch/system/consolidation", async (req, res, next) => {
    try {
      const result = await getSystemConsolidation(deps.db);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/system/release-gates", async (req, res, next) => {
    try {
      const result = await saveReleaseGate(deps.db, tenantId(req), req.body);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/system/health-check", async (req, res, next) => {
    try {
      const result = await runSystemHealthCheck(deps.db);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  return router;
}
