# Sprint 030 — Real Specification Catalog & SpecObject Persistence

## Objetivo
Transformar o Specification Studio em fluxo real:

```text
Render aprovado
↓
SpecObject persistente
↓
Produto / material / fabricante / fornecedor
↓
Quantidade / unidade / ambiente
↓
Valor material
↓
Valor mão de obra
↓
Orçamento
```

## Frontend incluído
Pasta:

```text
artifacts/frontend/src/modules/arqdor/workspace/real-specification-catalog
```

Arquivos principais:

- `RealSpecificationCatalogStudio.tsx`
- `useRealSpecificationCatalog.ts`
- `specCatalogApi.ts`
- `specCatalogTypes.ts`
- `specCatalogUtils.ts`
- `CatalogBrowserPanel.tsx`
- `SpecObjectListPanel.tsx`
- `SpecObjectEditorPanel.tsx`
- `BudgetBridgePanel.tsx`
- `SpecSummaryCards.tsx`

## Backend incluído
Pasta:

```text
artifacts/server/modules/arch/spec-objects
```

Arquivos:

- `specObjects.routes.ts`
- `specObjects.service.ts`
- `specObjects.types.ts`

Migração sugerida:

```text
artifacts/server/migrations/2026_07_09_arch_spec_objects.sql
```

## Endpoints previstos

- `GET /arch/catalogo`
- `GET /arch/spec-objects?projectId=:projectId&renderId=:renderId`
- `POST /arch/spec-objects`
- `PATCH /arch/spec-objects/:id`
- `POST /arch/spec-objects/bulk-from-render`
- `POST /arch/spec-objects/:id/send-to-budget`

## Integração no ArqWorkspace

```tsx
import RealSpecificationCatalogStudio from "./real-specification-catalog/RealSpecificationCatalogStudio";
```

Adicionar case:

```tsx
case "real-specification":
case "spec-catalog":
case "spec-objects":
  return <RealSpecificationCatalogStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Importante
A Sprint 030 deve substituir dados mockados do Specification Studio por dados reais gradualmente. Não deixar a tela nova órfã se o workspace já tem um Specification Studio ativo.

## Próximo passo após aplicar
Validar se o backend já tem estrutura compatível para registrar o router. Se não tiver, retornar o ponto exato de integração para gerarmos Sprint 030B.
