Aplicar Sprint 030 — Real Specification Catalog & SpecObject Persistence.

Contexto:
A Sprint 029 criou o fluxo de render real, melhoria com nova versão, alteração de material e envio do render aprovado para especificação.
Agora precisamos transformar Specification Studio em fluxo real.

Objetivo:
1. Conectar Specification Studio ao /arch/catalogo.
2. Substituir produtos, materiais, fabricantes e fornecedores mockados por catálogo real.
3. Criar/persistir SpecObject.
4. Permitir criar objetos a partir de render aprovado.
5. Cada SpecObject deve ter:
   - projectId
   - ambienteId
   - cenaId
   - renderId
   - nome
   - categoria
   - região
   - quantidade
   - unidade
   - produto
   - material
   - fabricante
   - fornecedor
   - valor material
   - valor mão de obra
   - total
   - status
6. Preparar envio para orçamento.

Frontend:
Copiar:
artifacts/frontend/src/modules/arqdor/workspace/real-specification-catalog

Integrar:
import RealSpecificationCatalogStudio from "./real-specification-catalog/RealSpecificationCatalogStudio";

Adicionar case:
case "real-specification":
case "spec-catalog":
case "spec-objects":
  return <RealSpecificationCatalogStudio arqState={arqState} onNavigate={handleNavigate} />;

Integração ideal:
Se o workspace já usa SpecificationStudio.tsx para especificação, integrar este módulo dentro da tela ativa ou substituir a área mockada de catálogo/objetos.
Não deixar componente órfão.

Backend:
Avaliar a estrutura real do servidor.
Se compatível, copiar/adaptar:
artifacts/server/modules/arch/spec-objects

Registrar router:
createSpecObjectsRouter({ db })

Endpoints esperados:
GET /arch/spec-objects
POST /arch/spec-objects
PATCH /arch/spec-objects/:id
POST /arch/spec-objects/bulk-from-render
POST /arch/spec-objects/:id/send-to-budget

Banco:
Usar a migração:
artifacts/server/migrations/2026_07_09_arch_spec_objects.sql

Se o projeto usa Drizzle/RLS/Supabase com padrão próprio:
- adaptar a migração ao padrão existente;
- manter tenant_id;
- garantir isolamento por tenant;
- não quebrar tabelas existentes.

Não alterar:
- outros nichos da Vendor.ai;
- autenticação global;
- rotas fora de /arch/*;
- billing;
- marketplace.

Rodar:
pnpm typecheck

Validar:
1. /arch/catalogo carrega itens reais.
2. /arch/spec-objects lista objetos do projeto.
3. Criar SpecObject manual salva no backend.
4. Editar produto/material/fornecedor salva no backend.
5. Valores de material e mão de obra aparecem separados.
6. Total calcula corretamente.
7. bulk-from-render cria pelo menos um objeto a partir de renderId.
8. send-to-budget muda status para sent-to-budget.
9. Typecheck limpo.

Se algum endpoint ou estrutura não existir:
- não inventar mock silencioso;
- manter typecheck limpo;
- retornar erro objetivo;
- informar arquivo/linha onde registrar router ou migration.
