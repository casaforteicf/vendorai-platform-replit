-- Sprint 030 — SpecObject persistence
-- Ajustar nomes de schemas/tabelas conforme padrão do projeto.

create table if not exists arch_spec_objects (
  id uuid primary key,
  tenant_id uuid null,
  project_id uuid not null,
  ambiente_id uuid null,
  cena_id uuid null,
  render_id uuid null,
  source_object_id text null,

  name text not null,
  description text null,
  category text null,
  region text null,
  quantity numeric not null default 1,
  unit text not null default 'un',

  catalog_product_id uuid null,
  catalog_material_id uuid null,
  manufacturer_id uuid null,
  supplier_id uuid null,

  product_name text null,
  material_name text null,
  manufacturer_name text null,
  supplier_name text null,

  material_value numeric not null default 0,
  labor_value numeric not null default 0,
  total_value numeric not null default 0,

  notes text null,
  status text not null default 'draft',

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_arch_spec_objects_tenant on arch_spec_objects (tenant_id);
create index if not exists idx_arch_spec_objects_project on arch_spec_objects (project_id);
create index if not exists idx_arch_spec_objects_render on arch_spec_objects (render_id);
create index if not exists idx_arch_spec_objects_status on arch_spec_objects (status);

-- Se o projeto usa RLS Supabase, ativar e criar policies compatíveis com o padrão existente.
-- alter table arch_spec_objects enable row level security;
