import type { SpecObjectPayload } from "./specObjects.types";

/**
 * Sprint 030 service adapter.
 *
 * Ajustar os imports abaixo conforme o padrão real do backend:
 * - db / pool / drizzle
 * - tenantId vindo de req.user, req.tenant ou middleware existente
 *
 * Este arquivo está isolado para facilitar adaptação pelo agente Replit.
 */

function totalValue(payload: Partial<SpecObjectPayload>) {
  const quantity = Number(payload.quantity || 1);
  const material = Number(payload.materialValue || 0);
  const labor = Number(payload.laborValue || 0);
  return quantity * (material + labor);
}

export async function listSpecObjects(db: any, params: { tenantId?: string; projectId: string; renderId?: string }) {
  const values: any[] = [params.projectId];
  let sql = `select * from arch_spec_objects where project_id = $1`;

  if (params.tenantId) {
    values.push(params.tenantId);
    sql += ` and tenant_id = $${values.length}`;
  }

  if (params.renderId) {
    values.push(params.renderId);
    sql += ` and render_id = $${values.length}`;
  }

  sql += ` order by created_at desc`;

  const result = await db.query(sql, values);
  return result.rows;
}

export async function createSpecObject(db: any, tenantId: string | null, payload: SpecObjectPayload) {
  const id = crypto.randomUUID();
  const now = new Date();

  const result = await db.query(
    `
    insert into arch_spec_objects (
      id, tenant_id, project_id, ambiente_id, cena_id, render_id, source_object_id,
      name, description, category, region, quantity, unit,
      catalog_product_id, catalog_material_id, manufacturer_id, supplier_id,
      product_name, material_name, manufacturer_name, supplier_name,
      material_value, labor_value, total_value, notes, status, created_at, updated_at
    ) values (
      $1,$2,$3,$4,$5,$6,$7,
      $8,$9,$10,$11,$12,$13,
      $14,$15,$16,$17,
      $18,$19,$20,$21,
      $22,$23,$24,$25,$26,$27,$28
    )
    returning *
    `,
    [
      id,
      tenantId,
      payload.projectId,
      payload.ambienteId || null,
      payload.cenaId || null,
      payload.renderId || null,
      payload.sourceObjectId || null,
      payload.name,
      payload.description || null,
      payload.category || null,
      payload.region || null,
      Number(payload.quantity || 1),
      payload.unit || "un",
      payload.catalogProductId || null,
      payload.catalogMaterialId || null,
      payload.manufacturerId || null,
      payload.supplierId || null,
      payload.productName || null,
      payload.materialName || null,
      payload.manufacturerName || null,
      payload.supplierName || null,
      Number(payload.materialValue || 0),
      Number(payload.laborValue || 0),
      totalValue(payload),
      payload.notes || null,
      payload.status || "draft",
      now,
      now,
    ],
  );

  return result.rows[0];
}

export async function updateSpecObject(db: any, id: string, tenantId: string | null, payload: Partial<SpecObjectPayload>) {
  const allowed = {
    name: "name",
    description: "description",
    category: "category",
    region: "region",
    quantity: "quantity",
    unit: "unit",
    catalogProductId: "catalog_product_id",
    catalogMaterialId: "catalog_material_id",
    manufacturerId: "manufacturer_id",
    supplierId: "supplier_id",
    productName: "product_name",
    materialName: "material_name",
    manufacturerName: "manufacturer_name",
    supplierName: "supplier_name",
    materialValue: "material_value",
    laborValue: "labor_value",
    notes: "notes",
    status: "status",
  } as const;

  const sets: string[] = [];
  const values: any[] = [];

  Object.entries(allowed).forEach(([key, column]) => {
    if ((payload as any)[key] === undefined) return;
    values.push((payload as any)[key]);
    sets.push(`${column} = $${values.length}`);
  });

  values.push(totalValue(payload));
  sets.push(`total_value = $${values.length}`);

  values.push(new Date());
  sets.push(`updated_at = $${values.length}`);

  values.push(id);
  let where = `id = $${values.length}`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  const result = await db.query(
    `update arch_spec_objects set ${sets.join(", ")} where ${where} returning *`,
    values,
  );

  return result.rows[0];
}

export async function createSpecObjectsFromRender(db: any, tenantId: string | null, payload: {
  projectId: string;
  ambienteId?: string | null;
  cenaId?: string | null;
  renderId: string;
}) {
  /**
   * Versão segura inicial:
   * cria placeholders persistentes.
   * Depois pode ser substituída por extração real via IA/visão.
   */
  const defaults: SpecObjectPayload[] = [
    {
      projectId: payload.projectId,
      ambienteId: payload.ambienteId || null,
      cenaId: payload.cenaId || null,
      renderId: payload.renderId,
      name: "Objeto identificado no render",
      category: "a especificar",
      region: "render aprovado",
      quantity: 1,
      unit: "un",
      materialValue: 0,
      laborValue: 0,
      status: "identified",
      notes: "Criado a partir do render aprovado. Especificar produto, material e fornecedor.",
    },
  ];

  const rows = [];
  for (const item of defaults) {
    rows.push(await createSpecObject(db, tenantId, item));
  }

  return rows;
}
