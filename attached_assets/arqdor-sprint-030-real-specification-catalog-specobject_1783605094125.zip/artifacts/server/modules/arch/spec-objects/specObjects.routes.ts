import { Router } from "express";
import {
  createSpecObject,
  createSpecObjectsFromRender,
  listSpecObjects,
  updateSpecObject,
} from "./specObjects.service";

export function createSpecObjectsRouter(deps: { db: any }) {
  const router = Router();

  function tenantId(req: any) {
    return req?.tenant?.id || req?.user?.tenantId || req?.tenantId || null;
  }

  router.get("/arch/spec-objects", async (req, res, next) => {
    try {
      const projectId = String(req.query.projectId || "");
      const renderId = req.query.renderId ? String(req.query.renderId) : undefined;

      if (!projectId) {
        res.status(400).json({ error: "projectId é obrigatório" });
        return;
      }

      const items = await listSpecObjects(deps.db, {
        tenantId: tenantId(req),
        projectId,
        renderId,
      });

      res.json({ items, total: items.length });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/spec-objects", async (req, res, next) => {
    try {
      const item = await createSpecObject(deps.db, tenantId(req), req.body);
      res.status(201).json({ item });
    } catch (error) {
      next(error);
    }
  });

  router.patch("/arch/spec-objects/:id", async (req, res, next) => {
    try {
      const item = await updateSpecObject(deps.db, req.params.id, tenantId(req), req.body);

      if (!item) {
        res.status(404).json({ error: "SpecObject não encontrado" });
        return;
      }

      res.json({ item });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/spec-objects/bulk-from-render", async (req, res, next) => {
    try {
      const items = await createSpecObjectsFromRender(deps.db, tenantId(req), req.body);
      res.status(201).json({ items, total: items.length });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/spec-objects/:id/send-to-budget", async (req, res, next) => {
    try {
      const item = await updateSpecObject(deps.db, req.params.id, tenantId(req), {
        status: "sent-to-budget",
      } as any);

      /**
       * Próximo passo:
       * integrar com /arch/orcamento/* para criar BudgetItem real.
       */
      res.json({ ok: true, specObjectId: item?.id, budgetItemId: null });
    } catch (error) {
      next(error);
    }
  });

  return router;
}
