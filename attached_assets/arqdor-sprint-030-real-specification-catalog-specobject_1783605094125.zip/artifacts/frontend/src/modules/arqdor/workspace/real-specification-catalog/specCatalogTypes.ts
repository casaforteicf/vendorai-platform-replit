export type SpecObjectStatus =
  | "draft"
  | "identified"
  | "specified"
  | "priced"
  | "approved"
  | "sent-to-budget"
  | "archived";

export type CatalogItemType =
  | "product"
  | "material"
  | "manufacturer"
  | "supplier"
  | "component"
  | "finish";

export type CatalogItem = {
  id: string;
  type: CatalogItemType;
  name: string;
  code?: string | null;
  category?: string | null;
  manufacturer?: string | null;
  supplier?: string | null;
  material?: string | null;
  unit?: string | null;
  price?: number | null;
  laborPrice?: number | null;
  imageUrl?: string | null;
  description?: string | null;
  metadata?: Record<string, unknown>;
};

export type SpecObject = {
  id: string;
  tenantId?: string | null;
  projectId: string;
  ambienteId?: string | null;
  cenaId?: string | null;
  renderId?: string | null;
  sourceObjectId?: string | null;

  name: string;
  description?: string | null;
  category?: string | null;
  region?: string | null;
  quantity: number;
  unit: string;

  catalogProductId?: string | null;
  catalogMaterialId?: string | null;
  manufacturerId?: string | null;
  supplierId?: string | null;

  productName?: string | null;
  materialName?: string | null;
  manufacturerName?: string | null;
  supplierName?: string | null;

  materialValue: number;
  laborValue: number;
  totalValue: number;

  notes?: string | null;
  status: SpecObjectStatus;
  createdAt?: string | null;
  updatedAt?: string | null;
};

export type SpecObjectPayload = {
  projectId: string;
  ambienteId?: string | null;
  cenaId?: string | null;
  renderId?: string | null;
  name: string;
  description?: string | null;
  category?: string | null;
  region?: string | null;
  quantity: number;
  unit: string;
  catalogProductId?: string | null;
  catalogMaterialId?: string | null;
  manufacturerId?: string | null;
  supplierId?: string | null;
  productName?: string | null;
  materialName?: string | null;
  manufacturerName?: string | null;
  supplierName?: string | null;
  materialValue: number;
  laborValue: number;
  notes?: string | null;
  status?: SpecObjectStatus;
};

export type BulkFromRenderPayload = {
  projectId: string;
  ambienteId?: string | null;
  cenaId?: string | null;
  renderId: string;
  preservePrompt: boolean;
  extractObjects: boolean;
};

export type CatalogResponse = {
  items: CatalogItem[];
  total?: number;
};

export type SpecObjectsResponse = {
  items: SpecObject[];
  total?: number;
};

export type ApiResult<T> = {
  data?: T;
  error?: string;
};
