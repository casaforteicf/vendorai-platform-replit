import { useCallback, useEffect, useMemo, useState } from "react";
import {
  applyCatalogItemToSpecObject,
  createSpecObject,
  createSpecObjectsFromRender,
  fetchCatalog,
  fetchSpecObjects,
  sendSpecObjectToBudget,
  updateSpecObject,
} from "./specCatalogApi";
import type { CatalogItem, CatalogItemType, SpecObject, SpecObjectPayload } from "./specCatalogTypes";

export function useRealSpecificationCatalog(projectId: string, renderId?: string) {
  const [catalogItems, setCatalogItems] = useState<CatalogItem[]>([]);
  const [specObjects, setSpecObjects] = useState<SpecObject[]>([]);
  const [selectedObject, setSelectedObject] = useState<SpecObject | null>(null);
  const [catalogType, setCatalogType] = useState<CatalogItemType | "all">("all");
  const [query, setQuery] = useState("");
  const [loadingCatalog, setLoadingCatalog] = useState(false);
  const [loadingObjects, setLoadingObjects] = useState(false);
  const [saving, setSaving] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [sendingToBudget, setSendingToBudget] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const totals = useMemo(() => {
    const material = specObjects.reduce((sum, item) => sum + Number(item.materialValue || 0) * Number(item.quantity || 1), 0);
    const labor = specObjects.reduce((sum, item) => sum + Number(item.laborValue || 0) * Number(item.quantity || 1), 0);

    return {
      material,
      labor,
      total: material + labor,
      count: specObjects.length,
      specified: specObjects.filter((item) => ["specified", "priced", "approved", "sent-to-budget"].includes(item.status)).length,
    };
  }, [specObjects]);

  const loadCatalog = useCallback(async () => {
    setLoadingCatalog(true);
    setError(null);

    const result = await fetchCatalog({ type: catalogType, query, projectId });

    if (result.error) {
      setError(result.error);
      setLoadingCatalog(false);
      return;
    }

    setCatalogItems(result.data?.items || []);
    setLoadingCatalog(false);
  }, [catalogType, projectId, query]);

  const loadSpecObjects = useCallback(async () => {
    if (!projectId) return;

    setLoadingObjects(true);
    setError(null);

    const result = await fetchSpecObjects({ projectId, renderId });

    if (result.error) {
      setError(result.error);
      setLoadingObjects(false);
      return;
    }

    const list = result.data?.items || [];
    setSpecObjects(list);
    setSelectedObject((current) => {
      if (current && list.some((item) => item.id === current.id)) return current;
      return list[0] || null;
    });

    setLoadingObjects(false);
  }, [projectId, renderId]);

  useEffect(() => {
    void loadCatalog();
  }, [loadCatalog]);

  useEffect(() => {
    void loadSpecObjects();
  }, [loadSpecObjects]);

  const addObject = useCallback(
    async (payload: SpecObjectPayload) => {
      setSaving(true);
      setError(null);

      const result = await createSpecObject(payload);

      if (result.error) {
        setError(result.error);
        setSaving(false);
        return null;
      }

      if (result.data) {
        setSpecObjects((current) => [result.data as SpecObject, ...current]);
        setSelectedObject(result.data);
      }

      setSaving(false);
      await loadSpecObjects();
      return result.data || null;
    },
    [loadSpecObjects],
  );

  const saveObject = useCallback(
    async (id: string, payload: Partial<SpecObjectPayload>) => {
      setSaving(true);
      setError(null);

      const result = await updateSpecObject(id, payload);

      if (result.error) {
        setError(result.error);
        setSaving(false);
        return null;
      }

      if (result.data) {
        setSpecObjects((current) => current.map((item) => (item.id === id ? result.data as SpecObject : item)));
        setSelectedObject(result.data);
      }

      setSaving(false);
      await loadSpecObjects();
      return result.data || null;
    },
    [loadSpecObjects],
  );

  const extractFromRender = useCallback(async () => {
    if (!projectId || !renderId) return null;

    setExtracting(true);
    setError(null);

    const result = await createSpecObjectsFromRender({
      projectId,
      renderId,
      preservePrompt: true,
      extractObjects: true,
    });

    if (result.error) {
      setError(result.error);
      setExtracting(false);
      return null;
    }

    const list = result.data?.items || [];
    setSpecObjects(list);
    setSelectedObject(list[0] || null);

    setExtracting(false);
    await loadSpecObjects();
    return list;
  }, [loadSpecObjects, projectId, renderId]);

  const applyCatalogToObject = useCallback(
    async (object: SpecObject, item: CatalogItem) => {
      const payload = applyCatalogItemToSpecObject(object, item);
      return saveObject(object.id, payload);
    },
    [saveObject],
  );

  const sendToBudget = useCallback(
    async (object: SpecObject) => {
      setSendingToBudget(true);
      setError(null);

      const result = await sendSpecObjectToBudget(object.id);

      if (result.error) {
        setError(result.error);
        setSendingToBudget(false);
        return null;
      }

      await saveObject(object.id, { status: "sent-to-budget" } as any);
      setSendingToBudget(false);
      return result.data || null;
    },
    [saveObject],
  );

  return {
    catalogItems,
    specObjects,
    selectedObject,
    setSelectedObject,
    catalogType,
    setCatalogType,
    query,
    setQuery,
    loadingCatalog,
    loadingObjects,
    saving,
    extracting,
    sendingToBudget,
    error,
    totals,
    reloadCatalog: loadCatalog,
    reloadSpecObjects: loadSpecObjects,
    addObject,
    saveObject,
    extractFromRender,
    applyCatalogToObject,
    sendToBudget,
  };
}
