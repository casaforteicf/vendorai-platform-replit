import type {
  ApiResult,
  BulkFromRenderPayload,
  CatalogItem,
  CatalogItemType,
  CatalogResponse,
  SpecObject,
  SpecObjectPayload,
  SpecObjectsResponse,
} from "./specCatalogTypes";
import { getAuthHeaders, normalizeCatalogItem, normalizeSpecObject } from "./specCatalogUtils";

const jsonHeaders = () => ({
  "Content-Type": "application/json",
  ...getAuthHeaders(),
});

async function parseResponse<T>(response: Response): Promise<ApiResult<T>> {
  const text = await response.text();
  const payload = text ? JSON.parse(text) : null;

  if (!response.ok) {
    return {
      error: payload?.message || payload?.error || `Erro HTTP ${response.status}`,
    };
  }

  return { data: payload as T };
}

export async function fetchCatalog(params: {
  type?: CatalogItemType | "all";
  query?: string;
  projectId?: string;
}): Promise<ApiResult<CatalogResponse>> {
  const query = new URLSearchParams();
  if (params.type && params.type !== "all") query.set("type", params.type);
  if (params.query) query.set("q", params.query);
  if (params.projectId) query.set("projectId", params.projectId);

  const response = await fetch(`/arch/catalogo?${query.toString()}`, {
    method: "GET",
    headers: getAuthHeaders(),
  });

  const result = await parseResponse<any>(response);
  if (result.error) return { error: result.error };

  const raw = result.data;
  const items = Array.isArray(raw) ? raw : raw?.items || raw?.data || raw?.catalog || [];

  return {
    data: {
      items: items.map(normalizeCatalogItem),
      total: raw?.total || items.length,
    },
  };
}

export async function fetchSpecObjects(params: {
  projectId: string;
  renderId?: string;
}): Promise<ApiResult<SpecObjectsResponse>> {
  const query = new URLSearchParams();
  query.set("projectId", params.projectId);
  if (params.renderId) query.set("renderId", params.renderId);

  const response = await fetch(`/arch/spec-objects?${query.toString()}`, {
    method: "GET",
    headers: getAuthHeaders(),
  });

  const result = await parseResponse<any>(response);
  if (result.error) return { error: result.error };

  const raw = result.data;
  const items = Array.isArray(raw) ? raw : raw?.items || raw?.data || raw?.objects || [];

  return {
    data: {
      items: items.map(normalizeSpecObject),
      total: raw?.total || items.length,
    },
  };
}

export async function createSpecObject(payload: SpecObjectPayload): Promise<ApiResult<SpecObject>> {
  const response = await fetch("/arch/spec-objects", {
    method: "POST",
    headers: jsonHeaders(),
    body: JSON.stringify(payload),
  });

  const result = await parseResponse<any>(response);
  if (result.error) return { error: result.error };

  return { data: normalizeSpecObject(result.data?.item || result.data?.data || result.data) };
}

export async function updateSpecObject(id: string, payload: Partial<SpecObjectPayload>): Promise<ApiResult<SpecObject>> {
  const response = await fetch(`/arch/spec-objects/${id}`, {
    method: "PATCH",
    headers: jsonHeaders(),
    body: JSON.stringify(payload),
  });

  const result = await parseResponse<any>(response);
  if (result.error) return { error: result.error };

  return { data: normalizeSpecObject(result.data?.item || result.data?.data || result.data) };
}

export async function createSpecObjectsFromRender(payload: BulkFromRenderPayload): Promise<ApiResult<SpecObjectsResponse>> {
  const response = await fetch("/arch/spec-objects/bulk-from-render", {
    method: "POST",
    headers: jsonHeaders(),
    body: JSON.stringify(payload),
  });

  const result = await parseResponse<any>(response);
  if (result.error) return { error: result.error };

  const raw = result.data;
  const items = Array.isArray(raw) ? raw : raw?.items || raw?.data || raw?.objects || [];

  return {
    data: {
      items: items.map(normalizeSpecObject),
      total: raw?.total || items.length,
    },
  };
}

export async function sendSpecObjectToBudget(id: string): Promise<ApiResult<{ ok: boolean; budgetItemId?: string }>> {
  const response = await fetch(`/arch/spec-objects/${id}/send-to-budget`, {
    method: "POST",
    headers: jsonHeaders(),
  });

  return parseResponse<{ ok: boolean; budgetItemId?: string }>(response);
}

export function applyCatalogItemToSpecObject(object: SpecObject, item: CatalogItem): SpecObjectPayload {
  const materialValue = Number(item.price || object.materialValue || 0);
  const laborValue = Number(item.laborPrice || object.laborValue || 0);
  const quantity = Number(object.quantity || 1);

  return {
    projectId: object.projectId,
    ambienteId: object.ambienteId,
    cenaId: object.cenaId,
    renderId: object.renderId,
    name: object.name,
    description: object.description,
    category: object.category || item.category,
    region: object.region,
    quantity,
    unit: item.unit || object.unit || "un",
    catalogProductId: item.type === "product" || item.type === "component" ? item.id : object.catalogProductId,
    catalogMaterialId: item.type === "material" || item.type === "finish" ? item.id : object.catalogMaterialId,
    manufacturerId: item.type === "manufacturer" ? item.id : object.manufacturerId,
    supplierId: item.type === "supplier" ? item.id : object.supplierId,
    productName: item.type === "product" || item.type === "component" ? item.name : object.productName,
    materialName: item.type === "material" || item.type === "finish" ? item.name : item.material || object.materialName,
    manufacturerName: item.type === "manufacturer" ? item.name : item.manufacturer || object.manufacturerName,
    supplierName: item.type === "supplier" ? item.name : item.supplier || object.supplierName,
    materialValue,
    laborValue,
    notes: object.notes,
    status: "specified",
  };
}
