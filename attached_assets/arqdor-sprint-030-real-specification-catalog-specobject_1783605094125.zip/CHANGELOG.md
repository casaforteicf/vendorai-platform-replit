# Changelog — Sprint 030 Real Specification Catalog & SpecObject Persistence

## Adicionado
- RealSpecificationCatalogStudio.
- Hook `useRealSpecificationCatalog`.
- API client para catálogo real.
- API client para SpecObjects.
- Browser de catálogo.
- Lista de SpecObjects persistentes.
- Editor de SpecObject.
- Resumo de valores: material, mão de obra e total.
- Bridge para orçamento.
- Backend adapter para `/arch/spec-objects`.
- SQL base para `arch_spec_objects`.

## Resolvido
- Specification Studio deixa de depender apenas de mock.
- Render aprovado pode virar objeto especificável.
- Cada item pode receber produto, material, fabricante, fornecedor e valores.
- Valores de material e mão de obra ficam separados.
- Fluxo fica pronto para orçamento real.

## Fora do escopo
- Orçamento completo.
- Marketplace transacional.
- Extração IA visual avançada.
- Gateway de pagamento.
