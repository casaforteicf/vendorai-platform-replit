Sprint 019B
- Project API adapter
- Render API adapter
- Service layer
- Fluxo Project→Render
