Aplicar Sprint 019B

1 Copiar pasta project-render-api
2 Integrar repositories ao Project Studio
3 Substituir leitura de mock quando API existir
4 Não alterar backend
5 Não remover fallback
6 Rodar pnpm typecheck

Entregar:
- typecheck
- imports
- telas
- pendências 19C
