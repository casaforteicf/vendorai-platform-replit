# Sprint 019B

Entrega:
- ProjectRepository
- RenderRepository
- ProjectRenderService
- documentação de sincronização

Adicionar:

import ProjectRenderService ...

Cases:
project-render-api
render-api
project-api

Rodar:
pnpm typecheck
