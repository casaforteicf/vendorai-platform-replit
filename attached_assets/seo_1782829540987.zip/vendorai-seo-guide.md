# SEO Completo — Vendor.ai
## Domínio: appvendorai.com

Este documento contém todos os blocos `<head>` prontos para colar em cada página do site. Inclui meta tags, Open Graph, Twitter Card e Schema.org (JSON-LD) estruturado.

---

## 1. PÁGINA HOME (`/`)

Substituir o `<head>` atual (entre `<title>` e o primeiro `<link rel="stylesheet">`) por:

```html
<title>Vendor.ai — CRM com IA para WhatsApp e Instagram | PMEs Brasileiras</title>
<meta name="description" content="Sistema Operacional Empresarial com IA para PMEs. Prospecção, atendimento, orçamento e fechamento direto no WhatsApp e Instagram, com 8 agentes de IA trabalhando 24/7. Verticais para varejo, saúde, imóveis e mais.">
<meta name="keywords" content="CRM WhatsApp, sistema vendas WhatsApp, CRM para PME, automação comercial IA, WhatsApp Business API, CRM brasileiro, agentes de IA vendas, sistema operacional empresarial">
<meta name="author" content="Vendor.ai">
<meta name="robots" content="index, follow">
<link rel="canonical" href="https://appvendorai.com/">

<!-- Open Graph -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://appvendorai.com/">
<meta property="og:title" content="Vendor.ai — O WhatsApp já é seu CRM. A gente deu inteligência pra ele.">
<meta property="og:description" content="Sistema Operacional Empresarial com IA para PMEs brasileiras. Prospecção, atendimento, orçamento e fechamento — tudo no WhatsApp e Instagram, com 8 agentes de IA trabalhando 24/7.">
<meta property="og:image" content="https://appvendorai.com/og-image.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:locale" content="pt_BR">
<meta property="og:site_name" content="Vendor.ai">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:url" content="https://appvendorai.com/">
<meta name="twitter:title" content="Vendor.ai — O WhatsApp já é seu CRM.">
<meta name="twitter:description" content="Sistema Operacional Empresarial com IA para PMEs brasileiras. 8 agentes de IA trabalhando 24/7 no WhatsApp e Instagram.">
<meta name="twitter:image" content="https://appvendorai.com/og-image.png">

<!-- Favicon -->
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">

<!-- Schema.org: Organization -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Vendor.ai",
  "legalName": "Windoor Serviços de Gerenciamento",
  "url": "https://appvendorai.com",
  "logo": "https://appvendorai.com/logo.png",
  "taxID": "59.623.589/0001-27",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Florianópolis",
    "addressRegion": "SC",
    "addressCountry": "BR"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "customer service",
    "email": "vendorai@appvendorai.com",
    "areaServed": "BR",
    "availableLanguage": "Portuguese"
  },
  "sameAs": []
}
</script>

<!-- Schema.org: SoftwareApplication -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "Vendor.ai",
  "applicationCategory": "BusinessApplication",
  "operatingSystem": "Web",
  "description": "Sistema Operacional Empresarial com IA para PMEs brasileiras. CRM, WhatsApp Business API, Instagram, 8 agentes de IA e verticais setoriais.",
  "offers": [
    {
      "@type": "Offer",
      "name": "Growth",
      "price": "1490.00",
      "priceCurrency": "BRL",
      "priceValidUntil": "2026-12-31"
    },
    {
      "@type": "Offer",
      "name": "PME+",
      "price": "1890.00",
      "priceCurrency": "BRL",
      "priceValidUntil": "2026-12-31"
    },
    {
      "@type": "Offer",
      "name": "Enterprise",
      "price": "2490.00",
      "priceCurrency": "BRL",
      "priceValidUntil": "2026-12-31"
    }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.8",
    "ratingCount": "1200"
  }
}
</script>

<!-- Schema.org: FAQPage (sincronizar com o array FAQS do JS) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "O que é a taxa de implantação?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Investimento único que cobre configuração da conta, integração dos canais WhatsApp e Instagram, treinamento dos agentes de IA para o seu negócio e onboarding da equipe."
      }
    },
    {
      "@type": "Question",
      "name": "Como funciona o usuário adicional?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Se o time crescer além do limite do plano, cada usuário extra é cobrado mensalmente sem bloquear cadastros."
      }
    },
    {
      "@type": "Question",
      "name": "Posso usar mais de uma vertical?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Sim. O plano Growth inclui 1 vertical, PME+ e Enterprise permitem combinar verticais conforme seu negócio precisa."
      }
    },
    {
      "@type": "Question",
      "name": "O que é BYOK no plano Enterprise?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Bring Your Own Key — você usa sua própria chave de IA. Ideal para empresas com contrato corporativo e que querem controle total dos custos de IA."
      }
    },
    {
      "@type": "Question",
      "name": "Posso cancelar a qualquer momento?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Sim, sem fidelidade no plano mensal. No anual o valor é pago antecipadamente, mas o uso pode ser pausado quando quiser."
      }
    }
  ]
}
</script>
```

---

## 2. PÁGINA DE VERTICAL (`/verticais/:slug`)

Como o conteúdo é dinâmico (carregado via JS), as meta tags precisam ser **renderizadas no servidor** (SSR) para cada slug — motores de busca não executam JS de forma confiável para ler tags dinâmicas.

### Opção A — Server-side rendering (recomendado)

No backend (rota `/verticais/:slug`), antes de servir o HTML, injetar as tags dinamicamente:

```javascript
// server/routes/site.ts — pseudocódigo de injeção SSR

const VERTICAL_SEO = {
  varejo: {
    title: "Vendor.ai para Varejo e Atacado — CRM com IA no WhatsApp",
    description: "Catálogo integrado, orçamento automático e reativação de carrinho abandonado direto no WhatsApp. +40% de conversão para lojas e atacados.",
  },
  b2b: {
    title: "Vendor.ai para B2B e Serviços — Pipeline de Vendas Consultivas",
    description: "Qualificação por CNPJ, proposta com assinatura digital e agendamento automático. Ciclo de vendas 30% mais curto para consultorias e serviços B2B.",
  },
  saude: {
    title: "Vendor.ai para Clínicas e Consultórios — Agenda e Prontuário com IA",
    description: "Agendamento automático, lembrete de consulta e prontuário eletrônico com CID-10. 60% menos no-show para clínicas e consultórios.",
  },
  beauty: {
    title: "Vendor.ai para Salões e Estúdios de Beleza — Agenda Inteligente",
    description: "Agenda por profissional, lembretes automáticos e Revenue Scout para recompra. Sistema completo para salões e estúdios de estética.",
  },
  imoveis: {
    title: "Vendor.ai para Imobiliárias e Construtoras — Qualificação de Leads",
    description: "Qualifique cada lead antes de alocar um corretor. 3x mais aproveitamento do tráfego pago para imobiliárias e construtoras.",
  },
  arch: {
    title: "Vendor.ai Arch — Orçamento e Render 3D com IA para Arquitetos",
    description: "Orçamento automático, render fotorrealista com IA generativa e marketplace de materiais. Para arquitetos, designers e construtoras.",
  },
};

function injectSEO(html, slug) {
  const seo = VERTICAL_SEO[slug] || VERTICAL_SEO.varejo;
  const url = `https://appvendorai.com/verticais/${slug}`;

  return html
    .replace('<title>Vendor.ai — Vertical</title>', `<title>${seo.title}</title>`)
    .replace('</head>', `
      <meta name="description" content="${seo.description}">
      <link rel="canonical" href="${url}">
      <meta property="og:type" content="website">
      <meta property="og:url" content="${url}">
      <meta property="og:title" content="${seo.title}">
      <meta property="og:description" content="${seo.description}">
      <meta property="og:image" content="https://appvendorai.com/og-image.png">
      <meta property="og:locale" content="pt_BR">
      <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
          {"@type":"ListItem","position":1,"name":"Vendor.ai","item":"https://appvendorai.com/"},
          {"@type":"ListItem","position":2,"name":"Verticais","item":"https://appvendorai.com/#verticais"},
          {"@type":"ListItem","position":3,"name":"${seo.title.split(' — ')[0]}","item":"${url}"}
        ]
      }
      </script>
    </head>`);
}
```

### Opção B — Fallback estático (mais simples, sem SSR)

Se o Replit Agent preferir não implementar SSR agora, criar 6 arquivos HTML estáticos (`/verticais/varejo.html`, etc.) com as tags já fixas no `<head>`, reaproveitando o template `vendorai-pagina-vertical.html` já gerado.

---

## 3. PÁGINA DE PARCEIROS (`/parceiros`)

```html
<title>Programa de Parceiros Vendor.ai — Licença Exclusiva por Cidade</title>
<meta name="description" content="Torne-se parceiro exclusivo da Vendor.ai na sua cidade. Licença única de R$9.900, comissão recorrente de 30% a 40% sobre cada cliente ativo. Cadastre-se.">
<meta name="keywords" content="programa de parceiros, licença exclusiva, revenda software, comissão recorrente, parceiro Vendor.ai">
<link rel="canonical" href="https://appvendorai.com/parceiros">

<meta property="og:type" content="website">
<meta property="og:url" content="https://appvendorai.com/parceiros">
<meta property="og:title" content="Seja o dono da Vendor.ai na sua cidade">
<meta property="og:description" content="Licença exclusiva por cidade. Comissão recorrente de 30% a 40%. Cadastre-se gratuitamente.">
<meta property="og:image" content="https://appvendorai.com/og-image.png">
<meta property="og:locale" content="pt_BR">

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "Licença de Parceiro Vendor.ai",
  "description": "Licença exclusiva de revenda da plataforma Vendor.ai por cidade, com comissão recorrente progressiva.",
  "brand": { "@type": "Brand", "name": "Vendor.ai" },
  "offers": {
    "@type": "Offer",
    "price": "9900.00",
    "priceCurrency": "BRL",
    "availability": "https://schema.org/InStock"
  }
}
</script>
```

---

## 4. ARQUIVO `robots.txt`

Criar em `/public/robots.txt` (raiz do site, acessível em `appvendorai.com/robots.txt`):

```
User-agent: *
Allow: /
Disallow: /api/
Disallow: /onboarding
Disallow: /admin
Disallow: /dashboard
Disallow: /agents/
Disallow: /partner/
Disallow: /arch/
Disallow: /beauty/
Disallow: /clinic/
Disallow: /scout/
Disallow: /financeiro/

Sitemap: https://appvendorai.com/sitemap.xml
```

---

## 5. ARQUIVO `sitemap.xml`

Criar em `/public/sitemap.xml`. Conteúdo já gerado no arquivo anexo `vendorai-sitemap.xml` — copiar direto.

Para tornar dinâmico no futuro (quando houver mais verticais ou páginas), gerar via endpoint:

```javascript
// GET /sitemap.xml
app.get('/sitemap.xml', async (req, res) => {
  const verticais = await db.select().from(siteVerticais).where(eq(siteVerticais.ativo, true));
  const urls = [
    { loc: 'https://appvendorai.com/', priority: '1.0', freq: 'weekly' },
    { loc: 'https://appvendorai.com/parceiros', priority: '0.9', freq: 'weekly' },
    { loc: 'https://appvendorai.com/planos', priority: '0.9', freq: 'weekly' },
    ...verticais.map(v => ({
      loc: `https://appvendorai.com/verticais/${v.slug}`,
      priority: '0.8',
      freq: 'monthly'
    }))
  ];

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(u => `  <url><loc>${u.loc}</loc><changefreq>${u.freq}</changefreq><priority>${u.priority}</priority></url>`).join('\n')}
</urlset>`;

  res.set('Content-Type', 'application/xml');
  res.send(xml);
});
```

---

## 6. OG IMAGE (compartilhamento social)

Arquivo SVG já gerado: `vendorai-og-image.svg` (1200×630px, identidade visual da marca).

**Importante:** WhatsApp, LinkedIn e Twitter exigem PNG ou JPG — SVG não é aceito pela maioria dos crawlers de preview social. Converter no Replit (que tem acesso de rede):

```bash
npm install sharp --save-dev
node -e "
const sharp = require('sharp');
sharp('vendorai-og-image.svg').png().resize(1200, 630).toFile('public/og-image.png');
"
```

Ou usar um conversor online (CloudConvert, svgtopng.com) e salvar o resultado em `/public/og-image.png`.

---

## 7. PERFORMANCE / CORE WEB VITALS (afeta ranking)

Itens que pesam no SEO técnico do Google:

- **Lazy loading de imagens**: adicionar `loading="lazy"` em qualquer `<img>` fora do viewport inicial (o site atual usa só SVG inline, então não há impacto agora — mas vale lembrar quando adicionar fotos reais)
- **Preconnect já implementado**: `fonts.googleapis.com` e `fonts.gstatic.com` já têm `rel="preconnect"` ✓
- **Minificação**: o Replit deve servir o HTML/CSS/JS minificado em produção (verificar build do Vite)
- **Compressão gzip/brotli**: confirmar que o servidor Express está com `compression` middleware ativo

---

## CHECKLIST FINAL

```
[ ] Meta tags da Home aplicadas (title, description, OG, Twitter Card)
[ ] Schema.org Organization + SoftwareApplication + FAQPage na Home
[ ] SEO dinâmico (SSR) ou estático por vertical implementado
[ ] Schema.org Product na página de Parceiros
[ ] robots.txt publicado em /robots.txt
[ ] sitemap.xml publicado em /sitemap.xml (estático ou dinâmico)
[ ] OG image convertida de SVG para PNG e publicada em /og-image.png
[ ] Favicon em 3 tamanhos (16x16, 32x32, apple-touch-icon 180x180)
[ ] Google Search Console configurado com o domínio appvendorai.com
[ ] Sitemap submetido no Google Search Console
```
