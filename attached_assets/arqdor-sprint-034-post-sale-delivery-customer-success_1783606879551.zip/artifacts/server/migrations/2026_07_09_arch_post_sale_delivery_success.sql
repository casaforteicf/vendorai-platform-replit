-- Sprint 034 — Post-Sale, Delivery & Customer Success
-- Ajustar schema e RLS conforme padrão real do projeto.

create table if not exists arch_deliveries (
  id uuid primary key,
  tenant_id uuid null,
  project_id uuid not null,
  proposal_id uuid null,

  client_name text null,
  client_email text null,
  client_phone text null,

  status text not null default 'not-started',
  delivery_date date null,
  accepted_at timestamptz null,
  closed_at timestamptz null,

  nps numeric null,
  satisfaction_score numeric null,
  summary text null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);

create table if not exists arch_delivery_checklist (
  id uuid primary key,
  delivery_id uuid not null references arch_deliveries(id) on delete cascade,
  project_id uuid not null,

  category text not null default 'execution',
  label text not null,
  done boolean not null default false,
  required boolean not null default true,
  responsible text null,
  notes text null,
  completed_at timestamptz null,
  sort_order integer not null default 0,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists arch_delivery_terms (
  id uuid primary key,
  delivery_id uuid not null references arch_deliveries(id) on delete cascade,
  project_id uuid not null,

  title text not null,
  client_name text null,
  content text not null,
  accepted boolean not null default false,
  accepted_by text null,
  accepted_at timestamptz null,
  signature_url text null,
  public_token text null unique,

  created_at timestamptz not null default now()
);

create table if not exists arch_final_documents (
  id uuid primary key,
  delivery_id uuid not null references arch_deliveries(id) on delete cascade,
  project_id uuid not null,

  type text not null default 'other',
  title text not null,
  description text null,
  file_url text null,
  thumbnail_url text null,
  visible_to_client boolean not null default true,

  created_at timestamptz not null default now()
);

create table if not exists arch_satisfaction_surveys (
  id uuid primary key,
  delivery_id uuid not null references arch_deliveries(id) on delete cascade,
  project_id uuid not null,

  status text not null default 'not-sent',
  nps numeric null,
  satisfaction_score numeric null,
  comment text null,
  client_name text null,
  public_token text null unique,

  sent_at timestamptz null,
  answered_at timestamptz null,
  created_at timestamptz not null default now()
);

create table if not exists arch_testimonial_requests (
  id uuid primary key,
  delivery_id uuid not null references arch_deliveries(id) on delete cascade,
  project_id uuid not null,

  status text not null default 'draft',
  channel text not null default 'manual',
  message text not null,
  testimonial text null,
  rating numeric null,
  received_at timestamptz null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists arch_future_opportunities (
  id uuid primary key,
  tenant_id uuid null,
  delivery_id uuid not null references arch_deliveries(id) on delete cascade,
  project_id uuid not null,

  type text not null,
  status text not null default 'identified',
  title text not null,
  description text null,
  estimated_value numeric not null default 0,
  next_action text null,
  due_date date null,
  owner_name text null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists arch_post_sale_events (
  id uuid primary key,
  delivery_id uuid null,
  project_id uuid not null,

  type text not null,
  message text not null,
  actor_type text not null default 'system',
  actor_name text null,
  metadata jsonb not null default '{}'::jsonb,

  created_at timestamptz not null default now()
);

create index if not exists idx_arch_deliveries_tenant on arch_deliveries (tenant_id);
create index if not exists idx_arch_deliveries_project on arch_deliveries (project_id);
create index if not exists idx_arch_delivery_checklist_delivery on arch_delivery_checklist (delivery_id);
create index if not exists idx_arch_delivery_terms_delivery on arch_delivery_terms (delivery_id);
create index if not exists idx_arch_final_documents_delivery on arch_final_documents (delivery_id);
create index if not exists idx_arch_satisfaction_surveys_delivery on arch_satisfaction_surveys (delivery_id);
create index if not exists idx_arch_testimonial_requests_delivery on arch_testimonial_requests (delivery_id);
create index if not exists idx_arch_future_opportunities_delivery on arch_future_opportunities (delivery_id);
create index if not exists idx_arch_future_opportunities_tenant on arch_future_opportunities (tenant_id);
create index if not exists idx_arch_post_sale_events_project on arch_post_sale_events (project_id);

-- Se usa Supabase RLS:
-- alter table arch_deliveries enable row level security;
-- alter table arch_delivery_checklist enable row level security;
-- alter table arch_delivery_terms enable row level security;
-- alter table arch_final_documents enable row level security;
-- alter table arch_satisfaction_surveys enable row level security;
-- alter table arch_testimonial_requests enable row level security;
-- alter table arch_future_opportunities enable row level security;
