import type {
  ChecklistPayload,
  CreatePostSaleFromProductionPayload,
  DeliveryTermPayload,
  FinalDocumentPayload,
  OpportunityPayload,
  SatisfactionPayload,
} from "./postSale.types";

function publicToken() {
  return crypto.randomUUID().replace(/-/g, "");
}

async function addEvent(db: any, projectId: string, deliveryId: string | null, type: string, message: string, actorType = "system", metadata: any = {}) {
  await db.query(
    `
    insert into arch_post_sale_events (
      id, delivery_id, project_id, type, message, actor_type, metadata, created_at
    ) values ($1,$2,$3,$4,$5,$6,$7,now())
    `,
    [crypto.randomUUID(), deliveryId, projectId, type, message, actorType, JSON.stringify(metadata || {})],
  );
}

export async function getPostSaleBundle(db: any, params: { tenantId?: string | null; projectId: string }) {
  const values: any[] = [params.projectId];
  let tenantWhere = "";

  if (params.tenantId) {
    values.push(params.tenantId);
    tenantWhere = ` and tenant_id = $${values.length}`;
  }

  const deliveryResult = await db.query(
    `select * from arch_deliveries where project_id = $1 ${tenantWhere} and deleted_at is null order by created_at desc limit 1`,
    values,
  );

  const delivery = deliveryResult.rows[0] || null;

  if (!delivery) {
    const events = await db.query(
      `select * from arch_post_sale_events where project_id = $1 order by created_at desc limit 80`,
      [params.projectId],
    );

    return {
      delivery: null,
      checklist: [],
      terms: [],
      documents: [],
      surveys: [],
      testimonialRequests: [],
      opportunities: [],
      events: events.rows,
    };
  }

  const deliveryId = delivery.id;

  const checklist = await db.query(
    `select * from arch_delivery_checklist where delivery_id = $1 order by sort_order asc, created_at asc`,
    [deliveryId],
  );

  const terms = await db.query(
    `select * from arch_delivery_terms where delivery_id = $1 order by created_at desc`,
    [deliveryId],
  );

  const documents = await db.query(
    `select * from arch_final_documents where delivery_id = $1 order by created_at desc`,
    [deliveryId],
  );

  const surveys = await db.query(
    `select * from arch_satisfaction_surveys where delivery_id = $1 order by created_at desc`,
    [deliveryId],
  );

  const testimonialRequests = await db.query(
    `select * from arch_testimonial_requests where delivery_id = $1 order by created_at desc`,
    [deliveryId],
  );

  const opportunities = await db.query(
    `select * from arch_future_opportunities where delivery_id = $1 order by created_at desc`,
    [deliveryId],
  );

  const events = await db.query(
    `select * from arch_post_sale_events where project_id = $1 order by created_at desc limit 80`,
    [params.projectId],
  );

  return {
    delivery,
    checklist: checklist.rows,
    terms: terms.rows,
    documents: documents.rows,
    surveys: surveys.rows,
    testimonialRequests: testimonialRequests.rows,
    opportunities: opportunities.rows,
    events: events.rows,
  };
}

export async function createPostSaleFromProduction(db: any, tenantId: string | null, payload: CreatePostSaleFromProductionPayload) {
  const existing = await db.query(
    `select * from arch_deliveries where project_id = $1 and deleted_at is null order by created_at desc limit 1`,
    [payload.projectId],
  );

  if (existing.rows[0]) {
    return getPostSaleBundle(db, { tenantId, projectId: payload.projectId });
  }

  const deliveryId = crypto.randomUUID();

  await db.query(
    `
    insert into arch_deliveries (
      id, tenant_id, project_id, proposal_id,
      client_name, client_email, client_phone,
      status, summary, created_at, updated_at
    ) values (
      $1,$2,$3,$4,
      $5,$6,$7,
      'in-progress',$8,now(),now()
    )
    `,
    [
      deliveryId,
      tenantId,
      payload.projectId,
      payload.proposalId || null,
      payload.clientName || null,
      payload.clientEmail || null,
      payload.clientPhone || null,
      "Pós-venda iniciado a partir da conclusão operacional.",
    ],
  );

  const defaults = [
    ["execution", "Conferir execução conforme projeto aprovado"],
    ["quality", "Conferir acabamento e qualidade final"],
    ["cleaning", "Conferir limpeza final do ambiente"],
    ["documentation", "Anexar fotos finais"],
    ["documentation", "Anexar garantias e manuais"],
    ["client-approval", "Gerar termo de entrega"],
    ["client-approval", "Registrar aceite do cliente"],
    ["warranty", "Orientar cliente sobre garantias e cuidados"],
  ];

  for (let i = 0; i < defaults.length; i += 1) {
    await db.query(
      `
      insert into arch_delivery_checklist (
        id, delivery_id, project_id, category, label, done, required, sort_order, created_at, updated_at
      ) values ($1,$2,$3,$4,$5,false,true,$6,now(),now())
      `,
      [crypto.randomUUID(), deliveryId, payload.projectId, defaults[i][0], defaults[i][1], i],
    );
  }

  await addEvent(db, payload.projectId, deliveryId, "created", "Pós-venda iniciado.", "system");

  return getPostSaleBundle(db, { tenantId, projectId: payload.projectId });
}

export async function createChecklistItem(db: any, tenantId: string | null, payload: ChecklistPayload) {
  const result = await db.query(
    `
    insert into arch_delivery_checklist (
      id, delivery_id, project_id, category, label, done, required,
      responsible, notes, sort_order, created_at, updated_at
    ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,now(),now())
    returning *
    `,
    [
      crypto.randomUUID(),
      payload.deliveryId,
      payload.projectId,
      payload.category,
      payload.label,
      payload.done ?? false,
      payload.required ?? true,
      payload.responsible || null,
      payload.notes || null,
      Number(payload.sortOrder || 0),
    ],
  );

  await addEvent(db, payload.projectId, payload.deliveryId, "checklist-updated", "Item adicionado ao checklist de entrega.", "internal");
  return result.rows[0];
}

export async function updateChecklistItem(db: any, id: string, payload: Partial<ChecklistPayload>) {
  const currentResult = await db.query(`select * from arch_delivery_checklist where id = $1`, [id]);
  const current = currentResult.rows[0];
  if (!current) return null;

  const allowed = {
    category: "category",
    label: "label",
    done: "done",
    required: "required",
    responsible: "responsible",
    notes: "notes",
    sortOrder: "sort_order",
  } as const;

  const sets: string[] = [];
  const values: any[] = [];

  Object.entries(allowed).forEach(([key, column]) => {
    if ((payload as any)[key] === undefined) return;
    values.push((payload as any)[key]);
    sets.push(`${column} = $${values.length}`);
  });

  if (payload.done !== undefined) {
    values.push(payload.done ? new Date() : null);
    sets.push(`completed_at = $${values.length}`);
  }

  values.push(new Date());
  sets.push(`updated_at = $${values.length}`);
  values.push(id);

  const result = await db.query(
    `update arch_delivery_checklist set ${sets.join(", ")} where id = $${values.length} returning *`,
    values,
  );

  await addEvent(db, current.project_id, current.delivery_id, "checklist-updated", "Checklist de entrega atualizado.", "internal", {
    checklistItemId: id,
  });

  return result.rows[0];
}

export async function createDeliveryTerm(db: any, payload: DeliveryTermPayload) {
  const result = await db.query(
    `
    insert into arch_delivery_terms (
      id, delivery_id, project_id, title, client_name, content,
      accepted, public_token, created_at
    ) values ($1,$2,$3,$4,$5,$6,false,$7,now())
    returning *
    `,
    [
      crypto.randomUUID(),
      payload.deliveryId,
      payload.projectId,
      payload.title,
      payload.clientName || null,
      payload.content,
      publicToken(),
    ],
  );

  await addEvent(db, payload.projectId, payload.deliveryId, "term-generated", "Termo de entrega gerado.", "internal");
  return result.rows[0];
}

export async function acceptDeliveryTerm(db: any, termId: string, payload: { acceptedBy?: string; signatureUrl?: string }) {
  const currentResult = await db.query(`select * from arch_delivery_terms where id = $1`, [termId]);
  const current = currentResult.rows[0];
  if (!current) return null;

  const result = await db.query(
    `
    update arch_delivery_terms
    set accepted = true,
        accepted_by = $2,
        accepted_at = now(),
        signature_url = $3
    where id = $1
    returning *
    `,
    [termId, payload.acceptedBy || null, payload.signatureUrl || null],
  );

  await db.query(
    `update arch_deliveries set status = 'accepted', accepted_at = now(), updated_at = now() where id = $1`,
    [current.delivery_id],
  );

  await addEvent(db, current.project_id, current.delivery_id, "term-accepted", "Cliente aceitou o termo de entrega.", "client", {
    acceptedBy: payload.acceptedBy || null,
  });

  return result.rows[0];
}

export async function createFinalDocument(db: any, payload: FinalDocumentPayload) {
  const result = await db.query(
    `
    insert into arch_final_documents (
      id, delivery_id, project_id, type, title, description,
      file_url, thumbnail_url, visible_to_client, created_at
    ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,now())
    returning *
    `,
    [
      crypto.randomUUID(),
      payload.deliveryId,
      payload.projectId,
      payload.type,
      payload.title,
      payload.description || null,
      payload.fileUrl || null,
      payload.thumbnailUrl || null,
      payload.visibleToClient ?? true,
    ],
  );

  await addEvent(db, payload.projectId, payload.deliveryId, "document-added", "Documento final adicionado.", "internal", {
    title: payload.title,
    type: payload.type,
  });

  return result.rows[0];
}

export async function createSatisfactionSurvey(db: any, payload: SatisfactionPayload) {
  const result = await db.query(
    `
    insert into arch_satisfaction_surveys (
      id, delivery_id, project_id, status, nps, satisfaction_score,
      comment, client_name, public_token, sent_at, answered_at, created_at
    ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,now(),$10,now())
    returning *
    `,
    [
      crypto.randomUUID(),
      payload.deliveryId,
      payload.projectId,
      payload.nps !== undefined || payload.satisfactionScore !== undefined ? "answered" : "sent",
      payload.nps ?? null,
      payload.satisfactionScore ?? null,
      payload.comment || null,
      payload.clientName || null,
      publicToken(),
      payload.nps !== undefined || payload.satisfactionScore !== undefined ? new Date() : null,
    ],
  );

  await db.query(
    `update arch_deliveries set nps = $2, satisfaction_score = $3, updated_at = now() where id = $1`,
    [payload.deliveryId, payload.nps ?? null, payload.satisfactionScore ?? null],
  );

  await addEvent(db, payload.projectId, payload.deliveryId, payload.nps !== undefined ? "survey-answered" : "survey-sent", "Pesquisa de satisfação registrada/enviada.", "internal");
  return result.rows[0];
}

export async function createTestimonialRequest(db: any, payload: { deliveryId: string; projectId: string; channel: string; message: string }) {
  const result = await db.query(
    `
    insert into arch_testimonial_requests (
      id, delivery_id, project_id, status, channel, message, created_at, updated_at
    ) values ($1,$2,$3,'sent',$4,$5,now(),now())
    returning *
    `,
    [crypto.randomUUID(), payload.deliveryId, payload.projectId, payload.channel, payload.message],
  );

  await addEvent(db, payload.projectId, payload.deliveryId, "testimonial-requested", "Pedido de depoimento enviado.", "internal", {
    channel: payload.channel,
  });

  return result.rows[0];
}

export async function createFutureOpportunity(db: any, tenantId: string | null, payload: OpportunityPayload) {
  const result = await db.query(
    `
    insert into arch_future_opportunities (
      id, tenant_id, delivery_id, project_id, type, status, title, description,
      estimated_value, next_action, due_date, owner_name, created_at, updated_at
    ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,now(),now())
    returning *
    `,
    [
      crypto.randomUUID(),
      tenantId,
      payload.deliveryId,
      payload.projectId,
      payload.type,
      payload.status || "identified",
      payload.title,
      payload.description || null,
      Number(payload.estimatedValue || 0),
      payload.nextAction || null,
      payload.dueDate || null,
      payload.ownerName || null,
    ],
  );

  await addEvent(db, payload.projectId, payload.deliveryId, "opportunity-created", "Oportunidade futura criada.", "internal", {
    title: payload.title,
    type: payload.type,
  });

  return result.rows[0];
}

export async function updateFutureOpportunity(db: any, id: string, tenantId: string | null, payload: Partial<OpportunityPayload>) {
  const allowed = {
    type: "type",
    status: "status",
    title: "title",
    description: "description",
    estimatedValue: "estimated_value",
    nextAction: "next_action",
    dueDate: "due_date",
    ownerName: "owner_name",
  } as const;

  const sets: string[] = [];
  const values: any[] = [];

  Object.entries(allowed).forEach(([key, column]) => {
    if ((payload as any)[key] === undefined) return;
    values.push((payload as any)[key]);
    sets.push(`${column} = $${values.length}`);
  });

  values.push(new Date());
  sets.push(`updated_at = $${values.length}`);

  values.push(id);
  let where = `id = $${values.length}`;

  if (tenantId) {
    values.push(tenantId);
    where += ` and tenant_id = $${values.length}`;
  }

  const result = await db.query(
    `update arch_future_opportunities set ${sets.join(", ")} where ${where} returning *`,
    values,
  );

  return result.rows[0];
}
