export type CreatePostSaleFromProductionPayload = {
  projectId: string;
  proposalId?: string | null;
  clientName?: string | null;
  clientEmail?: string | null;
  clientPhone?: string | null;
};

export type ChecklistPayload = {
  deliveryId: string;
  projectId: string;
  category: string;
  label: string;
  done?: boolean;
  required?: boolean;
  responsible?: string | null;
  notes?: string | null;
  sortOrder?: number;
};

export type DeliveryTermPayload = {
  deliveryId: string;
  projectId: string;
  title: string;
  clientName?: string | null;
  content: string;
};

export type FinalDocumentPayload = {
  deliveryId: string;
  projectId: string;
  type: string;
  title: string;
  description?: string | null;
  fileUrl?: string | null;
  thumbnailUrl?: string | null;
  visibleToClient?: boolean;
};

export type SatisfactionPayload = {
  deliveryId: string;
  projectId: string;
  clientName?: string | null;
  nps?: number | null;
  satisfactionScore?: number | null;
  comment?: string | null;
};

export type OpportunityPayload = {
  deliveryId: string;
  projectId: string;
  type: string;
  status?: string;
  title: string;
  description?: string | null;
  estimatedValue?: number | null;
  nextAction?: string | null;
  dueDate?: string | null;
  ownerName?: string | null;
};
