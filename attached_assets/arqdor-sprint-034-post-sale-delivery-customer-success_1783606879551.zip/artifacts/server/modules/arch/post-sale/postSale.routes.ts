import { Router } from "express";
import {
  acceptDeliveryTerm,
  createChecklistItem,
  createDeliveryTerm,
  createFinalDocument,
  createFutureOpportunity,
  createPostSaleFromProduction,
  createSatisfactionSurvey,
  createTestimonialRequest,
  getPostSaleBundle,
  updateChecklistItem,
  updateFutureOpportunity,
} from "./postSale.service";

export function createPostSaleRouter(deps: { db: any }) {
  const router = Router();

  function tenantId(req: any) {
    return req?.tenant?.id || req?.user?.tenantId || req?.tenantId || null;
  }

  router.get("/arch/pos-venda", async (req, res, next) => {
    try {
      const projectId = String(req.query.projectId || "");

      if (!projectId) {
        res.status(400).json({ error: "projectId é obrigatório" });
        return;
      }

      const result = await getPostSaleBundle(deps.db, {
        tenantId: tenantId(req),
        projectId,
      });

      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/pos-venda/from-production", async (req, res, next) => {
    try {
      const result = await createPostSaleFromProduction(deps.db, tenantId(req), req.body);
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/pos-venda/delivery-checklist", async (req, res, next) => {
    try {
      const item = await createChecklistItem(deps.db, tenantId(req), req.body);
      res.status(201).json({ item });
    } catch (error) {
      next(error);
    }
  });

  router.patch("/arch/pos-venda/delivery-checklist/:id", async (req, res, next) => {
    try {
      const item = await updateChecklistItem(deps.db, req.params.id, req.body);
      res.json({ item });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/pos-venda/delivery-term", async (req, res, next) => {
    try {
      const term = await createDeliveryTerm(deps.db, req.body);
      res.status(201).json({ term });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/pos-venda/delivery-term/:id/accept", async (req, res, next) => {
    try {
      const term = await acceptDeliveryTerm(deps.db, req.params.id, req.body);
      res.json({ term });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/pos-venda/final-documents", async (req, res, next) => {
    try {
      const document = await createFinalDocument(deps.db, req.body);
      res.status(201).json({ document });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/pos-venda/satisfaction", async (req, res, next) => {
    try {
      const survey = await createSatisfactionSurvey(deps.db, req.body);
      res.status(201).json({ survey });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/pos-venda/testimonial-request", async (req, res, next) => {
    try {
      const request = await createTestimonialRequest(deps.db, req.body);
      res.status(201).json({ request });
    } catch (error) {
      next(error);
    }
  });

  router.post("/arch/pos-venda/opportunities", async (req, res, next) => {
    try {
      const opportunity = await createFutureOpportunity(deps.db, tenantId(req), req.body);
      res.status(201).json({ opportunity });
    } catch (error) {
      next(error);
    }
  });

  router.patch("/arch/pos-venda/opportunities/:id", async (req, res, next) => {
    try {
      const opportunity = await updateFutureOpportunity(deps.db, req.params.id, tenantId(req), req.body);
      res.json({ opportunity });
    } catch (error) {
      next(error);
    }
  });

  return router;
}
