Aplicar Sprint 034 — Post-Sale, Delivery & Customer Success.

Contexto:
A Sprint 033 criou produção, compras, instalação e qualidade.
Agora precisamos fechar o ciclo com entrega, pós-venda, satisfação e oportunidades futuras.

Objetivo:
1. Criar pós-venda a partir da produção concluída.
2. Criar checklist final de entrega.
3. Criar termo de entrega.
4. Registrar aceite do cliente.
5. Anexar documentação final: fotos, vídeos, garantias, manuais, notas e as built.
6. Registrar/enviar pesquisa de satisfação.
7. Registrar NPS/feedback.
8. Solicitar depoimento/indicação.
9. Criar oportunidades futuras:
   - novo ambiente;
   - manutenção;
   - complemento;
   - indicação;
   - upsell de fornecedor;
   - novo projeto.
10. Registrar timeline de pós-venda.
11. Preparar envio de oportunidades para CRM.

Frontend:
Copiar:
artifacts/frontend/src/modules/arqdor/workspace/post-sale-delivery-success

Integrar:
import PostSaleDeliverySuccessStudio from "./post-sale-delivery-success/PostSaleDeliverySuccessStudio";

Adicionar case:
case "post-sale":
case "pos-venda":
case "delivery-success":
case "customer-success":
case "success":
  return <PostSaleDeliverySuccessStudio arqState={arqState} onNavigate={handleNavigate} />;

Backend:
Avaliar estrutura real do servidor.
Se compatível, copiar/adaptar:
artifacts/server/modules/arch/post-sale

Registrar router:
createPostSaleRouter({ db })

Endpoints:
GET /arch/pos-venda?projectId=:projectId
POST /arch/pos-venda/from-production
POST /arch/pos-venda/delivery-checklist
PATCH /arch/pos-venda/delivery-checklist/:id
POST /arch/pos-venda/delivery-term
POST /arch/pos-venda/delivery-term/:id/accept
POST /arch/pos-venda/final-documents
POST /arch/pos-venda/satisfaction
POST /arch/pos-venda/testimonial-request
POST /arch/pos-venda/opportunities
PATCH /arch/pos-venda/opportunities/:id

Banco:
Usar migração:
artifacts/server/migrations/2026_07_09_arch_post_sale_delivery_success.sql

Se usa Drizzle/RLS/Supabase:
- adaptar ao padrão existente;
- manter tenant_id;
- garantir isolamento por tenant;
- não quebrar tabelas existentes.

Validações:
1. Iniciar pós-venda a partir do projeto.
2. Checklist padrão é criado.
3. Marcar item de checklist salva.
4. Gerar termo de entrega salva.
5. Registrar aceite do cliente atualiza status.
6. Adicionar documento final salva.
7. Registrar NPS/feedback salva.
8. Solicitar depoimento registra evento.
9. Criar oportunidade futura salva.
10. Atualizar status de oportunidade salva.
11. Timeline registra eventos.
12. Typecheck limpo.

Não alterar:
- outros nichos da Vendor.ai;
- autenticação global;
- rotas fora de /arch/*;
- billing;
- marketplace.

Se algum endpoint ou estrutura não existir:
- manter typecheck limpo;
- não inventar mock silencioso;
- retornar erro objetivo;
- informar arquivo/linha para registro de router ou migration.
