# Sprint 034 — Post-Sale, Delivery & Customer Success

## Objetivo
Fechar o ciclo do ARQDOR.ai depois da execução:

```text
Produção concluída
↓
Checklist final
↓
Termo de entrega
↓
Fotos finais / documentação
↓
Pesquisa de satisfação
↓
Depoimento / indicação
↓
Oportunidades futuras
```

## Frontend
Pasta:

```text
artifacts/frontend/src/modules/arqdor/workspace/post-sale-delivery-success
```

Arquivos principais:

- `PostSaleDeliverySuccessStudio.tsx`
- `usePostSaleSuccess.ts`
- `postSaleApi.ts`
- `postSaleTypes.ts`
- `postSaleUtils.ts`
- `DeliveryChecklistPanel.tsx`
- `DeliveryTermPanel.tsx`
- `FinalDocumentationPanel.tsx`
- `SatisfactionSurveyPanel.tsx`
- `TestimonialReferralPanel.tsx`
- `FutureOpportunitiesPanel.tsx`
- `PostSaleTimelinePanel.tsx`
- `DeliverySummaryCards.tsx`

## Backend
Pasta:

```text
artifacts/server/modules/arch/post-sale
```

Arquivos:

- `postSale.routes.ts`
- `postSale.service.ts`
- `postSale.types.ts`

Migração:

```text
artifacts/server/migrations/2026_07_09_arch_post_sale_delivery_success.sql
```

## Endpoints previstos

- `GET /arch/pos-venda?projectId=:projectId`
- `POST /arch/pos-venda/from-production`
- `POST /arch/pos-venda/delivery-checklist`
- `PATCH /arch/pos-venda/delivery-checklist/:id`
- `POST /arch/pos-venda/delivery-term`
- `POST /arch/pos-venda/delivery-term/:id/accept`
- `POST /arch/pos-venda/final-documents`
- `POST /arch/pos-venda/satisfaction`
- `POST /arch/pos-venda/testimonial-request`
- `POST /arch/pos-venda/opportunities`
- `PATCH /arch/pos-venda/opportunities/:id`

## Integração no ArqWorkspace

```tsx
import PostSaleDeliverySuccessStudio from "./post-sale-delivery-success/PostSaleDeliverySuccessStudio";
```

Adicionar case:

```tsx
case "post-sale":
case "pos-venda":
case "delivery-success":
case "customer-success":
case "success":
  return <PostSaleDeliverySuccessStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Próximo passo
Depois de aplicar esta sprint, o fluxo principal fica fechado. A próxima etapa deve ser consolidação, QA, permissões e navegação final.
