Aplicar Sprint 016C — IoT & Smart Building.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/iot-smart-building

2. Integrar em ArqWorkspace:
import SmartBuildingCenter from "./iot-smart-building/SmartBuildingCenter";

3. Usar em case seguro:
case "iot":
case "smart-building":
case "building":
  return <SmartBuildingCenter arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Smart Building Center;
- resultado typecheck.
