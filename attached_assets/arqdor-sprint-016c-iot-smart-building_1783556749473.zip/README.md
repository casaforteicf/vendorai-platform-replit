# Sprint 016C — IoT & Smart Building

## Arquivos incluídos
- SmartBuildingCenter.tsx
- iotTypes.ts
- iotData.ts
- iotUtils.ts
- MetricCard.tsx
- IoTDashboard.tsx
- SensorMonitor.tsx
- EnergyAnalytics.tsx
- WaterManagement.tsx
- HVACControl.tsx
- EnvironmentMonitor.tsx
- RealtimeAlerts.tsx
- PredictiveMaintenance.tsx
- AutomationRules.tsx
- DeviceManagement.tsx
- BuildingMap.tsx
- AISmartBuildingPanel.tsx

## Objetivo
Criar o Smart Building Center:
- Dashboard IoT.
- Monitoramento de sensores.
- Energia.
- Água.
- HVAC.
- Ambiente.
- Alertas em tempo real.
- Manutenção preditiva.
- Automações.
- Dispositivos.
- Mapa digital.
- AI Smart Building.

## Integração
Importar no ArqWorkspace:

```tsx
import SmartBuildingCenter from "./iot-smart-building/SmartBuildingCenter";
```

Adicionar/usar case:
```tsx
case "iot":
case "smart-building":
case "building":
  return <SmartBuildingCenter arqState={arqState} onNavigate={handleNavigate} />;
```
