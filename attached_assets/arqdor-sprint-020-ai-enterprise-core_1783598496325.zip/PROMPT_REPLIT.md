Aplicar Sprint 020 — AI Enterprise Core.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/ai-enterprise

2. Integrar no ArqWorkspace:
import AIEnterpriseCore from "./ai-enterprise/AIEnterpriseCore";

3. Adicionar/substituir case:
case "ai-intel":
case "ai-enterprise":
case "ai":
  return <AIEnterpriseCore arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar autenticação.
7. Não alterar outros nichos da Vendor.ai.
8. Manter o ARQDOR isolado em /arch/*.

Rodar:
pnpm typecheck

Se o build direto falhar por PORT/BASE_PATH, validar pelo workflow do Replit conforme regra do workspace.

Validar UI:
- Comando
- Agentes
- Fluxo
- Memória
- Ações
- Integrações
- Governança
- Copilot

Entregar:
- resultado do typecheck;
- print da tela AI Enterprise;
- logs do workflow se houver erro.
