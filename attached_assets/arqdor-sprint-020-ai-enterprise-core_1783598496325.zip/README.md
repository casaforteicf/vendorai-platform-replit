# Sprint 020 — AI Enterprise Core

## Objetivo
Entregar a camada central de IA do ARQDOR.ai, funcionando como cérebro transversal entre:

- Render Studio
- Design Studio
- Specification Studio
- Budget Studio
- Production Studio
- Procurement Studio
- Client Portal
- Vendor.ai CRM

## Arquivos incluídos
- AIEnterpriseCore.tsx
- AICommandCenter.tsx
- AIAgentGrid.tsx
- AIWorkflowMap.tsx
- AIMemoryCenter.tsx
- AIActionQueue.tsx
- AIIntegrationMatrix.tsx
- AIGovernancePanel.tsx
- AIChatCopilot.tsx
- AIInsightCard.tsx
- AIKpiCard.tsx
- aiEnterpriseTypes.ts
- aiEnterpriseData.ts
- aiEnterpriseUtils.ts

## Integração sugerida no ArqWorkspace

Importar:

```tsx
import AIEnterpriseCore from "./ai-enterprise/AIEnterpriseCore";
```

Adicionar ou substituir o case do módulo de IA:

```tsx
case "ai-intel":
case "ai-enterprise":
case "ai":
  return <AIEnterpriseCore arqState={arqState} onNavigate={handleNavigate} />;
```

## Observação
Este pacote entrega a interface enterprise e a arquitetura local do AI Core.
A ligação com LLM real, banco, memória persistente e automações deve ser feita em etapa posterior sobre esta base.
