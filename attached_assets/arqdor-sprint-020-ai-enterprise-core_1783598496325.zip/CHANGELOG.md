# Changelog — Sprint 020 AI Enterprise Core

## Adicionado
- Cérebro ARQDOR.ai.
- Command Center.
- Grade de agentes especialistas.
- Mapa de fluxo inteligente.
- Memória de decisões.
- Fila de ações sugeridas.
- Matriz de integrações.
- Painel de governança.
- Copilot textual.
- Tipos, dados e utils centralizados.

## Escopo
- Interface enterprise.
- Arquitetura local preparada para integração real.
- Isolamento dentro de /arch/*.

## Fora do escopo desta entrega
- Chamada real para LLM.
- Persistência em banco.
- Execução real de ações.
- Integração backend.
