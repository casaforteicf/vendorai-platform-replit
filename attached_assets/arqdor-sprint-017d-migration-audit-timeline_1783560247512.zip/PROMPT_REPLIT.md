Aplicar Sprint 017D — Migration Center + Audit + Integration Timeline.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-hub/migration-audit

2. Integrar em ArqWorkspace ou IntegrationHub:
import MigrationAuditCenter from "./integration-hub/migration-audit/MigrationAuditCenter";

3. Usar em case seguro:
case "migration":
case "migration-audit":
case "mock-migration":
  return <MigrationAuditCenter onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Migration Audit Center;
- resultado typecheck.
