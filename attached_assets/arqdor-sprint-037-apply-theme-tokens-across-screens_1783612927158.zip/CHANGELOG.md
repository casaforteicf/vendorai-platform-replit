# Changelog — Sprint 037 Apply Theme Tokens Across ARQDOR Screens

## Adicionado
- ThemeTokenMigrationStudio.
- Matriz de alvos 029–035.
- Matriz de substituições visuais.
- CSS complementar `arqdor-theme-extensions.css`.
- Script de auditoria de classes fixas.
- Script de migração segura com dry-run.

## Resolvido
- Prepara migração visual real para tema claro/escuro.
- Ajuda a remover `bg-[#f7f7f8]`, `bg-white`, `text-slate-*`, `border-slate-*`.
- Mantém render escuro e print do orçamento branco.

## Fora do escopo
- Redesign completo de UX.
- White-label por tenant.
- Backend.
- Novas funcionalidades de produto.
