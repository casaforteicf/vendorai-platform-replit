Aplicar Sprint 037 — Apply Theme Tokens Across ARQDOR Screens.

Contexto:
A Sprint 036 já foi aplicada com sucesso. O tema claro/escuro funciona, mas as telas 029–035 ainda possuem muitas classes fixas.

Objetivo:
1. Importar `arqdor-theme-extensions.css`.
2. Registrar `ThemeTokenMigrationStudio`.
3. Rodar auditoria de classes fixas.
4. Aplicar substituição segura nas telas ARQDOR.
5. Revisar manualmente pontos críticos.
6. Garantir contraste no tema escuro.
7. Manter impressão do orçamento branca.
8. Manter render/preview escuro.
9. Manter portal público claro por padrão.
10. Rodar `pnpm typecheck`.

Copiar arquivos:
- `artifacts/frontend/src/modules/arqdor/workspace/theme-token-migration`
- `artifacts/frontend/src/modules/arqdor/theme/arqdor-theme-extensions.css`
- `tools/arqdor/check-theme-token-migration.mjs`
- `tools/arqdor/apply-theme-token-migration.mjs`

Importar CSS extra:
```tsx
import "./modules/arqdor/theme/arqdor-theme-extensions.css";
```

Registrar studio:
```tsx
import ThemeTokenMigrationStudio from "./theme-token-migration/ThemeTokenMigrationStudio";
```

Adicionar case:
```tsx
case "theme-token-migration":
case "theme-migration":
case "apply-theme":
case "visual-polish":
  return <ThemeTokenMigrationStudio arqState={arqState} onNavigate={handleNavigate} />;
```

Rodar:
```bash
node tools/arqdor/check-theme-token-migration.mjs
node tools/arqdor/apply-theme-token-migration.mjs --dry-run
```

Se o dry-run listar apenas arquivos esperados, rodar:
```bash
node tools/arqdor/apply-theme-token-migration.mjs --write
```

Revisar manualmente:
1. `real-render-gallery`: preview em `arq-render-workspace`.
2. `real-budget-engine`: impressão/PDF continua branco.
3. `client-portal-approval`: portal público continua claro.
4. `production-procurement-execution`: Kanban e selects legíveis.
5. `system-consolidation-qa`: tabelas legíveis.

Validações:
- `pnpm typecheck` limpo.
- Tema claro correto.
- Tema escuro correto.
- Toggle ☀️/🌙 afeta telas internas ARQDOR.
- Nenhuma regra de negócio alterada.

Não alterar backend, billing, lógica de render, orçamento, proposta, produção ou pós-venda.
