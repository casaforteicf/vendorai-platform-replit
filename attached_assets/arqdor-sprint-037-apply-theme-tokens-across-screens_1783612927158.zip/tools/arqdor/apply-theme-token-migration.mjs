#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
const args=new Set(process.argv.slice(2));
const write=args.has("--write");
const root=process.cwd();
const targetRoot=path.join(root,"artifacts/frontend/src/modules/arqdor/workspace");
const folders=["real-render-gallery","real-specification-catalog","real-budget-engine","client-portal-approval","production-procurement-execution","post-sale-delivery-success","system-consolidation-qa"];
const replacements=[
  ["min-h-screen bg-[#f7f7f8] text-slate-950","arq-page"],
  ["bg-[#f7f7f8] text-slate-950","arq-page"],
  ["bg-[#f7f7f8]","arq-page"],
  ["rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm","arq-card arq-card-lg"],
  ["rounded-[28px] border border-slate-100 bg-white p-5 shadow-sm","arq-card arq-card-lg"],
  ["rounded-[26px] border border-slate-100 bg-white p-4 shadow-sm","arq-card"],
  ["border-slate-100","border-[color:var(--arq-border)]"],
  ["border-slate-200","border-[color:var(--arq-border)]"],
  ["text-slate-950","text-[color:var(--arq-foreground)]"],
  ["text-slate-900","text-[color:var(--arq-foreground)]"],
  ["text-slate-800","text-[color:var(--arq-foreground)]"],
  ["text-slate-600","text-[color:var(--arq-muted)]"],
  ["text-slate-500","text-[color:var(--arq-muted)]"],
  ["text-slate-400","text-[color:var(--arq-muted)]"],
  ["bg-violet-600","bg-[color:var(--arq-accent)]"],
  ["hover:bg-violet-700","hover:opacity-90"]
];
function walk(dir){ if(!fs.existsSync(dir)) return []; const out=[]; for(const e of fs.readdirSync(dir,{withFileTypes:true})){ const f=path.join(dir,e.name); if(e.isDirectory()) out.push(...walk(f)); if(e.isFile() && /\.tsx$/.test(e.name)) out.push(f);} return out; }
let changed=0; const files=[];
for(const folder of folders){ for(const file of walk(path.join(targetRoot,folder))){ let text=fs.readFileSync(file,"utf8"), next=text; for(const [a,b] of replacements) next=next.split(a).join(b); if(next!==text){ changed++; files.push(path.relative(root,file)); if(write) fs.writeFileSync(file,next,"utf8"); } } }
console.log(`${write?"WRITE":"DRY RUN"} — arquivos ${write?"alterados":"que seriam alterados"}: ${changed}`);
for(const f of files) console.log(`- ${f}`);
if(!write) console.log("\nPara aplicar: node tools/arqdor/apply-theme-token-migration.mjs --write");
