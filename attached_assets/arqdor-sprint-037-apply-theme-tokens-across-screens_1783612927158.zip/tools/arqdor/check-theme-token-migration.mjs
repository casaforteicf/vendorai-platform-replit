#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
const root = process.cwd();
const targetRoot = path.join(root, "artifacts/frontend/src/modules/arqdor/workspace");
const patterns = ["bg-[#f7f7f8]","bg-white","bg-slate-50","text-slate-950","text-slate-900","text-slate-800","text-slate-600","text-slate-500","text-slate-400","border-slate-100","border-slate-200","bg-violet-600","hover:bg-violet-700"];
function walk(dir){ if(!fs.existsSync(dir)) return []; const out=[]; for(const e of fs.readdirSync(dir,{withFileTypes:true})){ const f=path.join(dir,e.name); if(e.isDirectory()) out.push(...walk(f)); if(e.isFile() && /\.(tsx|ts)$/.test(e.name)) out.push(f);} return out; }
const findings=[];
for(const file of walk(targetRoot)){ const text=fs.readFileSync(file,"utf8"); for(const p of patterns){ const count=text.split(p).length-1; if(count>0) findings.push({file:path.relative(root,file),pattern:p,count}); } }
if(!findings.length){ console.log("✅ Nenhuma classe fixa crítica encontrada."); process.exit(0); }
console.log("⚠️ Classes fixas encontradas:");
for(const f of findings) console.log(`${f.file} :: ${f.pattern} (${f.count})`);
console.log(`\nTotal: ${findings.reduce((s,f)=>s+f.count,0)} ocorrências.`);
process.exit(1);
