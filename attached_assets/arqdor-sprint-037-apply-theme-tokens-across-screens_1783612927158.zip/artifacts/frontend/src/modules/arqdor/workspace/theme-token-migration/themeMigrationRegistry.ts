import type { ThemeMigrationTarget } from "./themeMigrationTypes";

export const THEME_REPLACEMENTS = [
  { from: "min-h-screen bg-[#f7f7f8] text-slate-950", to: "arq-page", type: "container", note: "Container principal." },
  { from: "bg-[#f7f7f8]", to: "arq-page", type: "container", note: "Wrapper principal." },
  { from: "rounded-[34px] border border-slate-100 bg-white p-5 shadow-sm", to: "arq-card arq-card-lg", type: "card", note: "Card grande." },
  { from: "rounded-[28px] border border-slate-100 bg-white p-5 shadow-sm", to: "arq-card arq-card-lg", type: "card", note: "Card secundário." },
  { from: "rounded-[26px] border border-slate-100 bg-white p-4 shadow-sm", to: "arq-card", type: "card", note: "Card pequeno, revisar padding." },
  { from: "bg-slate-50", to: "arq-soft", type: "surface", note: "Área interna suave." },
  { from: "text-slate-950", to: "text-[color:var(--arq-foreground)]", type: "text", note: "Texto principal." },
  { from: "text-slate-900", to: "text-[color:var(--arq-foreground)]", type: "text", note: "Texto principal." },
  { from: "text-slate-800", to: "text-[color:var(--arq-foreground)]", type: "text", note: "Texto principal." },
  { from: "text-slate-600", to: "text-[color:var(--arq-muted)]", type: "text", note: "Texto secundário." },
  { from: "text-slate-500", to: "text-[color:var(--arq-muted)]", type: "text", note: "Texto secundário." },
  { from: "text-slate-400", to: "text-[color:var(--arq-muted)]", type: "text", note: "Texto auxiliar." },
  { from: "border-slate-100", to: "border-[color:var(--arq-border)]", type: "border", note: "Borda tokenizada." },
  { from: "border-slate-200", to: "border-[color:var(--arq-border)]", type: "border", note: "Borda tokenizada." },
  { from: "bg-violet-600", to: "bg-[color:var(--arq-accent)]", type: "button", note: "Accent do usuário." },
  { from: "hover:bg-violet-700", to: "hover:opacity-90", type: "button", note: "Hover neutro." }
] as const;

export const THEME_MIGRATION_TARGETS: ThemeMigrationTarget[] = [
  { id: "s029", sprint: "029", moduleName: "Real Render Gallery", pathHint: "workspace/real-render-gallery", priority: "critical", status: "pending", qaChecks: ["Preview usa arq-render-workspace.", "Botões de melhoria/material têm contraste.", "Histórico e inspector acompanham claro/escuro."] },
  { id: "s030", sprint: "030", moduleName: "Real Specification Catalog", pathHint: "workspace/real-specification-catalog", priority: "high", status: "pending", qaChecks: ["Catálogo legível.", "SpecObjects legíveis.", "Botões de orçamento visíveis."] },
  { id: "s031", sprint: "031", moduleName: "Real Budget Engine", pathHint: "workspace/real-budget-engine", priority: "critical", status: "pending", qaChecks: ["Tela muda com tema.", "Print/PDF continua branco.", "Material e mão de obra continuam aparecendo."] },
  { id: "s032", sprint: "032", moduleName: "Client Portal Approval", pathHint: "workspace/client-portal-approval", priority: "high", status: "pending", qaChecks: ["Interno acompanha tema.", "Portal público permanece claro por padrão.", "Aprovar/revisar/reprovar têm contraste."] },
  { id: "s033", sprint: "033", moduleName: "Production Procurement Execution", pathHint: "workspace/production-procurement-execution", priority: "high", status: "pending", qaChecks: ["Kanban legível.", "Selects de status legíveis.", "Fornecedor e agenda legíveis."] },
  { id: "s034", sprint: "034", moduleName: "Post-Sale Delivery Success", pathHint: "workspace/post-sale-delivery-success", priority: "medium", status: "pending", qaChecks: ["Checklist legível.", "Termo legível.", "Oportunidades legíveis."] },
  { id: "s035", sprint: "035", moduleName: "System Consolidation QA", pathHint: "workspace/system-consolidation-qa", priority: "medium", status: "pending", qaChecks: ["Tabelas legíveis.", "Release gates legíveis.", "Mocks e segurança legíveis."] }
];
