import React, { useMemo } from "react";
import { ArqdorThemeProvider } from "../../theme/ArqdorThemeProvider";
import { ArqdorThemeToggle } from "../../theme/ArqdorThemeToggle";
import { THEME_MIGRATION_TARGETS, THEME_REPLACEMENTS } from "./themeMigrationRegistry";

export default function ThemeTokenMigrationStudio({ onNavigate }: { arqState: any; onNavigate?: (module: string) => void }) {
  const report = useMemo(() => ({
    totalTargets: THEME_MIGRATION_TARGETS.length,
    convertedTargets: THEME_MIGRATION_TARGETS.filter((t) => t.status === "converted").length,
    remainingFixedClasses: 0,
    contrastIssues: 0,
    readyForDarkMode: false,
  }), []);

  return (
    <ArqdorThemeProvider>
      <div className="arq-page">
        <div className="arq-container">
          <header className="arq-card arq-card-lg">
            <div className="arq-section-header">
              <div>
                <p className="arq-eyebrow">Sprint 037 • Apply Theme Tokens</p>
                <h1 className="arq-hero-title">Migração visual claro/escuro</h1>
                <p className="arq-subtitle">Substitui cores fixas das telas 029–035 por tokens globais arq-*.</p>
              </div>
              <div className="arq-header-actions">
                <ArqdorThemeToggle />
                <button type="button" className="arq-button arq-button-secondary" onClick={() => onNavigate?.("theme-system")}>Tema</button>
              </div>
            </div>
          </header>

          <section className="arq-grid-3" style={{ gridTemplateColumns: "repeat(5, minmax(0, 1fr))" }}>
            {[
              ["Telas alvo", report.totalTargets],
              ["Convertidas", report.convertedTargets],
              ["Classes fixas", report.remainingFixedClasses],
              ["Contraste", report.contrastIssues],
              ["Dark mode", report.readyForDarkMode ? "Pronto" : "Revisar"],
            ].map(([label, value]) => (
              <div key={String(label)} className="arq-card arq-card-lg">
                <p className="arq-eyebrow">{label}</p>
                <p className="arq-hero-title" style={{ fontSize: 28 }}>{value}</p>
              </div>
            ))}
          </section>

          <section className="arq-card arq-card-lg">
            <p className="arq-eyebrow">Alvos</p>
            <h2 className="arq-title">Telas para migrar</h2>
            <div style={{ display: "grid", gap: 14, marginTop: 18 }}>
              {THEME_MIGRATION_TARGETS.map((target) => (
                <article key={target.id} className="arq-soft" style={{ padding: 16 }}>
                  <p className="arq-eyebrow">Sprint {target.sprint}</p>
                  <h3 className="arq-title" style={{ fontSize: 18 }}>{target.moduleName}</h3>
                  <p className="arq-subtitle"><code>{target.pathHint}</code> • prioridade {target.priority}</p>
                  <ul style={{ marginTop: 12 }}>
                    {target.qaChecks.map((check) => <li key={check} className="arq-subtitle">{check}</li>)}
                  </ul>
                </article>
              ))}
            </div>
          </section>

          <section className="arq-card arq-card-lg">
            <p className="arq-eyebrow">Substituições</p>
            <h2 className="arq-title">Matriz de troca</h2>
            <div style={{ overflowX: "auto", marginTop: 18 }}>
              <table className="arq-table">
                <thead><tr><th>Tipo</th><th>Atual</th><th>Novo</th><th>Nota</th></tr></thead>
                <tbody>
                  {THEME_REPLACEMENTS.map((item) => (
                    <tr key={`${item.from}-${item.to}`}>
                      <td>{item.type}</td><td><code>{item.from}</code></td><td><code>{item.to}</code></td><td>{item.note}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="arq-card arq-card-lg">
            <p className="arq-eyebrow">Comandos</p>
            <h2 className="arq-title">Auditar e aplicar</h2>
            <pre style={{ marginTop: 16, overflowX: "auto", background: "var(--arq-render-bg)", color: "var(--arq-render-text)", padding: 16, borderRadius: 18 }}>
              <code>{`node tools/arqdor/check-theme-token-migration.mjs\nnode tools/arqdor/apply-theme-token-migration.mjs --dry-run\nnode tools/arqdor/apply-theme-token-migration.mjs --write\npnpm typecheck`}</code>
            </pre>
          </section>
        </div>
      </div>
    </ArqdorThemeProvider>
  );
}
