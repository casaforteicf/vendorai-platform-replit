export type ThemeMigrationStatus = "pending" | "in-progress" | "converted" | "needs-review" | "blocked";
export type ThemeMigrationSeverity = "low" | "medium" | "high" | "critical";
export type ThemeMigrationTarget = {
  id: string;
  sprint: string;
  moduleName: string;
  pathHint: string;
  priority: ThemeMigrationSeverity;
  status: ThemeMigrationStatus;
  qaChecks: string[];
};
export type ThemeMigrationReport = {
  totalTargets: number;
  convertedTargets: number;
  remainingFixedClasses: number;
  contrastIssues: number;
  readyForDarkMode: boolean;
};
