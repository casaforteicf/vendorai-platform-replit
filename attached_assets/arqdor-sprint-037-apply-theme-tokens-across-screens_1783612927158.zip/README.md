# Sprint 037 — Apply Theme Tokens Across ARQDOR Screens

## Objetivo
Aplicar o sistema de tema criado na Sprint 036 nas telas operacionais do ARQDOR.

Depois desta sprint, o botão ☀️/🌙 deve mudar visualmente:

```text
Background
Cards
Textos
Bordas
Botões
Áreas internas
```

## Telas alvo

- Sprint 029 — Real Render Gallery
- Sprint 030 — Real Specification Catalog
- Sprint 031 — Real Budget Engine
- Sprint 032 — Client Portal Approval
- Sprint 033 — Production / Procurement / Execution
- Sprint 034 — Post-Sale / Delivery / Success
- Sprint 035 — System Consolidation / QA

## Arquivos adicionados

```text
artifacts/frontend/src/modules/arqdor/workspace/theme-token-migration
artifacts/frontend/src/modules/arqdor/theme/arqdor-theme-extensions.css
tools/arqdor/check-theme-token-migration.mjs
tools/arqdor/apply-theme-token-migration.mjs
```

## Integração

Importar CSS extra depois do CSS da Sprint 036:

```tsx
import "./modules/arqdor/theme/arqdor-theme.css";
import "./modules/arqdor/theme/arqdor-theme-extensions.css";
```

Adicionar studio:

```tsx
import ThemeTokenMigrationStudio from "./theme-token-migration/ThemeTokenMigrationStudio";
```

Adicionar case:

```tsx
case "theme-token-migration":
case "theme-migration":
case "apply-theme":
case "visual-polish":
  return <ThemeTokenMigrationStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Comandos

```bash
node tools/arqdor/check-theme-token-migration.mjs
node tools/arqdor/apply-theme-token-migration.mjs --dry-run
node tools/arqdor/apply-theme-token-migration.mjs --write
pnpm typecheck
```

## Pontos de revisão manual

- Render/preview deve usar `arq-render-workspace`.
- Print do orçamento deve permanecer branco.
- Portal público do cliente deve ficar claro por padrão.
- Tabelas e selects precisam revisão de contraste.
- Badges/status precisam contraste no tema escuro.
