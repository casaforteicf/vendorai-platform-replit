Aplicar Sprint 015D — Executive Command Center.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/operations-center/executive-command

2. Integrar em OperationsCenter ou ArqWorkspace:
import ExecutiveCockpit from "./operations-center/executive-command/ExecutiveCockpit";

3. Usar em case seguro:
case "executive":
case "executive-command":
case "cockpit":
  return <ExecutiveCockpit onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Executive Command Center;
- resultado typecheck.
