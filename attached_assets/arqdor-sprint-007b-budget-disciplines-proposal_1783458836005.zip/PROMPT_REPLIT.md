Aplicar Sprint 007B — Budget Disciplines + Proposal.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/executive-budget/disciplines

2. Em ArqWorkspace.tsx:
- importar BudgetDisciplinesProposal;
- plugar em um case seguro de orçamento/proposta/budget;
- manter outros módulos intactos.

3. Não alterar backend.
4. Não alterar banco.
5. Não alterar Core Vendor.ai.
6. Não alterar rotas.
7. Não alterar useArqProject.ts.

Rodar:
- pnpm check
- pnpm build

Corrigir somente imports/tipagens se necessário.

Entregar:
- arquivos copiados;
- arquivo alterado para integração;
- resultado typecheck;
- resultado build.
