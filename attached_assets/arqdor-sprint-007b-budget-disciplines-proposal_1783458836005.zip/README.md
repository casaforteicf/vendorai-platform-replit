# Sprint 007B — Budget Disciplines + Proposal

## Objetivo
Complementar o Executive Budget Engine com orçamento por disciplina, proposta, exportação e revisão.

## Arquivos incluídos
- BudgetDisciplinesProposal.tsx
- BudgetDisciplinePanel.tsx
- DisciplineBudgetTable.tsx
- disciplineBudgetData.ts
- ProposalGenerator.tsx
- ExportBudget.tsx
- BudgetReview.tsx

## Integração sugerida
Em `ArqWorkspace.tsx`, importar:

```tsx
import BudgetDisciplinesProposal from "./executive-budget/disciplines/BudgetDisciplinesProposal";
```

Plugar em um case seguro, por exemplo:

```tsx
return <BudgetDisciplinesProposal />;
```

Sugestão de case: `orcamento-pro`, `budget-proposal`, ou algum case disponível de teste.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts

## Validação
- pnpm check
- pnpm build
