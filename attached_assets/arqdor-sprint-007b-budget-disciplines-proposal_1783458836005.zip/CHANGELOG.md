# Changelog — Sprint 007B

## Adicionado
- Orçamento por disciplina.
- Marcenaria, gesso, elétrica, hidráulica, pintura, marmoraria, paisagismo, esquadrias, mão de obra e frete.
- Gerador inicial de proposta.
- Exportação estrutural PDF/Excel.
- Revisão antes da proposta.
