# Sprint 008 — Documentation Studio Enterprise

## Arquivo substituído
- `artifacts/frontend/src/modules/arqdor/workspace/documentation-studio/DocumentationStudio.tsx`

## Objetivo
Transformar documentação em módulo Enterprise conectado ao render:
- Cadernos por disciplina.
- Memorial IA.
- Plantas e vistas.
- Quantitativos.
- Revisões.
- Impressão/PDF estrutural.

## Não alterar
- Backend
- Banco
- Rotas
- Hooks
- ArqWorkspace
