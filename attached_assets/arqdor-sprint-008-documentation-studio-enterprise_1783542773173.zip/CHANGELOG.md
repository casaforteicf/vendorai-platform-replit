# Changelog — Sprint 008

## Alterado
- DocumentationStudio refinado para versão Enterprise.
- Cadernos técnicos por disciplina.
- Memorial assistido por IA.
- Plantas/vistas técnicas.
- Quantitativos.
- Revisões.
- Impressão.
