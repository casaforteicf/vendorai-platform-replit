Aplicar Sprint 008 — Documentation Studio Enterprise.

1. Substituir:
artifacts/frontend/src/modules/arqdor/workspace/documentation-studio/DocumentationStudio.tsx

2. Não criar componentes paralelos.
3. Não alterar ArqWorkspace.
4. Não alterar backend, banco, rotas ou hooks.

Rodar:
pnpm typecheck
pnpm build

Entregar print da documentação.
