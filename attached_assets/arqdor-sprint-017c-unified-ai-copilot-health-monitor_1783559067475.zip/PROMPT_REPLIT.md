Aplicar Sprint 017C — Unified AI Copilot + Health Monitor.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-hub/unified-copilot

2. Integrar em ArqWorkspace ou IntegrationHub:
import UnifiedCopilotCenter from "./integration-hub/unified-copilot/UnifiedCopilotCenter";

3. Usar em case seguro:
case "unified-copilot":
case "copilot":
case "ai-copilot":
  return <UnifiedCopilotCenter onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Unified Copilot Center;
- resultado typecheck.
