Aplicar Sprint 012A — Procurement Core.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/procurement-studio

2. Integrar em ArqWorkspace:
import ProcurementStudio from "./procurement-studio/ProcurementStudio";

3. Usar em case seguro:
case "procurement":
case "compras":
  return <ProcurementStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build via workflow se necessário.

Entregar:
- print do Procurement Studio;
- resultado typecheck.
