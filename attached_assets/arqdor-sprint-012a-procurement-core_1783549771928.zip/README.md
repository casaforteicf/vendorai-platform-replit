# Sprint 012A — Procurement Core

## Pacote 1 da Sprint 012

Arquivos incluídos:
- ProcurementStudio.tsx
- procurementTypes.ts
- procurementData.ts
- procurementUtils.ts
- MetricCard.tsx
- PurchaseRequestCard.tsx
- PurchaseRequestInspector.tsx
- ProcurementDashboard.tsx
- ProcurementSuppliers.tsx
- AIProcurementPanel.tsx

## Objetivo
Criar o core do Procurement Studio:
- Dashboard.
- Solicitações de compra.
- Inspector da solicitação.
- Fornecedores de compra.
- IA de compras.
- Estrutura de navegação para cotações, pedidos, recebimento, estoque e logística.

## Integração
Importar no ArqWorkspace:

```tsx
import ProcurementStudio from "./procurement-studio/ProcurementStudio";
```

Adicionar/usar case:

```tsx
case "procurement":
case "compras":
  return <ProcurementStudio arqState={arqState} onNavigate={handleNavigate} />;
```
