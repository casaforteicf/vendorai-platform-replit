# Changelog — Sprint 012A

## Adicionado
- Procurement Core.
- Dashboard de compras.
- Solicitações de compra.
- Inspector da solicitação.
- Base de fornecedores.
- IA de compras.
- Navegação base para cotações, pedidos, recebimento, estoque e logística.
