Aplicar Sprint 009 — Módulo Completo Specification Studio Enterprise.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/specification-studio

2. Integrar em ArqWorkspace:
import SpecificationStudio from "./specification-studio/SpecificationStudio";

3. Adicionar case seguro:
case "specification":
case "especificacao-produto":
  return <SpecificationStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar hooks.
7. Não alterar rotas públicas.

Rodar:
pnpm typecheck
pnpm build

Entregar:
- print do Specification Studio;
- resultado typecheck;
- resultado build.
