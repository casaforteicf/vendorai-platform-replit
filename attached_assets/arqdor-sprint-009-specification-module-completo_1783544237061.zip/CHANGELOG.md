# Changelog — Sprint 009 Módulo Completo

## Adicionado
- Módulo completo de especificação.
- Tipos centralizados.
- Dados mockados organizados.
- Utils de projeto/status.
- Catálogo de produtos.
- Filtros e busca.
- Objetos inteligentes.
- Inspector do objeto.
- Materiais.
- Fabricantes.
- Fornecedores.
- Timeline executiva.
- Painel de aprovação.
- Painel de recomendações IA.
