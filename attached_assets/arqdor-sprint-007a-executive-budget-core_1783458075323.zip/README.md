# Sprint 007A — Executive Budget Core

## Objetivo
Criar o núcleo do orçamento executivo do ARQDOR.ai.

## Arquivos incluídos
- BudgetEngine.tsx
- BudgetContext.tsx
- BudgetHeader.tsx
- BudgetSidebar.tsx
- BudgetCanvas.tsx
- BudgetKPIs.tsx
- BudgetSummary.tsx
- BudgetTotals.tsx
- BudgetTimeline.tsx
- BudgetItemsTable.tsx
- budgetData.ts
- useBudgetEngine.ts

## Integração sugerida
Em `ArqWorkspace.tsx`, importar:

```tsx
import BudgetEngine from "./executive-budget/BudgetEngine";
```

Plugar em um case seguro:

```tsx
return <BudgetEngine arqState={arqState} onNavigate={handleNavigate} />;
```

Sugestão de case: `orcamento`, `budget` ou algum case disponível de teste.

## Não alterar
- Backend
- Banco
- Core Vendor.ai
- Rotas
- useArqProject.ts

## Validação
- pnpm check
- pnpm build
