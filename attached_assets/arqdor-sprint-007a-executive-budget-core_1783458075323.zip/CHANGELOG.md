# Changelog — Sprint 007A

## Adicionado
- Executive Budget Core.
- Contexto de orçamento.
- Dashboard financeiro.
- KPIs.
- Totais por disciplina.
- Tabela de itens.
- Resumo executivo.
- Timeline inicial.
