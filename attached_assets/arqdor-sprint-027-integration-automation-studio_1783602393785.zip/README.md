# Sprint 027 — Integration & Automation Studio

## Objetivo
Criar o módulo central de integrações e automações do ARQDOR.ai.

Este módulo organiza:
- canais;
- webhooks;
- automações;
- providers;
- jobs de sync;
- logs;
- templates;
- segurança;
- health das integrações.

## Arquivos incluídos
- IntegrationAutomationStudio.tsx
- IntegrationOverview.tsx
- ChannelsPanel.tsx
- WebhookPanel.tsx
- AutomationsPanel.tsx
- ProvidersPanel.tsx
- SyncJobsPanel.tsx
- IntegrationLogsPanel.tsx
- TemplatesPanel.tsx
- SecurityPanel.tsx
- HealthPanel.tsx
- IntegrationMetricCard.tsx
- SuccessBar.tsx
- integrationTypes.ts
- integrationData.ts
- integrationUtils.ts

## Integração no ArqWorkspace

Importar:

```tsx
import IntegrationAutomationStudio from "./integration-automation-studio/IntegrationAutomationStudio";
```

Adicionar case:

```tsx
case "integrations":
case "automation":
case "integration-automation":
  return <IntegrationAutomationStudio arqState={arqState} onNavigate={handleNavigate} />;
```

## Observação
Este pacote não altera backend, banco ou autenticação.
Ele entrega a central visual de integrações e automações para evoluir depois para execução real.
