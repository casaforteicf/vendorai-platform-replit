# Changelog — Sprint 027 Integration & Automation Studio

## Adicionado
- Central Integration Hub do ARQDOR.ai.
- Canais de comunicação.
- Webhooks.
- Automações.
- Providers externos.
- Sync jobs.
- Logs.
- Templates.
- Segurança.
- Health das integrações.

## Fora do escopo
- Backend.
- Banco.
- Execução real das automações.
- OAuth real.
- Webhooks reais novos.
