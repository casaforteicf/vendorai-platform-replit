Aplicar Sprint 027 — Integration & Automation Studio.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-automation-studio

2. Integrar no ArqWorkspace:
import IntegrationAutomationStudio from "./integration-automation-studio/IntegrationAutomationStudio";

3. Adicionar case:
case "integrations":
case "automation":
case "integration-automation":
  return <IntegrationAutomationStudio arqState={arqState} onNavigate={handleNavigate} />;

4. Não alterar backend.
5. Não alterar banco.
6. Não alterar autenticação.
7. Não alterar outros nichos da Vendor.ai.
8. Manter isolamento em /arch/*.

Rodar:
pnpm typecheck

Validar UI:
- Visão
- Canais
- Webhooks
- Automações
- Providers
- Sync
- Logs
- Templates
- Segurança
- Health

Entregar:
- resultado do typecheck;
- print da tela Integration Hub;
- logs do workflow se houver erro.
