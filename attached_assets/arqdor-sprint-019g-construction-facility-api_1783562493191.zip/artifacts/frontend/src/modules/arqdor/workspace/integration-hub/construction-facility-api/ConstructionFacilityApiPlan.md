# Plano técnico — Sprint 019G

## Objetivo
Conectar Construction Hub e Facility Management ao fluxo real vindo da Production.

## Fluxo
Production finished/delivered
→ production.delivered
→ Construction phase
→ Construction delivered
→ Facility asset
→ Owner manual / warranties / maintenance

## Regras
- Construction só deve avançar após Production.
- Facility só deve criar ativos após entrega/instalação.
- Manter fallback mock para constructionData.ts e facilityData.ts.
- Não criar backend nesta sprint.
