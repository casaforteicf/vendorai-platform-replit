# Checklist 019G

- [ ] Confirmar se /arch/construction existe
- [ ] Confirmar se /arch/facility existe
- [ ] Integrar ConstructionRepository
- [ ] Integrar FacilityRepository
- [ ] Manter fallback constructionData.ts
- [ ] Manter fallback facilityData.ts
- [ ] Validar productionOrderId
- [ ] Validar facilityAssetId
- [ ] Rodar pnpm typecheck
- [ ] Listar pendências para 019H Event Bus
