# Sprint 019G — Construction + Facility API Integration

## Objetivo
Conectar Construction Hub e Facility Management ao fluxo real vindo de Production.

## Entregas
- ConstructionRepository
- FacilityRepository
- ProductionDeliveredHandler
- ConstructionDeliveredHandler
- ConstructionFacilityContract
- ConstructionFacilityValidation
- Plano técnico
- Checklist

## Integração sugerida
```ts
import { ConstructionRepository } from "./integration-hub/construction-facility-api/ConstructionRepository";
import { FacilityRepository } from "./integration-hub/construction-facility-api/FacilityRepository";
```

## Regras
- Não alterar backend.
- Não remover fallback mock ainda.
- Construction depende de Production.
- Facility depende de Construction entregue.
- Rodar `pnpm typecheck`.
