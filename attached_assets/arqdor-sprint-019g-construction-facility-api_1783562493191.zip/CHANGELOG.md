# Changelog — Sprint 019G

## Adicionado
- ConstructionRepository
- FacilityRepository
- ProductionDeliveredHandler
- ConstructionDeliveredHandler
- ConstructionFacilityContract
- ConstructionFacilityValidation
- Plano de migração Construction/Facility
- Checklist 019G
