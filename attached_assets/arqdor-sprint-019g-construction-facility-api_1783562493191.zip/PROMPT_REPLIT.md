Aplicar Sprint 019G — Construction + Facility API Integration.

Objetivo:
Conectar Construction Hub e Facility Management ao fluxo Production → Construction → Facility com fallback seguro.

1. Copiar a pasta:
artifacts/frontend/src/modules/arqdor/workspace/integration-hub/construction-facility-api

2. Integrar gradualmente:
- ConstructionRepository para /arch/construction ou rota equivalente.
- FacilityRepository para /arch/facility ou rota equivalente.
- ProductionDeliveredHandler para criar fase de obra.
- ConstructionDeliveredHandler para criar ativo de facility.

3. Não remover:
- constructionData.ts
- facilityData.ts

4. Usar fallback:
- tenta API real;
- se falhar, usa dados mockados atuais.

5. Validar contrato:
- projectId
- productionOrderId
- environmentId
- constructionPhaseId
- facilityAssetId
- canonicalProductId quando existir

6. Se APIs não existirem:
- não criar backend;
- manter adapters documentados;
- registrar pendência para backend.

7. Rodar:
pnpm typecheck

Entregar:
- typecheck;
- arquivos alterados;
- fallback mantido;
- APIs encontradas;
- APIs ausentes;
- pendências para 019H Event Bus.
